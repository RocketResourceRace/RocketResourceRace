import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.math.BigDecimal; 
import processing.sound.*; 
import java.util.Arrays; 
import java.nio.file.Files; 
import java.nio.file.Paths; 
import java.nio.file.Path; 
import java.util.Collections; 
import java.nio.ByteBuffer; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class RocketResourceRace extends PApplet {








String activeState;
HashMap<String, State> states;
int lastClickTime = 0;
final int DOUBLECLICKWAIT = 500;
final String LETTERSNUMBERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890/\\_ ";
HashMap<String, SoundFile> sfx;
int prevT;
JSONObject gameData;
HashMap<Integer, PFont> fonts;
PShader toon;
String loadingName;

JSONManager jsManager;

// Event-driven methods
public void mouseClicked(){mouseEvent("mouseClicked", mouseButton);doubleClick();}
public void mouseDragged(){mouseEvent("mouseDragged", mouseButton);}
public void mouseMoved(){mouseEvent("mouseMoved", mouseButton);}
public void mousePressed(){mouseEvent("mousePressed", mouseButton);}
public void mouseReleased(){mouseEvent("mouseReleased", mouseButton);}
public void mouseWheel(MouseEvent event){mouseEvent("mouseWheel", mouseButton, event);}
public void keyPressed(){keyboardEvent("keyPressed", key);}
public void keyReleased(){keyboardEvent("keyReleased", key);}
public void keyTyped(){keyboardEvent("keyTyped", key);}

public float between(float lower, float v, float upper){
  return max(min(upper, v), lower);
}

public int brighten(int old, int off){
  return color(between(0, red(old)+off, 255), between(0, green(old)+off, 255), between(0, blue(old)+off, 255));
}

public String roundDp(String val, int dps){
  return (new BigDecimal(""+val).divide(new BigDecimal("1"), dps, BigDecimal.ROUND_HALF_EVEN).stripTrailingZeros()).toPlainString();
}

public int JSONIndex(JSONArray j, String id){
  for (int i=0; i<j.size(); i++){
    if (j.getJSONObject(i).getString("id").equals(id)){
      return i;
    }
  }
  println("invalid id,", id);
  return -1;
}

public JSONObject findJSONObject(JSONArray j, String id){
  for (int i=0; i<j.size(); i++){
    if (j.getJSONObject(i).getString("id").equals(id)){
      return j.getJSONObject(i);
    }
  }
  return null;
}

public boolean JSONContainsStr(JSONArray j, String id){
  if (id == null || j == null)
    return false;
  for (int i=0; i<j.size(); i++){
    if (j.getString(i).equals(id)){
      return true;
    }
  }
  return false;
}

public void doubleClick(){
  if (millis() - lastClickTime < DOUBLECLICKWAIT){
    mouseEvent("mouseDoubleClicked", mouseButton);
    lastClickTime = 0;
  }
  else{
    lastClickTime = millis();
  }
}

public float sigmoid(float x){
  return 1-2/(exp(x)+1);
}

public void mouseEvent(String eventType, int button){
  getActiveState()._mouseEvent(eventType, button);
}
public void mouseEvent(String eventType, int button, MouseEvent event){
  getActiveState()._mouseEvent(eventType, button, event);
}
public void keyboardEvent(String eventType, char _key){
  if (key==ESC){
    key = 0;
  }
  getActiveState()._keyboardEvent(eventType, _key);
}

public void setVolume(){
  for (SoundFile fect:sfx.values()){
    fect.amp(jsManager.loadFloatSetting("volume"));
  }
}

public void setFrameRateCap(){
  if (jsManager.loadBooleanSetting("framerate cap")){
    frameRate(60);
  }
  else{
    frameRate(1000);
  }
}

int NUMOFGROUNDTYPES = 5;
int NUMOFBUILDINGTYPES = 9;
int TILESIZE = 1;
int MAPWIDTH = 100;
int MAPHEIGHT = 100;
float MAPHEIGHTNOISESCALE = 0.08f;
float MAPTERRAINNOISESCALE = 0.08f;
float HILLSTEEPNESS = 0.1f;

int[] playerColours = new int[]{color(0, 0, 255), color(255, 0, 0)};

HashMap<String, PImage> tileImages;
HashMap<String, PImage[]> buildingImages;
PImage[] partyImages;
PImage[] taskImages;
HashMap<String, PImage> lowImages;
HashMap<String, PImage> tile3DImages;

public void loadSounds(){
  if(jsManager.loadBooleanSetting("sound on")){
    sfx = new HashMap<String, SoundFile>();
    sfx.put("click3", new SoundFile(this, "click3.wav"));
  }
}

public void loadImages(){
  try{
    tileImages = new HashMap<String, PImage>();
    lowImages = new HashMap<String, PImage>();
    tile3DImages = new HashMap<String, PImage>();
    buildingImages = new HashMap<String, PImage[]>();
    taskImages = new PImage[gameData.getJSONArray("tasks").size()];
    for (int i=0; i<gameData.getJSONArray("terrain").size(); i++){
      JSONObject tileType = gameData.getJSONArray("terrain").getJSONObject(i);
      tileImages.put(tileType.getString("id"), loadImage(tileType.getString("img")));
      if (!tileType.isNull("low img")){
        lowImages.put(tileType.getString("id"), loadImage(tileType.getString("low img")));
      }
      if(!tileType.isNull("img3d")){
        tile3DImages.put(tileType.getString("id"), loadImage(tileType.getString("img3d")));
      }
    }
    for (int i=0; i<gameData.getJSONArray("buildings").size(); i++){
      JSONObject buildingType = gameData.getJSONArray("buildings").getJSONObject(i);
      PImage[] p = new PImage[buildingType.getJSONArray("img").size()];
      for (int i2=0; i2< buildingType.getJSONArray("img").size(); i2++)
        p[i2] = loadImage(buildingType.getJSONArray("img").getString(i2));
      buildingImages.put(buildingType.getString("id"), p);
    }
    for (int i=0; i<gameData.getJSONArray("tasks").size(); i++){
      JSONObject task = gameData.getJSONArray("tasks").getJSONObject(i);
      if (!task.isNull("img")){
        taskImages[i] = loadImage(task.getString("img"));
      }
    }
  }
  catch (Exception e){
    println("Error loading images");
    println(e);
  }
}

public PFont getFont(float size){
  PFont f=fonts.get(round(size));
  if (f == null){
    fonts.put(round(size), createFont("GillSans", size));
    return fonts.get(round(size));
  }
  else{
    return f;
  }
}


public float sum(float[] l){
  float c=0;
  for (int i=0; i<l.length; i++)
    c += l[i];
  return c;
}


float halfScreenWidth;
float halfScreenHeight;
public void setup(){

  
  try{
    fonts = new HashMap<Integer, PFont>();
    gameData = loadJSONObject("data.json");
    jsManager = new JSONManager();
    loadSounds();
    setFrameRateCap();
    textFont(createFont("GillSans", 32));

    loadImages();

    partyImages = new PImage[]{
      loadImage("data/blue_flag.png"),
      loadImage("data/red_flag.png"),
      loadImage("data/battle.png")
    };
    states = new HashMap<String, State>();
    addState("menu", new Menu());
    addState("map", new Game());
    activeState = "menu";
    //noSmooth();
    smooth();
    noStroke();
    //hint(DISABLE_OPTIMIZED_STROKE);
    halfScreenWidth = width/2;
    halfScreenHeight= height/2;
    toon = loadShader("ToonFrag.glsl", "ToonVert.glsl");
    toon.set("fraction", 1.0f);
  }
  catch(Exception e){
    PrintWriter pw = createWriter("error_log");
    pw.println(""+millis()+e);
    pw.flush();
    pw.close();
  }
}
boolean smoothed = false;

public void draw(){
  background(255);
  prevT = millis();
  String newState = getActiveState().update();
  if (!newState.equals("")){
    for (Panel panel : states.get(newState).panels){
      for (Element elem : panel.elements){
        elem.mouseEvent("mouseMoved", LEFT);
      }
    }
    states.get(activeState).leaveState();
    states.get(newState).enterState();
    activeState = newState;
  }
  textFont(getFont(10));
  textAlign(LEFT, TOP);
  fill(255,0,0);
  text(frameRate, 0, 0);


}

public State getActiveState(){
  return states.get(activeState);
}

public void addState(String name, State state){
  states.put(name, state);
}

class State{
  ArrayList<Panel> panels;
  String newState, activePanel;

  State(){
    panels = new ArrayList<Panel>();
    addPanel("default", 0, 0, width, height, true, true, color(255, 255), color(0));
    newState = "";
    activePanel = "default";
  }

  public String getNewState(){
    String t = newState;
    newState = "";
    return t;
  }

  public String update(){
    drawPanels();
    return getNewState();
  }
  public void enterState(){

  }
  public void leaveState(){

  }
  public void hidePanels(){
    for (Panel panel:panels){
      panel.visible = false;
    }
  }
  
  public void resetPanels(){
    panels.clear();
  }
  
  public void addPanel(String id, int x, int y, int w, int h, Boolean visible, Boolean blockEvent, int bgColour, int strokeColour){
    // Adds new panel to front
    panels.add(new Panel(id, x, y, w, h, visible, blockEvent, bgColour, strokeColour));
    panelToTop(id);
  }
  public void addPanel(String id, int x, int y, int w, int h, Boolean visible, String fileName, int strokeColour){
    // Adds new panel to front
    panels.add(new Panel(id, x, y, w, h, visible, fileName, strokeColour));
    panelToTop(id);
  }
  public void addElement(String id, Element elem){
    elem.setID(id);
    getPanel("default").elements.add(elem);
    elem.setOffset(getPanel("default").x, getPanel("default").y);
  }
  public void addElement(String id, Element elem, String panel){
    elem.setID(id);
    getPanel(panel).elements.add(elem);
    elem.setOffset(getPanel(panel).x, getPanel(panel).y);
  }

  public Element getElement(String id, String panel){
    for (Element elem : getPanel(panel).elements){
      if (elem.id.equals(id)){
        return  elem;
      }
    }
    println(String.format("Element not found %s panel:%s", id, panel));
    return null;
  }

  public void removeElement(String elementID, String panelID){
    getPanel(panelID).elements.remove(elementID);
  }
  public void removePanel(String id){
    panels.remove(findPanel(id));
  }

  public void panelToTop(String id){
    Panel tempPanel = getPanel(id);
    for (int i=findPanel(id); i>0; i--){
      panels.set(i, panels.get(i-1));
    }
    panels.set(0, tempPanel);
  }
  
  public void elementToTop(String id, String panelID){
    Element tempElem = getElement(id, panelID);
    boolean found = false;
    for (int i=0; i<getPanel(panelID).elements.size()-1; i++){
      if (getPanel(panelID).elements.get(i).id.equals(id)){
        found = true;
      }
      if (found){
        getPanel(panelID).elements.set(i, getPanel(panelID).elements.get(i+1));
      }
    }
    getPanel(panelID).elements.set(getPanel(panelID).elements.size()-1, tempElem);
  }

  public void printPanels(){
    for(Panel panel:panels){
      print(panel.id);
    }
    println();
  }

  public int findPanel(String id){
    for (int i=0; i<panels.size(); i++){
      if (panels.get(i).id.equals(id)){
        return i;
      }
    }
    print("invalid panel, ", id);
    return -1;
  }
  public Panel getPanel(String id){
    return panels.get(findPanel(id));
  }

  public void drawPanels(){
    // Draw the panels in reverse order (highest in the list are drawn last so appear on top)
    for (int i=panels.size()-1; i>=0; i--){
      if (panels.get(i).visible){
        panels.get(i).draw();
      }
    }
  }
  // Empty method for use by children
  public ArrayList<String> mouseEvent(String eventType, int button){return new ArrayList<String>();}
  public ArrayList<String> mouseEvent(String eventType, int button, MouseEvent event){return new ArrayList<String>();}
  public ArrayList<String> keyboardEvent(String eventType, char _key){return new ArrayList<String>();}

  public void elementEvent(ArrayList<Event> events){
    for (Event event : events){
      println(event.info(), 1);
    }
  }
 
  public void _elementEvent(ArrayList<Event> events){
    for (Event event : events){
      if (event.type.equals("element to top")){
        elementToTop(event.id, event.panel);
      }
    }
  }

  public void _mouseEvent(String eventType, int button){
    ArrayList<Event> events = new ArrayList<Event>();
    mouseEvent(eventType, button);
    if (eventType == "mousePressed"){
      for (int i=0; i<panels.size(); i++){
        if (panels.get(i).mouseOver()&& panels.get(i).visible&&panels.get(i).blockEvent){
          activePanel = panels.get(i).id;
          break;
        }
      }
    }
    for (Panel panel : panels){
      if(activePanel == panel.id || eventType.equals("mouseMoved") || panel.overrideBlocking){
        // Iterate in reverse order
        for (int i=panel.elements.size()-1; i>=0; i--){
          if (panel.elements.get(i).active && panel.visible){
            for (String eventName : panel.elements.get(i)._mouseEvent(eventType, button)){
              events.add(new Event(panel.elements.get(i).id, panel.id, eventName));
              if (eventName.equals("stop events")){
                return;
              }
            }
          }
        }
        if (!eventType.equals("mouseMoved") && !panel.overrideBlocking)
          break;
      }
    }
    elementEvent(events);
    _elementEvent(events);
  }
  public void _mouseEvent(String eventType, int button, MouseEvent event){
    ArrayList<Event> events = new ArrayList<Event>();
    mouseEvent(eventType, button, event);
    for (Panel panel : panels){
      if(panel.mouseOver() && panel.visible){
        // Iterate in reverse order
        for (int i=panel.elements.size()-1; i>=0; i--){
          if (panel.elements.get(i).active){
            for (String eventName : panel.elements.get(i)._mouseEvent(eventType, button, event)){
              events.add(new Event(panel.elements.get(i).id, panel.id, eventName));
              if (eventName.equals("stop events")){
                return;
              }
            }
          }
        }
      }
    }
    elementEvent(events);
    _elementEvent(events);
  }
  public void _keyboardEvent(String eventType, char _key){
    ArrayList<Event> events = new ArrayList<Event>();
    keyboardEvent(eventType, _key);
    for (Panel panel : panels){
      for (int i=panel.elements.size()-1; i>=0; i--){
        if (panel.elements.get(i).active && panel.visible){
          for (String eventName : panel.elements.get(i)._keyboardEvent(eventType, _key)){
            events.add(new Event(panel.elements.get(i).id, panel.id, eventName));
          }
        }
      }
    }
    elementEvent(events);
    _elementEvent(events);
  }
}






class Panel{
  ArrayList<Element> elements;
  String id;
  PImage img;
  Boolean visible, blockEvent, overrideBlocking;
  private int x, y, w, h;
  private int bgColour, strokeColour;
  PGraphics panelCanvas, elemGraphics;

  Panel(String id, int x, int y, int w, int h, Boolean visible, Boolean blockEvent, int bgColour, int strokeColour){
    this.x = x;
    this.y = y;
    this.w = w;
    this.h = h;
    this.visible = visible;
    this.blockEvent = blockEvent;
    this.id = id;
    this.bgColour = bgColour;
    this.strokeColour = strokeColour;
    elements = new ArrayList<Element>();
    panelCanvas = createGraphics(w, h, P2D);
    overrideBlocking = false;
  }

  Panel(String id, int x, int y, int w, int h, Boolean visible, String fileName, int strokeColour){
    this.x = x;
    this.y = y;
    this.w = w;
    this.h = h;
    this.visible = visible;
    this.id = id;
    this.img = loadImage(fileName);
    this.strokeColour = strokeColour;
    elements = new ArrayList<Element>();
    panelCanvas = createGraphics(w, h, P2D);
    overrideBlocking = false;
  }
  
  public void setOverrideBlocking(boolean v){
    overrideBlocking = v;
  }

  public void setOffset(){
    for (Element elem : elements){
      elem.setOffset(x, y);
    }
  }
  public void setColour(int c){
    bgColour = c;
  }

  public void setVisible(boolean a){
    visible = a;
    for (Element elem:elements){
      elem.mouseEvent("mouseMoved", mouseButton);
    }
  }
  public void transform(int x, int y, int w, int h){
    this.x = x;
    this.y = y;
    this.w = w;
    this.h = h;
    setOffset();
  }

  public void draw(){
    panelCanvas.beginDraw();
    panelCanvas.clear();
    panelCanvas.pushStyle();
    if (img == null){
      if (bgColour != color(255, 255)){
        panelCanvas.fill(bgColour);
        panelCanvas.stroke(strokeColour);
        panelCanvas.rect(0, 0, w, h);
      }
    }
    else{
      //imageMode(CENTER);
      panelCanvas.image(img, 0, 0, w, h);
    }
    panelCanvas.popStyle();

    for (Element elem : elements){
      if(elem.visible){
        elem.draw(panelCanvas);
      }
    }
    panelCanvas.endDraw();
    image(panelCanvas, x, y);
  }

  public int getX(){
    return x;
  }
  public int getY(){
    return y;
  }

  public Boolean mouseOver(){
    return mouseX >= x && mouseX <= x+w && mouseY >= y && mouseY <= y+h;
  }
}





class Element{
  boolean active = true;
  boolean visible = true;
  int x, y, w, h, xOffset, yOffset;
  String id;

  public void draw(PGraphics panelCanvas){}
  public ArrayList<String> mouseEvent(String eventType, int button){return new ArrayList<String>();}
  public ArrayList<String> mouseEvent(String eventType, int button, MouseEvent event){return new ArrayList<String>();}
  public ArrayList<String> keyboardEvent(String eventType, char _key){return new ArrayList<String>();}
  public void transform(int x, int y, int w, int h){
    this.x = x;
    this.y = y;
    this.w = w;
    this.h = h;
  }
  public void setOffset(int xOffset, int yOffset){
    this.xOffset = xOffset;
    this.yOffset = yOffset;
  }
  
  public void setID(String id){
    this.id = id;
  }
  
  public ArrayList<String> _mouseEvent(String eventType, int button){
    return mouseEvent(eventType, button);
  }
  public ArrayList<String> _mouseEvent(String eventType, int button, MouseEvent event){
    return mouseEvent(eventType, button, event);
  }
  public ArrayList<String> _keyboardEvent(String eventType, char _key){
    return keyboardEvent(eventType, _key);
  }
  public void activate(){
    active = true;
  }
  public void deactivate(){
    active = false;
  }
}


class BaseFileManager extends Element{
  // Basic file manager that scans a folder and makes a selectable list for all the files
  final int TEXTSIZE = 14;
  String folderString;
  String[] saveNames;
  int selected, rowHeight;
  
  
  BaseFileManager(int x, int y, int w, int h, String folderString){
    super.x = x;
    super.y = y;
    super.w = w;
    super.h = h;
    this.folderString = folderString;
    saveNames = new String[0];
    selected = 0;
    rowHeight = ceil(TEXTSIZE * jsManager.loadFloatSetting("text scale"))+5;
  }
  
  public String getNextAutoName(){
    // Find the next automatic name for save
    loadSaveNames();
    int mx = 1;
    for (int i=0; i<saveNames.length; i++){
      if (saveNames[i].length() > 8) {// 'Untitled is 8 characters
        if (saveNames[i].substring(0, 8).equals("Untitled")){
          try{
            mx = max(mx, Integer.parseInt(saveNames[i].substring(8, saveNames[i].length())));
          }
          catch(Exception e){
            print(1);
          }
        }
      }
    }
    return "Untitled"+(mx+1);
  }
  
  public void loadSaveNames(){
    try{
      File dir = new File(sketchPath("saves"));
      if (!dir.exists()){
        println("creating new saves directory");
        dir.mkdir();
      }
      saveNames = dir.list();
    }
    catch (Exception e) {
      println("files scanning failed");
    }
  }
  
  public ArrayList<String> mouseEvent(String eventType, int button){
    ArrayList<String> events = new ArrayList<String>();
    
    if (eventType.equals("mouseClicked")){
      if (moveOver()){
        selected = hoveringOption();
        events.add("valueChanged");
      }
    }
    
    return events;
  }
  
  public String selectedSaveName(){
    if (saveNames.length == 0){
      return "Untitled";
    }
    return saveNames[selected];
  }
  
  public void draw(PGraphics panelCanvas){
    
    rowHeight = ceil(TEXTSIZE * jsManager.loadFloatSetting("text scale"))+5;
    panelCanvas.pushStyle();
    
    panelCanvas.textSize(TEXTSIZE * jsManager.loadFloatSetting("text scale"));
    panelCanvas.textAlign(LEFT, TOP);
    for (int i=0; i<saveNames.length; i++){
      if (selected == i){
        panelCanvas.strokeWeight(2);
        panelCanvas.fill(color(100));
      }
      else{
        panelCanvas.strokeWeight(1);
        panelCanvas.fill(color(150));
      }
      panelCanvas.rect(x, y+rowHeight*i, w, rowHeight);
      panelCanvas.fill(0);
      panelCanvas.text(saveNames[i], x, y+rowHeight*i);
    }
    
    panelCanvas.popStyle();
  }
  
  public boolean moveOver(){
    return mouseX-xOffset >= x && mouseX-xOffset <= x+w && mouseY-yOffset >= y && mouseY-yOffset <= y+h*(saveNames.length+1);
  }
  
  public int hoveringOption(){
    int s = (mouseY-yOffset-y)/rowHeight;
    if (!(0 <= s && s < saveNames.length)){
      return selected;
    }
    return s;
  }
}




class DropDown extends Element{
  String[] options;  // Either strings or floats
  int selected, bgColour;
  String name, optionTypes;
  boolean expanded, postExpandedEvent;
  
  DropDown(int x, int y, int w, int h, int bgColour, String name, String optionTypes){
    // h here means the height of one dropper box
    this.x = x;
    this.y = y;
    this.w = w;
    this.h = h;
    this.bgColour = bgColour;
    this.name = name;
    this.expanded = false;
    this.optionTypes = optionTypes;
  }
  
  public void setOptions(String[] options){
    this.options = options;
  }
  
  public void setValue(String value){
    for (int i=0; i < options.length; i++){
      if (value.equals(options[i])){
        selected = i;
        return;
      }
    }
    println("Invalid value", value);
  }
  
  public void draw(PGraphics panelCanvas){
    int hovering = hoveringOption();
    panelCanvas.pushStyle();
    
    // draw selected option
    panelCanvas.stroke(color(0));
    if (moveOver() && hovering == -1){
      panelCanvas.fill(brighten(bgColour, -20));
    }
    else{
      panelCanvas.fill(brighten(bgColour, -40));
    }
    panelCanvas.rect(x, y, w, h);
    panelCanvas.textAlign(LEFT, TOP);
    panelCanvas.fill(color(0));
    panelCanvas.text(String.format("%s: %s", name, options[selected]), x+3, y);
    
    // Draw expand box
    if (expanded){
      panelCanvas.line(x+w-h, y+1, x+w-h/2, y+h-1);
      panelCanvas.line(x+w-h/2, y+h-1, x+w, y+1);
    }
    else{
      panelCanvas.line(x+w-h, y+h-1, x+w-h/2, y+1);
      panelCanvas.line(x+w-h/2, y+1, x+w, y+h-1);
    }
    
    // Draw other options
    if (expanded){
      for (int i=0; i < options.length; i++){
        if (i == selected){
          panelCanvas.fill(brighten(bgColour, 50));
        }
        else{
          if (moveOver() && i == hovering){
            panelCanvas.fill(brighten(bgColour, 20));
          }
          else{
            panelCanvas.fill(bgColour);
          }
        }
        panelCanvas.rect(x, y+(i+1)*h, w, h);
        if (i == selected){
          panelCanvas.fill(brighten(bgColour, 20));
        }
        else{
          panelCanvas.fill(0);
        }
        panelCanvas.text(options[i], x+3, y+(i+1)*h);
      }
    }
    
    panelCanvas.popStyle();
  }
  
  public ArrayList<String> mouseEvent(String eventType, int button){
    ArrayList<String> events = new ArrayList<String>();
    if (eventType.equals("mouseClicked")){
      int hovering = hoveringOption();
      if (moveOver()){
        if (hovering == -1){
          toggleExpanded();
        }
        else{
          events.add("valueChanged");
          selected = hovering;
          contract();
          events.add("stop events");
        }
      }
      else{
        contract();
      }
    }
    if (postExpandedEvent){
      events.add("element to top");
      postExpandedEvent = false;
    }
    return events;
  }
  
  public void setSelected(String s){
    for (int i=0; i < options.length; i++){
      if (options[i].equals(s)){
        selected = i;
        return;
      }
    }
    print("invalid selected:", s);
  }
  
  public void contract(){
    expanded = false;
  }
  
  public void expand(){
    postExpandedEvent = true;
    expanded = true;
  }
  
  public void toggleExpanded(){
    expanded = !expanded;
    if (expanded){
      postExpandedEvent = true;
    }
  }
  
  public int getIntVal(){
    return Integer.parseInt(options[selected]);
  }
  
  public String getStrVal(){
    return options[selected];
  }
  
  public float getFloatVal(){
    return Float.parseFloat(options[selected]);
  }
  
  public boolean moveOver(){
    if (expanded){
      return mouseX-xOffset >= x && mouseX-xOffset <= x+w && mouseY-yOffset >= y && mouseY-yOffset <= y+h*(options.length+1);
    }
    else{
      return mouseX-xOffset >= x && mouseX-xOffset <= x+w && mouseY-yOffset >= y && mouseY-yOffset <= y+h;
    }
  }
  
  public int hoveringOption(){
    if (!expanded){
      return -1;
    }
    return (mouseY-yOffset-y)/h-1;
  }
}


class Tickbox extends Element{
  boolean val;
  String name;
  
  Tickbox(int x, int y, int w, int h, boolean defaultVal, String name){
    this.x = x;
    this.y = y;
    this.w = w;
    this.h = h;
    this.val = defaultVal;
    this.name = name;
  }
  
  public void toggle(){
    val = !val;
  }
  
  public ArrayList<String> mouseEvent(String eventType, int button){
    ArrayList<String> events = new ArrayList<String>();
    if (eventType.equals("mouseClicked")){
      if (moveOver()){
        toggle();
        events.add("valueChanged");
      }
    }
    return events;
  }
  
  public boolean getState(){
    return val;
  }
  public void setState(boolean state){
    val = state;
  }
  
  public boolean moveOver(){
    return mouseX-xOffset >= x && mouseX-xOffset <= x+h && mouseY-yOffset >= y && mouseY-yOffset <= y+h;
  }
  
  public void draw(PGraphics panelCanvas){
    panelCanvas.pushStyle();
    
    panelCanvas.fill(color(255));
    panelCanvas.stroke(color(0));
    panelCanvas.rect(x, y, h*jsManager.loadFloatSetting("gui scale"), h*jsManager.loadFloatSetting("gui scale"));
    if (val){
      panelCanvas.line(x+1, y+1, x+h*jsManager.loadFloatSetting("gui scale")-1, y+h*jsManager.loadFloatSetting("gui scale")-1);
      panelCanvas.line(x+h*jsManager.loadFloatSetting("gui scale")-1, y+1, x+1, y+h*jsManager.loadFloatSetting("gui scale")-1);
    }
    panelCanvas.fill(0);
    panelCanvas.textAlign(LEFT, CENTER);
    panelCanvas.textSize(8*jsManager.loadFloatSetting("text scale"));
    panelCanvas.text(name, x+h*jsManager.loadFloatSetting("gui scale")+5, y+h*jsManager.loadFloatSetting("gui scale")/2);
    panelCanvas.popStyle();
  }
}

class Tooltip extends Element{
  boolean visible;
  String text;
  boolean attacking;
  
  Tooltip(){
    hide();
    setText("");
  }
  
  public void show(){
    visible = true;
  }
  public void hide(){
    visible = false;
  }
  
  public ArrayList<String> getLines(String s){
    int j = 0;
    ArrayList<String> lines = new ArrayList<String>();
    for (int i=0; i<s.length(); i++){
      if(s.charAt(i) == '\n'){
        lines.add(s.substring(j, i));
        j=i+1;
      }
    }
    lines.add(s.substring(j, s.length()));
    return lines;
  }
  public float maxWidthLine(ArrayList<String> lines){
    float ml = 0;
    for (int i=0; i<lines.size(); i++){
      if (textWidth(lines.get(i)) > ml){
        ml = textWidth(lines.get(i));
      }
    }
    return ml;
  }
  public void setText(String text){
    this.text = text;
  }
  //String resourcesList(float[] resources){
  //  String returnString = "";
  //  boolean notNothing = false;
  //  for (int i=0; i<numResources;i++){
  //    if (resources[i]>0){
  //      returnString += roundDp(""+resources[i], 1)+ " " +resourceNames[i]+ ", "; 
  //      notNothing = true;
  //    }
  //  }
  //  if (!notNothing)
  //    returnString += "Nothing/Unknown";
  //  else if(returnString.length()-2 > 0)
  //    returnString = returnString.substring(0, returnString.length()-2);
  //  return returnString;
  //}
  public String getResourceList(JSONArray resArray){
    String returnString = "";
    for (int i=0; i<resArray.size(); i++){
      JSONObject jo = resArray.getJSONObject(i);
      returnString += String.format("  %s %s\n", roundDp(""+jo.getFloat("quantity"),2), jo.getString("id"));
    }
    return returnString;
  }
  
  public void setMoving(int turns, boolean splitting){
    attacking = false;
    //Tooltip text if moving. Turns is the number of turns in move
    JSONObject jo = gameData.getJSONObject("tooltips");
    String t;
    if (splitting){
      t = jo.getString("moving splitting");
    }
    else{
      t = jo.getString("moving");
    }
    if (turns > 0){
      t += String.format(jo.getString("moving turns"), turns);
    }
    setText(t);
  }
  public void setAttacking(BigDecimal chance){
    attacking = true;
    JSONObject jo = gameData.getJSONObject("tooltips");
    setText(String.format(jo.getString("attacking"), chance.toString()));
  }
  public void setTurnsRemaining(){
    attacking = false;
    JSONObject jo = gameData.getJSONObject("tooltips");
    setText(jo.getString("turns remaining"));
  }
  public void setMoveButton(){
    attacking = false;
    JSONObject jo = gameData.getJSONObject("tooltips");
    setText(jo.getString("move button"));
  }
  public void setMerging(){
    attacking = false;
    JSONObject jo = gameData.getJSONObject("tooltips");
    setText(jo.getString("merging"));
  }
  public void setTask(String task){
    attacking = false;
    JSONObject jo = findJSONObject(gameData.getJSONArray("tasks"), task);
    String t="";
    if (!jo.isNull("description")){
      t += jo.getString("description")+"\n\n";
    }
    if (!jo.isNull("initial cost")){
      t += String.format("Initial Resource Cost:\n%s\n", getResourceList(jo.getJSONArray("initial cost")));
    }
    if(!jo.isNull("movement points")){
      t += String.format("Movement Points: %d\n",jo.getInt("movement points"));
    }
    if (!jo.isNull("action")){
      t += String.format("Turns: %d\n", jo.getJSONObject("action").getInt("turns"));
    }
    if (t.length()>2 && (t.charAt(t.length()-1)!='\n' || t.charAt(t.length()-2)!='\n'))
      t += "\n";
    if (!jo.isNull("production")){
      t += "Production/Turn/Unit:\n"+getResourceList(jo.getJSONArray("production"));
    }
    if (!jo.isNull("consumption")){
      t += "Consumption/Turn/Unit:\n"+getResourceList(jo.getJSONArray("consumption"));
    }
    //Strip
    setText(t.replaceAll("\\s+$", ""));
  }
  
  public void draw(PGraphics panelCanvas){
    if (visible && text.length() > 0){
      ArrayList<String> lines = getLines(text);
      panelCanvas.textFont(getFont(8*jsManager.loadFloatSetting("text scale")));
      int tw = ceil(maxWidthLine(lines))+4;
      int gap = ceil(panelCanvas.textAscent()+panelCanvas.textDescent());
      int th = ceil(panelCanvas.textAscent()+panelCanvas.textDescent())*lines.size();
      int tx = round(between(0, mouseX-xOffset-tw/2, width-tw));
      int ty = round(between(0, mouseY-yOffset+20, height-th-20));
      panelCanvas.fill(200, 230);
      panelCanvas.stroke(0);
      panelCanvas.rectMode(CORNER);
      panelCanvas.rect(tx, ty, tw, th);
      panelCanvas.fill(0);
      panelCanvas.textAlign(LEFT, TOP);
      for (int i=0; i<lines.size(); i++){
        panelCanvas.text(lines.get(i), tx+2, ty+i*gap);
      }
    }
  }
}

class NotificationManager extends Element{
  ArrayList<ArrayList<Notification>> notifications;
  int bgColour, textColour, displayNots, notHeight, topOffset, scroll, turn;
  Notification lastSelected;
  boolean scrolling;
  
  NotificationManager(int x, int y, int w, int h, int bgColour, int textColour, int displayNots, int turn){
    this.x = x;
    this.y = y;
    this.w = w;
    this.h = h;
    this.turn = turn;
    this.bgColour = bgColour;
    this.textColour = textColour;
    this.displayNots = displayNots;
    this.notHeight = h/displayNots;
    this.notifications = new ArrayList<ArrayList<Notification>>();
    notifications.add(new ArrayList<Notification>());
    notifications.add(new ArrayList<Notification>());
    this.scroll = 0;
    lastSelected = null;
    scrolling = false;
  }
  
  public boolean moveOver(){
    return mouseX-xOffset >= x && mouseX-xOffset <= x+w && mouseY-yOffset >= y && mouseY-yOffset <= y+h;
  }
  public boolean mouseOver(int i){
    return mouseX-xOffset >= x && mouseX-xOffset <= x+w && mouseY-yOffset >= y+notHeight*i+topOffset && mouseY-yOffset <= y+notHeight*(i+1)+topOffset;
  }
  public int findMouseOver(){
    if (!moveOver()){
      return -1;
    }
    for (int i=0; i<notifications.get(turn).size(); i++){
      if (mouseOver(i)){
        return i;
      }
    }
    return -1;
  }
  public boolean hoveringDismissAll(){
    return x<mouseX-xOffset&&mouseX-xOffset<x+notHeight&&y<mouseY-yOffset&&mouseY-yOffset<y+topOffset; 
  }
  
  public void turnChange(int turn){
    this.turn = turn;
    this.scroll = 0;
  }
  public void dismiss(int i){
    notifications.get(turn).remove(i);
    scroll = round(between(0, scroll, notifications.get(turn).size()-displayNots));
  }
  public void dismissAll(){
    // Dismisses all notification for the current player
    notifications.get(turn).clear();
  }
  public void reset(){
    // Clears all notificaitions for all players
    notifications.clear();
    notifications.add(new ArrayList<Notification>());
    notifications.add(new ArrayList<Notification>());
  }
  public void post(Notification n, int turn){
    notifications.get(turn).add(0, n);
  }
  public void post(String name, int x, int y, int turnNum, int turn){
    notifications.get(turn).add(0, new Notification(name, x, y, turnNum));
  }
  
  public ArrayList<String> mouseEvent(String eventType, int button, MouseEvent event){
    ArrayList<String> events = new ArrayList<String>();
    if (eventType == "mouseWheel"){
      float count = event.getCount();
      if (moveOver()){
        scroll = round(between(0, scroll+count, notifications.get(turn).size()-displayNots));
      }
    }
    return events;
  }
  public ArrayList<String> mouseEvent(String eventType, int button){
    ArrayList<String> events = new ArrayList<String>();
    if (eventType == "mousePressed"){
      if (moveOver() && mouseX-xOffset>x+w-20*jsManager.loadFloatSetting("gui scale") && mouseY-yOffset > topOffset && notifications.get(turn).size() > displayNots){
        scrolling = true;
        scroll = round(between(0, (mouseY-yOffset-y-topOffset)*(notifications.get(turn).size()-displayNots+1)/(h-topOffset), notifications.get(turn).size()-displayNots));
      }
      else{
        scrolling = false;
      }
    }
    if (eventType == "mouseDragged"){
      if (scrolling && notifications.get(turn).size() > displayNots){
        scroll = round(between(0, (mouseY-yOffset-y-topOffset)*(notifications.get(turn).size()-displayNots+1)/(h-topOffset), notifications.get(turn).size()-displayNots));
      }
      
    }
    if (eventType == "mouseClicked"){
      int hovering = findMouseOver();
      if (hovering >=0){
        if (mouseX-xOffset<x+notHeight){
          dismiss(hovering+scroll);
          events.add("notification dismissed");
        }
        else if (!(notifications.get(turn).size() > displayNots) || !(mouseX-xOffset>x+w-20*jsManager.loadFloatSetting("gui scale"))){
          lastSelected = notifications.get(turn).get(hovering+scroll);
          events.add("notification selected");
        }
      }
      else if (mouseX-xOffset<x+notHeight && hoveringDismissAll()){
        dismissAll();
      }
    }
    return events;
  }
  
  public boolean empty(){
    return notifications.get(turn).size() == 0;
  }
  
  public void draw(PGraphics panelCanvas){
    if (empty())return;
    panelCanvas.pushStyle();
    panelCanvas.fill(bgColour);
    panelCanvas.rect(x, y, w, h);
    panelCanvas.textFont(getFont(10*jsManager.loadFloatSetting("text scale")));
    panelCanvas.fill(brighten(bgColour, -50));
    topOffset = ceil(panelCanvas.textAscent()+panelCanvas.textDescent());
    this.notHeight = (h-topOffset)/displayNots;
    panelCanvas.rect(x, y, w, topOffset);
    panelCanvas.fill(textColour);
    panelCanvas.textAlign(CENTER, TOP);
    panelCanvas.text("Notification Manager", x+w/2, y);
    
    if (hoveringDismissAll()){
      panelCanvas.fill(brighten(bgColour, 80));
    }
    else{
      panelCanvas.fill(brighten(bgColour, -20));
    }
    panelCanvas.rect(x, y, notHeight, topOffset);
    panelCanvas.strokeWeight(3);
    panelCanvas.line(x+5, y+5, x+notHeight-5, y+topOffset-5);
    panelCanvas.line(x+notHeight-5, y+5, x+5, y+topOffset-5);
    panelCanvas.strokeWeight(1);
    
    int hovering = findMouseOver();
    for (int i=0; i<min(notifications.get(turn).size(), displayNots); i++){
      
      if (hovering == i){
        panelCanvas.fill(brighten(bgColour, 20));
      }
      else{
        panelCanvas.fill(brighten(bgColour, -10));
      }
      panelCanvas.rect(x, y+i*notHeight+topOffset, w, notHeight);
      
      panelCanvas.fill(brighten(bgColour, -20));
      if (mouseX-xOffset<x+notHeight){
        if (hovering == i){
          panelCanvas.fill(brighten(bgColour, 80));
        }
        else{
          panelCanvas.fill(brighten(bgColour, -20));
        }
      }
      panelCanvas.rect(x, y+i*notHeight+topOffset, notHeight, notHeight);
      panelCanvas.strokeWeight(3);
      panelCanvas.line(x+5, y+i*notHeight+topOffset+5, x+notHeight-5, y+(i+1)*notHeight+topOffset-5);
      panelCanvas.line(x+notHeight-5, y+i*notHeight+topOffset+5, x+5, y+(i+1)*notHeight+topOffset-5);
      panelCanvas.strokeWeight(1);
      
      panelCanvas.fill(textColour);
      panelCanvas.textFont(getFont(8*jsManager.loadFloatSetting("text scale")));
      panelCanvas.textAlign(LEFT, CENTER);
      panelCanvas.text(notifications.get(turn).get(i+scroll).name, x+notHeight+5, y+topOffset+i*notHeight+notHeight/2);
      panelCanvas.textAlign(RIGHT, CENTER);
      panelCanvas.text("Turn "+notifications.get(turn).get(i+scroll).turn, x-notHeight+w, y+topOffset+i*notHeight+notHeight/2);
    }
    
    //draw scroll
    int d = notifications.get(turn).size() - displayNots;
    if (d > 0){
      panelCanvas.fill(brighten(bgColour, 100));
      panelCanvas.rect(x-20*jsManager.loadFloatSetting("gui scale")+w, y+topOffset, 20*jsManager.loadFloatSetting("gui scale"), h-topOffset);
      panelCanvas.fill(brighten(bgColour, -20));
      panelCanvas.rect(x-20*jsManager.loadFloatSetting("gui scale")+w, y+(h-topOffset-(h-topOffset)/(d+1))*scroll/d+topOffset, 20*jsManager.loadFloatSetting("gui scale"), (h-topOffset)/(d+1));
    }
    panelCanvas.popStyle();
  }
}



class TextBox extends Element{
  int textSize, bgColour, textColour;
  String text;
  boolean autoSizing;
  
  TextBox(int x, int y, int w, int h, int textSize, String text, int bgColour, int textColour){
    //w=-1 means get width from text
    this.x = x;
    this.y = y;
    this.w = w;
    this.h = h;
    if (this.w == -1)
      autoSizing = true;
    else
      autoSizing = false;
    this.textSize = textSize;
    this.bgColour = bgColour;
    this.textColour = textColour;
    setText("");
  }
  
  public void setText(String text){
    this.text = text;
  }
  
  public void updateWidth(PGraphics panelCanvas){
    if (autoSizing){
      this.w = ceil(panelCanvas.textWidth(text))+10;
    }
  }
  
  public String getText(){
    return text;
  }
  
  public void setColour(int c){
    bgColour = c;
  }
  
  public void draw(PGraphics panelCanvas){
    panelCanvas.pushStyle();
    panelCanvas.textFont(getFont(textSize*jsManager.loadFloatSetting("text scale")));
    panelCanvas.textAlign(CENTER, CENTER);
    panelCanvas.rectMode(CORNER);
    updateWidth(panelCanvas);
    if (bgColour != color(255, 255)){
      panelCanvas.fill(bgColour);
      panelCanvas.rect(x, y, w, h);
    }
    panelCanvas.fill(textColour);
    panelCanvas.text(text, x+w/2, y+h/2);
    panelCanvas.popStyle();
  }
}



class ResourceSummary extends Element{
  float[] stockPile, net;
  String[] resNames;
  int numRes, scroll;
  boolean expanded;
  int[] timings;
  
  final int GAP = 10;
  final int FLASHTIMES = 500;
  
  ResourceSummary(int x, int y, int h, String[] resNames, float[] stockPile, float[] net){
    this.x = x;
    this.y = y;
    this.h = h;
    this.resNames = resNames;
    this.numRes = resNames.length;
    this.stockPile = stockPile;
    this.net = net;
    this.expanded = false;
    this.timings = new int[resNames.length];
  }
  
  public void updateStockpile(float[] v){
    stockPile = v;
  }
  public void updateNet(float[] v){
    net = v;
  }
  public void toggleExpand(){
    expanded = !expanded;
  }
  public String prefix(String v){
    float i = Float.parseFloat(v);
    if (i >= 1000000)
      return (new BigDecimal(v).divide(new BigDecimal("1000000"), 1, BigDecimal.ROUND_HALF_EVEN).stripTrailingZeros()).toPlainString()+"M";
    else if(i >= 1000)
      return (new BigDecimal(v).divide(new BigDecimal("1000"), 1, BigDecimal.ROUND_HALF_EVEN).stripTrailingZeros()).toPlainString()+"K";
      
    return (new BigDecimal(v).divide(new BigDecimal("1"), 1, BigDecimal.ROUND_HALF_EVEN).stripTrailingZeros()).toPlainString();
  }
  
  public String getResString(int i){
    return resNames[i];
  }
  public String getStockString(int i){
    String tempString = prefix(""+stockPile[i]);
    return tempString;
  }
  public String getNetString(int i){
    String tempString = prefix(""+net[i]);
    if (net[i] >= 0){
      return "+"+tempString;
    }
    return tempString;
  }
  public int columnWidth(int i){
    int m=0;
    textFont(getFont(10*jsManager.loadFloatSetting("text scale")));
    m = max(m, ceil(textWidth(getResString(i))));
    textFont(getFont(8*jsManager.loadFloatSetting("text scale")));
    m = max(m, ceil(textWidth(getStockString(i))));
    textFont(getFont(8*jsManager.loadFloatSetting("text scale")));
    m = max(m, ceil(textWidth(getNetString(i))));
    return m;
  }
  public int totalWidth(){
    int tot = 0;
    for (int i=numRes-1; i>=0; i--){
      if (gameData.getJSONArray("resources").getJSONObject(i).getInt("resource manager") <= ((expanded) ? 0:1)) continue;
        tot += columnWidth(i)+GAP;
    }
    return tot;
  }
  
  public void flash(int i){
    timings[i] = millis()+FLASHTIMES;
  }
  public int getFill(int i){
   if (timings[i] < millis()){
     return color(100);
    }
    return color(155*(timings[i]-millis())/FLASHTIMES+100, 100, 100);
  }
  
  public void draw(PGraphics panelCanvas){
    int cw = 0;
    int w, yLevel, tw = totalWidth();
    panelCanvas.pushStyle();
    panelCanvas.textAlign(LEFT, TOP);
    panelCanvas.fill(120);
    panelCanvas.rect(width-tw-x-GAP/2, y, tw, h);
    panelCanvas.rectMode(CORNERS);
    for (int i=numRes-1; i>=0; i--){
      if (gameData.getJSONArray("resources").getJSONObject(i).getInt("resource manager") <= ((expanded) ? 0:1)) continue;
      w = columnWidth(i);
      panelCanvas.fill(getFill(i));
      panelCanvas.textFont(getFont(10*jsManager.loadFloatSetting("text scale")));
      panelCanvas.rect(width-cw+x-GAP/2, y, width-cw+x-GAP/2-(w+GAP), y+panelCanvas.textAscent()+panelCanvas.textDescent());
      cw += w+GAP;
      panelCanvas.line(width-cw+x-GAP/2, y, width-cw+x-GAP/2, y+h);
      panelCanvas.fill(0);
      
      yLevel=0;
      panelCanvas.textFont(getFont(10*jsManager.loadFloatSetting("text scale")));
      panelCanvas.text(getResString(i), width-cw, y);
      yLevel += panelCanvas.textAscent()+panelCanvas.textDescent();
      
      panelCanvas.textFont(getFont(8*jsManager.loadFloatSetting("text scale")));
      panelCanvas.text(getStockString(i), width-cw, y+yLevel);
      yLevel += panelCanvas.textAscent()+panelCanvas.textDescent();
      
      if (net[i] < 0)
        panelCanvas.fill(255,0,0);
      else
        panelCanvas.fill(0,255,0);
      panelCanvas.textFont(getFont(8*jsManager.loadFloatSetting("text scale")));
      panelCanvas.text(getNetString(i), width-cw, y+yLevel);
      yLevel += panelCanvas.textAscent()+panelCanvas.textDescent();
    }
    panelCanvas.popStyle();
  }
}



class TaskManager extends Element{
  ArrayList<String> options;
  ArrayList<Integer> availableOptions;
  int textSize;
  boolean dropped, taskMActive;
  int bgColour, strokeColour;
  private final int HOVERINGOFFSET = 80, ONOFFSET = -50;
  TaskManager(int x, int y, int w, int textSize, int bgColour, int strokeColour, String[] options){
    this.x = x;
    this.y = y;
    this.w = w;
    this.textSize = textSize;
    this.h = 10;
    this.bgColour = bgColour;
    this.strokeColour = strokeColour;
    removeAllOptions();
    for (String option : options){
      this.options.add(option);
    }
    dropped = true;
    resetAvailable();
    taskMActive = true;
  }
  public void setOptions(ArrayList<String> options){
    this.options = options;
  }
  public void addOption(String option){
    this.options.add(option);
  }
  public void removeOption(String option){
    for (int i=0; i <options.size(); i++){
      if (option.equals(options.get(i))){
        options.remove(i);
      }
    }
  }
  public void removeAllOptions(){
    this.options = new ArrayList<String>();
  }
  public void resetAvailable(){
    this.availableOptions = new ArrayList<Integer>();
  }
  public String getSelected(){
    return options.get(availableOptions.get(0));
  }
  public void makeAvailable(String option){
    for (int i=0; i<availableOptions.size(); i++){
      if (options.get(availableOptions.get(i)).equals(option)){
        return;
      }
    }
    for (int i=0; i<options.size(); i++){
      if (options.get(i).equals(option)){
        this.availableOptions.add(i);
        return;
      }
    }
  }
  public void makeUnavailable(String option){
    for (int i=0; i<options.size(); i++){
      if (options.get(i).equals(option)){
        this.availableOptions.remove(i);
        return;
      }
    }
  }
  public void selectAt(int j){
    int temp = availableOptions.get(0);
    availableOptions.set(0, availableOptions.get(j));
    availableOptions.set(j, temp);
  }
  public void select(String s){
    for (int j=0; j<availableOptions.size(); j++){
      if (options.get(availableOptions.get(j)).equals(s)){
        selectAt(j);
      }
    }
  }
  public int getH(PGraphics panelCanvas){
    textFont(getFont(textSize*jsManager.loadFloatSetting("text scale")));
    return ceil(panelCanvas.textAscent() + panelCanvas.textDescent());
  }
  public boolean optionAvailable(int i){
    for (int option : availableOptions){
      if(option == i){
        return true;
      }
    }
    return false;
  }
  public void draw(PGraphics panelCanvas){
    panelCanvas.pushStyle();
    h = getH(panelCanvas);
    panelCanvas.fill(brighten(bgColour, ONOFFSET));
    panelCanvas.stroke(strokeColour);
    panelCanvas.rect(x, y, w, h);
    panelCanvas.fill(0);
    panelCanvas.textAlign(LEFT, TOP);
    panelCanvas.text("Current Task: "+options.get(availableOptions.get(0)), x+5, y);
    
    if (dropped){
      for (int j=1; j< availableOptions.size(); j++){
        if (taskMActive && mouseOver(j)){
          panelCanvas.fill(brighten(bgColour, HOVERINGOFFSET));
        }
        else{
          panelCanvas.fill(bgColour);
        }
        panelCanvas.rect(x, y+h*j, w, h);
        panelCanvas.fill(0);
        panelCanvas.text(options.get(availableOptions.get(j)), x+5, y+h*j);
      }
    }
    panelCanvas.popStyle();
  }
  
  public ArrayList<String> mouseEvent(String eventType, int button){
    ArrayList<String> events = new ArrayList<String>();
    if (eventType == "mouseMoved"){
      taskMActive = moveOver();
      
    }
    if (eventType == "mouseClicked" && button == LEFT){
      for (int j=1; j < availableOptions.size();j++){
        if (mouseOver(j)){
          selectAt(j);
          events.add("valueChanged");
        }
      }
    }
    return events;
  }
  
  public String findMouseOver(){
    for (int j=0; j<availableOptions.size(); j++){
      if (mouseX-xOffset >= x && mouseX-xOffset <= x+w && mouseY-yOffset >= y+h*j && mouseY-yOffset <= y+h*(j+1))
        return options.get(availableOptions.get(j));
    }
    return "";
  }
  
  public boolean moveOver(){
    return mouseX-xOffset >= x && mouseX-xOffset <= x+w && mouseY-yOffset >= y && mouseY-yOffset <= y+h*availableOptions.size();
  }
  public boolean mouseOver(int j){
    return mouseX-xOffset >= x && mouseX-xOffset <= x+w && mouseY-yOffset >= y+h*j && mouseY-yOffset <= y+h*(j+1);
  }
}





class Button extends Element{
  private int x, y, w, h, cx, cy, textSize, textAlign;
  private int bgColour, strokeColour, textColour;
  private String state, text;
  private final int HOVERINGOFFSET = 80, ONOFFSET = -50;
  private ArrayList<String> lines;
  
  Button(int x, int y, int w, int h, int bgColour, int strokeColour, int textColour, int textSize, int textAlign, String text){
    state = "off";
    this.x = x;
    this.y = y;
    this.w = w;
    this.h = h;
    this.bgColour = bgColour;
    this.strokeColour = strokeColour;
    this.textColour = textColour;
    this.textSize = textSize;
    this.textAlign = textAlign;
    this.text = text;
    centerCoords();
    
    setLines(text);
  }
  public void transform(int x, int y, int w, int h){
    this.x = x;
    this.y = y;
    this.w = w;
    this.h = h;
    centerCoords();
  }
  public void centerCoords(){
    cx = x+w/2;
    cy = y+h/2;
  }
  public void setText(String text){
    this.text = text;
    setLines(text);
  }
  public void setColour(int colour){
    this.bgColour = colour;
  }
  public String getText(){
    return this.text;
  }
  public void draw(PGraphics panelCanvas){
    //println(xOffset, yOffset);
    int padding=0;
    float r = red(bgColour), g = green(bgColour), b = blue(bgColour);
    panelCanvas.pushStyle();
    panelCanvas.fill(bgColour);
    if (state == "off"){
      panelCanvas.fill(bgColour);
    }
    else if (state == "hovering"){
      panelCanvas.fill(min(r+HOVERINGOFFSET, 255), min(g+HOVERINGOFFSET, 255), min(b+HOVERINGOFFSET, 255));
    }
    else if (state == "on"){
      panelCanvas.fill(min(r+ONOFFSET, 255), min(g+ONOFFSET, 255), min(b+ONOFFSET, 255));
    }
    panelCanvas.stroke(strokeColour);
    panelCanvas.strokeWeight(3);
    panelCanvas.rect(x, y, w, h);
    panelCanvas.noTint();
    panelCanvas.fill(textColour);
    panelCanvas.textAlign(textAlign, TOP);
    panelCanvas.textFont(getFont(textSize*jsManager.loadFloatSetting("text scale")));
    if (lines.size() == 1){
      padding = h/10;
    }
    padding = (lines.size()*(int)(textSize*jsManager.loadFloatSetting("text scale"))-h/2)/2;
    for (int i=0; i<lines.size(); i++){
      if (textAlign == CENTER){
        panelCanvas.text(lines.get(i), cx, y+(h*0.9f-textSize*jsManager.loadFloatSetting("text scale"))/2);
      }
      else{
        panelCanvas.text(lines.get(i), x, y );
      }
    }
    panelCanvas.popStyle();
  }
  
  public ArrayList<String> setLines(String s){
    int j = 0;
    lines = new ArrayList<String>();
    for (int i=0; i<s.length(); i++){
      if(s.charAt(i) == '\n'){
        lines.add(s.substring(j, i));
        j=i+1;
      }
    }
    lines.add(s.substring(j, s.length()));
    
    return lines;
  }
  
  public ArrayList<String> mouseEvent(String eventType, int button){
    ArrayList<String> events = new ArrayList<String>();
    if(eventType == "mouseReleased"){
      if (state == "on"){
        events.add("clicked");
      }
      state = "off";
    }
    if (mouseOver()){
      if (!state.equals("on")){
        state = "hovering";
      }
      if (eventType == "mousePressed"){
        state = "on";
        if(jsManager.loadBooleanSetting("sound on")){
          sfx.get("click3").play();
        }
      }
    }
    else{
      state = "off";
    }
    return events;
  }
  
  public Boolean mouseOver(){
    return mouseX-xOffset >= x && mouseX-xOffset <= x+w && mouseY-yOffset >= y && mouseY-yOffset <= y+h;
  }
}





class Slider extends Element{
  private int x, y, w, h, cx, cy, major, minor, lw, lx;
  private int padding = 20;
  private BigDecimal value, step, upper, lower;
  private float knobSize;
  private int KnobColour, bgColour, strokeColour, scaleColour;
  private boolean horizontal, pressed=false;
  final int boxHeight = 20, boxWidth = 10;
  private final int PRESSEDOFFSET = 50;
  private String name;
  boolean visible = true;
  
  Slider(int x, int y, int w, int h, int KnobColour, int bgColour, int strokeColour, int scaleColour, float lower, float value, float upper, int major, int minor, float step, boolean horizontal, String name){
    this.lx = x;
    this.x = x;
    this.y = y;
    this.lw = w;
    this.w = w;
    this.h = h;
    this.KnobColour = KnobColour;
    this.bgColour = bgColour;
    this.strokeColour = strokeColour;
    this.scaleColour = scaleColour;
    this.major = major;
    this.minor = minor;
    this.upper = new BigDecimal(""+upper);
    this.lower = new BigDecimal(""+lower);
    this.horizontal = horizontal;
    this.step = new BigDecimal(""+step);
    this.value = new BigDecimal(""+value);
    this.name = name;
  }
  public void show(){
    visible = true;
  }
  public void hide(){
    visible = false;
  }
  public void scaleKnob(PGraphics panelCanvas, BigDecimal value){
    panelCanvas.textFont(getFont(8*jsManager.loadFloatSetting("text scale")));
    this.knobSize = max(this.knobSize, panelCanvas.textWidth(""+getInc(value)));
  }
  public void transform(int x, int y, int w, int h){
    this.lx = x;
    this.x = x;
    this.lw = w;
    this.w = w; 
    this.y = y;
    this.h = h;
  }
  public void setScale(float lower, float value, float upper, int major, int minor){
    this.major = major;
    this.minor = minor;
    this.upper = new BigDecimal(""+upper);
    this.lower = new BigDecimal(""+lower);
    this.value = new BigDecimal(""+value);
  }
  public void setValue(float value){
    setValue(new BigDecimal(""+value));
  }
  
  public void setValue(BigDecimal value){
    if (value.compareTo(lower) < 0){
      this.value = lower;
    }
    else if (value.compareTo(upper)>0){
      this.value = new BigDecimal(""+upper);
    }
    else{
      this.value = value.divideToIntegralValue(step).multiply(step);
    }
  }
  
  public float getValue(){
    return value.floatValue();
  }
  public BigDecimal getPreciseValue(){
    return value;
  }
  
  public ArrayList<String> mouseEvent(String eventType, int button){
    ArrayList<String> events = new ArrayList<String>();
    if (button == LEFT){
      if (mouseOver() && eventType == "mousePressed"){
          pressed = true;
          setValue((new BigDecimal(mouseX-xOffset-x)).divide(new BigDecimal(w), 15, BigDecimal.ROUND_HALF_EVEN).multiply(upper.subtract(lower)).add(lower));
          events.add("valueChanged");
      }
      else if (eventType == "mouseReleased"){
        pressed = false;
      }
      if (eventType == "mouseDragged" && pressed){
        setValue((new BigDecimal(mouseX-xOffset-x)).divide(new BigDecimal(w), 15, BigDecimal.ROUND_HALF_EVEN).multiply(upper.subtract(lower)).add(lower));
        events.add("valueChanged");
      }
    }
    return events;
  }
  
  public Boolean mouseOver(){
    BigDecimal range = upper.subtract(lower);
    int xKnobPos = round(x+(value.floatValue()/range.floatValue()*w-lower.floatValue()*w/range.floatValue())-knobSize/2);
    return (mouseX-xOffset >= x && mouseX-xOffset <= x+w && mouseY-yOffset >= y && mouseY-yOffset <= y+h) ||
    (mouseX-xOffset >= xKnobPos && mouseX-xOffset <= xKnobPos+knobSize && mouseY-yOffset >= y && mouseY-yOffset <= y+h); // Over slider or knob box
  }
  
  public BigDecimal getInc(BigDecimal i){
    return i.stripTrailingZeros();
  }
  
  public void draw(PGraphics panelCanvas){
    if (!visible)return;
    BigDecimal range = upper.subtract(lower);
    float r = red(KnobColour), g = green(KnobColour), b = blue(KnobColour);
    panelCanvas.pushStyle();
    panelCanvas.fill(255, 100);
    panelCanvas.stroke(strokeColour, 50);
    //rect(lx, y, lw, h);
    //rect(xOffset+x, y+yOffset+padding+2, w, h-padding);
    panelCanvas.stroke(strokeColour);
    
    
    for(int i=0; i<=minor; i++){
      panelCanvas.fill(scaleColour);
      panelCanvas.line(x+w*i/minor, y+padding+(h-padding)/6, x+w*i/minor, y+5*(h-padding)/6+padding);
    }
    for(int i=0; i<=major; i++){
      panelCanvas.fill(scaleColour);
      panelCanvas.textFont(getFont(10*jsManager.loadFloatSetting("text scale")));
      panelCanvas.textAlign(CENTER);
      panelCanvas.text(getInc((new BigDecimal(""+i).multiply(range).divide(new BigDecimal(""+major), 15, BigDecimal.ROUND_HALF_EVEN).add(lower))).toPlainString(), x+w*i/major, y+padding);
      panelCanvas.line(x+w*i/major, y+padding, x+w*i/major, y+h);
    }
    
    if (pressed){
      panelCanvas.fill(min(r-PRESSEDOFFSET, 255), min(g-PRESSEDOFFSET, 255), min(b+PRESSEDOFFSET, 255));
    }
    else{
      panelCanvas.fill(KnobColour);
    }
    
    panelCanvas.textFont(getFont(8*jsManager.loadFloatSetting("text scale")));
    panelCanvas.textAlign(CENTER);
    panelCanvas.rectMode(CENTER);
    scaleKnob(panelCanvas, value);
    panelCanvas.rect(x+value.floatValue()/range.floatValue()*w-lower.floatValue()*w/range.floatValue(), y+h/2+padding/2, knobSize, boxHeight);
    panelCanvas.rectMode(CORNER);
    panelCanvas.fill(scaleColour);
    panelCanvas.text(getInc(value).toPlainString(), x+value.floatValue()/range.floatValue()*w-lower.floatValue()*w/range.floatValue(), y+h/2+boxHeight/4+padding/2);
    panelCanvas.stroke(0);
    panelCanvas.textAlign(CENTER);
    panelCanvas.stroke(255, 0, 0);
    panelCanvas.line(x+value.floatValue()/range.floatValue()*w-lower.floatValue()*w/range.floatValue(), y+h/2-boxHeight/2+padding/2, x+value.floatValue()/range.floatValue()*w-lower.floatValue()*w/range.floatValue(), y+h/2-boxHeight+padding/2);
    panelCanvas.stroke(0);
    panelCanvas.fill(0);
    panelCanvas.textFont(getFont(10*jsManager.loadFloatSetting("text scale")));
    panelCanvas.textAlign(LEFT, BOTTOM);
    panelCanvas.text(name, x, y);
    panelCanvas.popStyle();
  }
}




class Text extends Element{
  int x, y, size, colour, align;
  PFont font;
  String text;
  
  Text(int x, int y,  int size, String text, int colour, int align){
    this.x = x;
    this.y = y;
    this.size = size;
    this.text = text;
    this.colour = colour;
    this.align = align;
  }
  public void translate(int x, int y){
    this.x = x;
    this.y = y;
  }
  public void setText(String text){
    this.text = text;
  }
  public void calcSize(PGraphics panelCanvas){
    panelCanvas.textFont(getFont(size*jsManager.loadFloatSetting("text scale")));
    this.w = ceil(panelCanvas.textWidth(text));
    this.h = ceil(panelCanvas.textAscent()+panelCanvas.textDescent());
  }
  public void draw(PGraphics panelCanvas){
    calcSize(panelCanvas);
    if (font != null){
      panelCanvas.textFont(font);
    }
    panelCanvas.textAlign(align, TOP);
    panelCanvas.textFont(getFont(size*jsManager.loadFloatSetting("text scale")));
    panelCanvas.fill(colour);
    panelCanvas.text(text, x, y);
  }
  public boolean mouseOver(){
    return mouseX-xOffset >= x && mouseX-xOffset <= x+w && mouseY-yOffset >= y && mouseY-yOffset <= y+h;
  }
}





class TextEntry extends Element{
  StringBuilder text;
  int x, y, w, h, textSize, textAlign, cursor, selected;
  int textColour, boxColour, borderColour, selectionColour;
  String allowedChars, name;
  final int BLINKTIME = 500;
  boolean texActive;
  
  TextEntry(int x, int y, int w, int h, int textAlign, int textColour, int boxColour, int borderColour, String allowedChars){
    this.x = x;
    this.y = y;
    this.h = h;
    this.w = w;
    this.textColour = textColour;
    this.textSize = 10;
    this.textAlign = textAlign;
    this.boxColour = boxColour;
    this.borderColour = borderColour;
    this.allowedChars = allowedChars;
    text = new StringBuilder();
    selectionColour = brighten(selectionColour, 150);
    texActive = false;
  }
  TextEntry(int x, int y, int w, int h, int textAlign, int textColour, int boxColour, int borderColour, String allowedChars, String name){
    this.x = x;
    this.y = y;
    this.h = h;
    this.w = w;
    this.textColour = textColour;
    this.textSize = 20;
    this.textAlign = textAlign;
    this.boxColour = boxColour;
    this.borderColour = borderColour;
    this.allowedChars = allowedChars;
    this.name = name;
    text = new StringBuilder();
    selectionColour = brighten(selectionColour, 150);
    texActive = false;
  }
  
  public void setText(String t){
    this.text = new StringBuilder(t);
  }
  public String getText(){
    return this.text.toString();
  }
  
  public void draw(PGraphics panelCanvas){
    boolean showCursor = ((millis()/BLINKTIME)%2==0 || keyPressed) && texActive;
    panelCanvas.pushStyle();
    
    // Draw a box behind the text
    panelCanvas.fill(boxColour);
    panelCanvas.stroke(borderColour);
    panelCanvas.rect(x, y, w, h);
    panelCanvas.textFont(getFont(textSize*jsManager.loadFloatSetting("text scale")));
    panelCanvas.textAlign(textAlign);
    // Draw selection box
    if (selected != cursor && texActive && cursor >= 0 ){
      panelCanvas.fill(selectionColour);
      panelCanvas.rect(x+panelCanvas.textWidth(text.substring(0, min(cursor, selected)))+5, y+2, panelCanvas.textWidth(text.substring(min(cursor, selected), max(cursor, selected))), h-4);
    }
    
    // Draw the text
    panelCanvas.textFont(getFont(textSize*jsManager.loadFloatSetting("text scale")));
    panelCanvas.textAlign(textAlign);
    panelCanvas.fill(textColour);
    panelCanvas.text(text.toString(), x+5, y+(h-textSize*jsManager.loadFloatSetting("text scale"))/2, w, h);
    
    // Draw cursor
    if (showCursor){
      panelCanvas.fill(0);
      panelCanvas.noStroke();
      panelCanvas.rect(x+panelCanvas.textWidth(text.toString().substring(0,cursor))+5, y+(h-textSize*jsManager.loadFloatSetting("text scale"))/2, 1, textSize*jsManager.loadFloatSetting("text scale"));
    }
    if (name != null){
      panelCanvas.fill(0);
      panelCanvas.textFont(getFont(10*jsManager.loadFloatSetting("text scale")));
      panelCanvas.textAlign(LEFT);
      panelCanvas.text(name, x, y-12);
    }
    
    panelCanvas.popStyle();
  }
  
  public void resetSelection(){
    selected = cursor;
  }
  public void transform(int x, int y, int w, int h){
    this.x = x;
    this.y = y;
    this.w = w;
    this.h = h;
  }
  
  public int getCursorPos(int mx, int my){
    int i=0;
    for(; i<text.length(); i++){
      textFont(getFont(textSize*jsManager.loadFloatSetting("text scale")));
      if ((textWidth(text.substring(0, i)) + textWidth(text.substring(0, i+1)))/2 + x > mx)
        break;
    }
    if (0 <= i && i <= text.length() && y+(h-textSize*jsManager.loadFloatSetting("text scale"))/2<= my && my <= y+(h-textSize*jsManager.loadFloatSetting("text scale"))/2+textSize*jsManager.loadFloatSetting("text scale")){
      return i;
    }
    return cursor;
  }
  
  public void doubleSelectWord(){
    if (!(y <= mouseY-yOffset && mouseY-yOffset <= y+h)){
      return;
    }
    int c = getCursorPos(mouseX-xOffset, mouseY-yOffset);
    int i;
    for (i=min(c, text.length()-1); i>0; i--){
      if (text.charAt(i) == ' '){
        i++;
        break;
      }
    }
    cursor = (int)between(0, i, text.length());
    for (i=c; i<text.length(); i++){
      if (text.charAt(i) == ' '){
        break;
      }
    }
    selected = i;
  }
  
  public ArrayList<String> mouseEvent(String eventType, int button){
    ArrayList<String> events = new ArrayList<String>();
    if (eventType == "mouseClicked"){
      if (button == LEFT){
        if (mouseOver()){
          texActive = true;
        }
      }
    }
    else if (eventType == "mousePressed"){
      if (button == LEFT){
        cursor = round(between(0, getCursorPos(mouseX-xOffset, mouseY-yOffset), text.length()));
        selected = getCursorPos(mouseX-xOffset, mouseY-yOffset);
      }
      if(!mouseOver()){
        texActive = false;
      }
    }
    else if (eventType == "mouseDragged"){
      if (button == LEFT){
        selected = getCursorPos(mouseX-xOffset, mouseY-yOffset);
      }
    }
    else if (eventType == "mouseDoubleClicked"){
      doubleSelectWord();
    }
    return events;
  }
  
  public ArrayList<String> keyboardEvent(String eventType, char _key){
    ArrayList<String> events = new ArrayList<String>();
    if (texActive){
      if (eventType == "keyTyped"){
        if (allowedChars.equals("") || allowedChars.contains(""+_key)){
          if (cursor != selected){
            text = new StringBuilder(text.substring(0, min(cursor, selected)) + text.substring(max(cursor, selected), text.length()));
            cursor = min(cursor, selected);
            resetSelection();
          }
          text.insert(cursor++, _key);
          resetSelection();
        }
      }
      else if (eventType == "keyPressed"){
        if (_key == '\n'){
          events.add("enterPressed");
          texActive = false;
        }
        if (_key == BACKSPACE){
          if (selected == cursor){
            if (cursor > 0){
              text.deleteCharAt(--cursor);
              resetSelection();
            }
          }
          else{
            text = new StringBuilder(text.substring(0, min(cursor, selected)) + text.substring(max(cursor, selected), text.length()));
            cursor = min(cursor, selected);
            resetSelection();
          }
        }
        if (_key == CODED){
          if (keyCode == LEFT){
            cursor = max(0, cursor-1);
            resetSelection();
          }
          if (keyCode == RIGHT){
            cursor = min(text.length(), cursor+1);
            resetSelection();
          }
        }
      }
    }
    return events;
  }
  
  public Boolean mouseOver(){
    return mouseX-xOffset >= x && mouseX-xOffset <= x+w && mouseY-yOffset >= y && mouseY-yOffset <= y+h;
  }
}





class ToggleButton extends Element{
  int bgColour, strokeColour;
  String name;
  boolean on;
  ToggleButton(int x, int y, int w, int h, int bgColour, int strokeColour, boolean value, String name){
    this.x = x;
    this.y = y;
    this.w = w;
    this.h = h;
    this.bgColour = bgColour;
    this.strokeColour = strokeColour;
    this.name = name;
    this.on = value;
  }
  public ArrayList<String> mouseEvent(String eventType, int button){
    ArrayList<String> events = new ArrayList<String>();
    if (eventType == "mouseClicked"&&mouseOver()){
      events.add("valueChanged");
      print(1);
      on = !on;
    }
    return events;
  }
  public void transform(int x, int y, int w, int h){
    this.x = x;
    this.y = y;
    this.w = w;
    this.h = h;
  }
  public boolean getState(){
    return on;
  }
  public void setState(boolean state){
    on = state;
  }
  public void draw(PGraphics panelCanvas){
    panelCanvas.pushStyle();
    panelCanvas.fill(bgColour);
    panelCanvas.stroke(strokeColour);
    panelCanvas.rect(x, y, w, h);
    if (on){
      panelCanvas.fill(0, 255, 0);
      panelCanvas.rect(x, y, w/2, h);
    }
    else{
      panelCanvas.fill(255, 0, 0);
      panelCanvas.rect(x+w/2, y, w/2, h);
    }
    panelCanvas.fill(0);
    panelCanvas.textFont(getFont(8*jsManager.loadFloatSetting("text scale")));
    panelCanvas.textAlign(LEFT, BOTTOM);
    panelCanvas.text(name, x, y);
    panelCanvas.popStyle();
  }
  public Boolean mouseOver(){
    return mouseX-xOffset >= x && mouseX-xOffset <= x+w && mouseY-yOffset >= y && mouseY-yOffset <= y+h;
  }
}

class Notification{
  String name;
  int x, y, turn;
  Notification(String name, int x, int y, int turn){
    this.x = x;
    this.y = y;
    this.name = name;
    this.turn = turn;
  }
}

class Event{
  String id, type, panel;
  Event(String id, String panel, String type){
    this.id = id;
    this.type = type;
    this.panel = panel;
  }
  public String info(){
    return "id:"+id+", type:"+type+", panel:"+panel;
  }
}


class Action{
  float turns, initialTurns;
  int type;
  String notification, terrain, building;
  Action(int type, String notification, float turns, String building, String terrain){
    this.type = type;
    this.turns = turns;
    this.notification = notification;
    this.building = building;
    this.terrain = terrain;
    initialTurns = turns;
  }
}

//Events
//Move sx sy ex ey
//Split sx sy ex ey num
//ChangeTask sx sy task
//

class GameEvent{
  String type;
}

class Move extends GameEvent{
  int startX, startY, endX, endY;
  Move(int startX, int startY, int endX, int endY){
    this.startX = startX;
    this.startY = startY;
    this.endX = endX;
    this.endY = endY;
  }
}

class Split extends GameEvent{
  int startX, startY, endX, endY, units;
  Split(int startX, int startY, int endX, int endY, int units){
    this.startX = startX;
    this.startY = startY;
    this.endX = endX;
    this.endY = endY;
    this.units = units;
  }

}

class ChangeTask extends GameEvent{
  int x, y;
  int task;
  ChangeTask(int x, int y, int task){
    this.x = x;
    this.y = y;
    this.task = task;
  }
}

class EndTurn extends GameEvent{

}


class JSONManager{
  JSONObject menu, gameData, settings;
  
  JSONManager(){
    try{
      menu = loadJSONObject("menu.json");
      gameData = loadJSONObject("data.json");
      
      try{
        settings = loadJSONObject("settings.json");
      }
      catch (Exception e){
        println("creating new settings file");
        PrintWriter w = createWriter("data/settings.json");
        w.print("{}\n");
        w.flush();
        w.close();
        println("Finished creating new settings file");
        settings = loadJSONObject("settings.json");
        println("loading settings... ");
        loadDefaultSettings();
      }
      loadInitialSettings();
    }
    catch(Exception e){
      println("Error loading JSON");
      println(e);
    }
  }
  
  public void saveSetting(String id, int val){
    // Save the setting to settings and write settings to file
    settings.setInt(id, val);
  }
  
  public void saveSetting(String id, float val){
    // Save the setting to settings and write settings to file
    settings.setFloat(id, val);
  }
  
  public void saveSetting(String id, String val){
    // Save the setting to settings and write settings to file
    settings.setString(id, val);
  }
  
  public void saveSetting(String id, boolean val){
    // Save the setting to settings and write settings to file
    settings.setBoolean(id, val);
  }
  
  public void writeSettings(){
    saveJSONObject(settings, "data/settings.json");
  }
  
  public boolean hasFlag(String panelID, String elemID, String flag){
    try{
      JSONObject panel = findJSONObject(menu.getJSONArray("states"), panelID);
      JSONObject elem = findJSONObject(panel.getJSONArray("elements"), elemID);
      JSONArray flags = elem.getJSONArray("flags");
      if (flags != null){
        for (int i=0; i<flags.size(); i++){
          if (flags.getString(i).equals(flag)){
            return true;
          }
        }
      }
    }
    catch (Exception e){
      
    }
    return false;
  }
  
  public void loadDefaultSettings(){
    // Reset all the settings to their default values
    JSONArray defaultSettings = menu.getJSONArray("default settings");
    for (int i=0; i<defaultSettings.size(); i++){
      JSONObject setting = defaultSettings.getJSONObject(i);
      if (setting.getString("type").equals("int")){
        saveSetting(setting.getString("id"), setting.getInt("value"));
      }
      else if (setting.getString("type").equals("float")){
        saveSetting(setting.getString("id"), setting.getFloat("value"));
      }
      else if (setting.getString("type").equals("string")){
        saveSetting(setting.getString("id"), setting.getString("value"));
      }
      else if (setting.getString("type").equals("boolean")){
        saveSetting(setting.getString("id"), setting.getBoolean("value"));
      }
      else{
        print("invalid setting type");
      }
    }
  }
  
  public void loadInitialSettings(){
    // Set all the settings to either the default value, or the value already set
    JSONArray defaultSettings = menu.getJSONArray("default settings");
    for (int i=0; i<defaultSettings.size(); i++){
      JSONObject setting = defaultSettings.getJSONObject(i);
      if (settings.get(setting.getString("id")) == null){
        if (setting.getString("type").equals("int")){
          saveSetting(setting.getString("id"), setting.getInt("value"));
        }
        else if (setting.getString("type").equals("float")){
          saveSetting(setting.getString("id"), setting.getFloat("value"));
        }
        else if (setting.getString("type").equals("string")){
          saveSetting(setting.getString("id"), setting.getString("value"));
        }
        else if (setting.getString("type").equals("boolean")){
          saveSetting(setting.getString("id"), setting.getBoolean("value"));
        }
        else{
          print("invalid setting type");
        }
      }
    }
    writeSettings();
  }
  
  public int loadIntSetting(String id){
    // Load a setting that is an int
    return  settings.getInt(id);
  }
  
  public float loadFloatSetting(String id){
    // Load a setting that is an float
    return  settings.getFloat(id);
  }
  
  public String loadStringSetting(String id){
    // Load a setting that is an string
    return  settings.getString(id);
  }
  
  public boolean loadBooleanSetting(String id){
    // Load a setting that is an string
    return  settings.getBoolean(id);
  }
  
  public JSONObject findJSONObject(JSONArray j, String id){
    // search for a json object in a json array with correct id
    for (int i=0; i<j.size(); i++){
      if (j.getJSONObject(i).getString("id").equals(id)){
        return j.getJSONObject(i);
      }
    }
    return null;
  }
  
  public String getElementType(String panel, String element){
    JSONArray elems = findJSONObject(menu.getJSONArray("states"), panel).getJSONArray("elements");
    return findJSONObject(elems, element).getString("type");
  }
  
  public HashMap<String, String[]> getChangeStateButtons(){
    // Store all the buttons that when clicked change the state
    HashMap returnHash = new HashMap<String, String[]>();
     JSONArray panels = menu.getJSONArray("states");
     for (int i=0; i<panels.size(); i++){
       JSONObject panel = panels.getJSONObject(i);
       JSONArray panelElems = panel.getJSONArray("elements");
       for (int j=0; j<panelElems.size(); j++){
         if (!panelElems.getJSONObject(j).isNull("new state")){
           returnHash.put(panelElems.getJSONObject(j).getString("id"), new String[]{panelElems.getJSONObject(j).getString("new state"), panel.getString("id")});
         }
       }
     }
    return returnHash;
  }
  
  public HashMap<String, String[]> getChangeSettingButtons(){
    // Store all the buttons that when clicked change a setting
    HashMap returnHash = new HashMap<String, String[]>();
    JSONArray panels = menu.getJSONArray("states");
    for (int i=0; i<panels.size(); i++){
      JSONObject panel = panels.getJSONObject(i);
      JSONArray panelElems = panel.getJSONArray("elements");
      for (int j=0; j<panelElems.size(); j++){
        if (!panelElems.getJSONObject(j).isNull("setting")){
          returnHash.put(panelElems.getJSONObject(j).getString("id"), new String[]{panelElems.getJSONObject(j).getString("setting"), panel.getString("id")});
        }
      }
    }
  return returnHash;
  }
  
  public String getSettingName(String id, String panelID){
    // Gets the name of the setting for an element or null if it doesnt have a settting
    JSONObject panel = findJSONObject(menu.getJSONArray("states"), panelID);
    JSONObject element = findJSONObject(panel.getJSONArray("elements"), id);
    return element.getString("setting");
  }
  public String menuStateTitle(String id){
    // Gets the titiel for menu state. Reutnrs null if there is no title defined
    JSONObject panel = findJSONObject(menu.getJSONArray("states"), id);
    return panel.getString("title");
  }
  
  public void loadMenuElements(State state, float guiScale){
    // Load all the menu panels in to menu state
     JSONArray panels = menu.getJSONArray("states");
     for (int i=0; i<panels.size(); i++){
       JSONObject panel = panels.getJSONObject(i);
       state.addPanel(panel.getString("id"), 0, 0, width, height, true, true, color(255, 255, 255, 255), color(0));
       loadPanelMenuElements(state, panel.getString("id"), guiScale);
     }
  }
  
  public void loadPanelMenuElements(State state, String panelID, float guiScale){
    // Load in the elements from JSON menu into panel
    // NOTE: "default value" in elements object means value is not saved to setting (and if not defined will be saved)
    
    int bgColour, strokeColour, textColour, textSize, major, minor;
    float x, y, w, h, scale, lower, defaultValue, upper, step;
    String type, id, text, setting;
    String[] options;
    JSONArray elements = findJSONObject(menu.getJSONArray("states"), panelID).getJSONArray("elements");
    
    
    scale = 20 * guiScale;
    
    for (int i=0; i<elements.size(); i++){
      JSONObject elem = elements.getJSONObject(i);
      
      // Transform the normalised coordinates to screen coordinates
      x = elem.getInt("x")*scale+width/2;
      y = elem.getInt("y")*scale+height/2;
      w = elem.getInt("w")*scale;
      h = elem.getInt("h")*scale;
      
      // Other attributes
      type = elem.getString("type");
      id = elem.getString("id");
      
      // Optional attributes
      if (elem.isNull("bg colour")){
        bgColour = color(100);
      }
      else{
        bgColour = elem.getInt("bg colour");
      }
      
      if (elem.isNull("setting")){
        setting = "";
      }
      else{
        setting = elem.getString("setting");
      }
      
      if (elem.isNull("stroke colour")){
        strokeColour = color(150);
      }
      else{
        strokeColour = elem.getInt("stroke colour");
      }
      
      if (elem.isNull("text colour")){
        textColour = color(255);
      }
      else{
        textColour = elem.getInt("text colour");
      }
      
      if (elem.isNull("text size")){
        textSize = 16;
      }
      else{
        textSize = elem.getInt("text size");
      }
      
      if (elem.isNull("text")){
        text = "";
      }
      else{
        text = elem.getString("text");
      }
      
      if (elem.isNull("lower")){
        lower = 0;
      }
      else{
        lower = elem.getFloat("lower");
      }
      
      if (elem.isNull("upper")){
        upper = 1;
      }
      else{
        upper = elem.getFloat("upper");
      }
      
      if (elem.isNull("major")){
        major = 2;
      }
      else{
        major = elem.getInt("major");
      }
      
      if (elem.isNull("minor")){
        minor = 1;
      }
      else{
        minor = elem.getInt("minor");
      }
      
      if (elem.isNull("step")){
        step = 0.5f;
      }
      else{
        step = elem.getFloat("step");
      }
      
      if (elem.isNull("options")){
        options = new String[0];
      }
      else{
        options = elem.getJSONArray("options").getStringArray();
      }
      
      // Check if there is a defualt value. If not try loading from settings
      switch (type){
        case "button":
          state.addElement(id, new Button((int)x, (int)y, (int)w, (int)h, bgColour, strokeColour, textColour, textSize, CENTER, text), panelID);
          break;
        case "slider":
          if (elem.isNull("default value")){
            state.addElement(id, new Slider((int)x, (int)y, (int)w, (int)h, color(150), bgColour, strokeColour, color(0), lower, loadFloatSetting(setting), upper, major, minor, step, true, text), panelID);
          }
          else{
            state.addElement(id, new Slider((int)x, (int)y, (int)w, (int)h, color(150), bgColour, strokeColour, color(0), lower, elem.getFloat("default value"), upper, major, minor, step, true, text), panelID);
          }
          break;
        case "tickbox":
          if (elem.isNull("default value")){
            state.addElement(id, new Tickbox((int)x, (int)y, (int)w, (int)h, loadBooleanSetting(setting), text), panelID);
          }
          else{
            state.addElement(id, new Tickbox((int)x, (int)y, (int)w, (int)h, elem.getBoolean("default value"), text), panelID);
          }
          break;
        case "dropdown":
          DropDown dd = new DropDown((int)x, (int)y, (int)w, (int)h, color(150), text, elem.getString("options type"));
          dd.setOptions(options);
          if (elem.isNull("default value")){
            switch (dd.optionTypes){
              case "floats":
                dd.setSelected(""+jsManager.loadFloatSetting(setting));
                break;
              case "strings":
                dd.setSelected(jsManager.loadStringSetting(setting));
                break;
              case "ints":
                dd.setSelected(""+jsManager.loadIntSetting(setting));
                break;
            }
          }
          else{
            dd.setValue(elem.getString("default value"));
          }
          state.addElement(id, dd, panelID);
          break;
        default:
          println("invalid element type:", type);
          break;
      }
    }
  }
}



interface Map {
  public void updateMoveNodes(Node[][] nodes);
  public void cancelMoveNodes();
  public void removeTreeTile(int cellX, int cellY);
  public boolean isPanning();
  public float getFocusedX();
  public float getFocusedY();
  public boolean isZooming();
  public float getTargetZoom();
  public float getZoom();
  public float getTargetOffsetX();
  public float getTargetOffsetY();
  public float getTargetBlockSize();
  public float[] targetCell(int x, int y, float zoom);
  public void loadSettings(float x, float y, float bs);
  public void unselectCell();
  public boolean mouseOver();
  public Node[][] getMoveNodes();
  public float scaleXInv();
  public float scaleYInv();
  public void updatePath(ArrayList<int[]> nodes);
  public void updateHoveringScale();
  public void cancelPath();
  public void setActive(boolean a);
  public void selectCell(int x, int y);
  public void generateShape();
  public void clearShape();
  public boolean isMoving();
}


public int getPartySize(Party p){
  int totalSize = 0;
  ByteBuffer[] actions = new ByteBuffer[p.actions.size()];
  int index = 0;
  for (Action a: p.actions){
    int notificationSize;
    int terrainSize;
    int buildingSize;
    byte[] notification = new byte[0];
    byte[] terrain = new byte[0];
    byte[] building = new byte[0];
    if(a.notification == null){
      notificationSize = 0;
    } else {
      notification = a.notification.getBytes();
      notificationSize = notification.length;
    }
    if(a.terrain == null){
      terrainSize = 0;
    } else {
      terrain = a.terrain.getBytes();
      terrainSize = terrain.length;
    }
    if(a.building == null){
      buildingSize = 0;
    } else {
      building = a.building.getBytes();
      buildingSize = building.length;
    }
    int actionLength = Float.BYTES*2+Integer.BYTES*4+notificationSize+terrainSize+buildingSize;
    totalSize += actionLength;
    actions[index] = ByteBuffer.allocate(actionLength);
    actions[index].putInt(notificationSize);
    actions[index].putInt(terrainSize);
    actions[index].putInt(buildingSize);
    actions[index].putFloat(a.turns);
    actions[index].putFloat(a.initialTurns);
    actions[index].putInt(a.type);
    if(notificationSize>0){
      actions[index].put(notification);
    }
    if(terrainSize>0){
      actions[index].put(terrain);
    }
    if(buildingSize>0){
      actions[index].put(building);
    }
    index++;
  }
  totalSize+=Integer.BYTES; // For action count
  int pathSize = Integer.BYTES*(2*p.path.size()+1);
  totalSize += pathSize;
  
  ByteBuffer path = ByteBuffer.allocate(pathSize);
  path.putInt(p.path.size());
  for (int[] l: p.path){
    path.putInt(l[0]);
    path.putInt(l[1]);
  }
  totalSize += Integer.BYTES*5+Float.BYTES;
  
  
  ByteBuffer partyBuffer = ByteBuffer.allocate(totalSize);
  partyBuffer.putInt(p.actions.size());
  for (ByteBuffer action: actions){
    partyBuffer.put(action.array());
  }
  partyBuffer.put(path.array());
  partyBuffer.putInt(p.getUnitNumber());
  partyBuffer.putInt(p.getMovementPoints());
  partyBuffer.putInt(p.player);
  partyBuffer.putFloat(p.strength);
  partyBuffer.putInt(p.getTask());
  partyBuffer.putInt(p.pathTurns);
  p.byteRep = partyBuffer.array();
  return totalSize;
}
public void saveParty(ByteBuffer b, Party p){
  b.put(p.byteRep);
}
public Party loadParty(ByteBuffer b){
  int actionCount = b.getInt();
  ArrayList<Action> actions = new ArrayList<Action>();
  for (int i=0; i<actionCount; i++){
    String notification;
    String terrain;
    String building;
    int notificationTextSize = b.getInt();
    int terrainTextSize = b.getInt();
    int buildingTextSize = b.getInt();
    Float turns = b.getFloat();
    Float initialTurns = b.getFloat();
    int type = b.getInt();
    if(notificationTextSize>0){
      byte[] notificationTemp = new byte[notificationTextSize];
      b.get(notificationTemp);
      notification = new String(notificationTemp);
    } else {
      notification = null;
    }
    if(terrainTextSize>0){
      byte[] terrainTemp = new byte[terrainTextSize];
      b.get(terrainTemp);
      terrain = new String(terrainTemp);
    } else {
      terrain = null;
    }
    if(buildingTextSize>0){
      byte[] buildingTemp = new byte[buildingTextSize];
      b.get(buildingTemp);
      building = new String(buildingTemp);
    } else {
      building = null;
    }
    actions.add(new Action(type, notification, turns, building, terrain));
    actions.get(i).initialTurns = initialTurns;
  }
  int pathSize = b.getInt();
  ArrayList<int[]> path = new ArrayList<int[]>();
  for(int i=0; i<pathSize; i++){
    path.add(new int[]{b.getInt(), b.getInt()});
  }
  int unitNumber = b.getInt();
  int movementPoints = b.getInt();
  int player = b.getInt();
  float strength = b.getFloat();
  int task = b.getInt();
  int pathTurns = b.getInt();
  Party p = new Party(player, unitNumber, task, movementPoints);
  p.strength = strength;
  p.pathTurns = pathTurns;
  p.actions = actions;
  if (path.size() > 0){
    p.target = path.get(path.size()-1);
    p.loadPath(path);
  }
  return p;
}

class BaseMap extends Element{
  float[] heightMap;
  int mapWidth, mapHeight;
  long heightMapSeed;
  int[][] terrain;
  Party[][] parties;
  Building[][] buildings;
  public void saveMap(String filename, int turnNumber, int turnPlayer, Player[] players){
    int partiesByteCount = 0;
    for (int y=0; y<mapHeight; y++){
      for (int x=0; x<mapWidth; x++){
        if(parties[y][x] != null){
          if(parties[y][x].player==2){
            partiesByteCount+=getPartySize(((Battle)parties[y][x]).party1);
            partiesByteCount+=getPartySize(((Battle)parties[y][x]).party2);
          } else {
            partiesByteCount+=getPartySize(parties[y][x]);
          }
        }
        partiesByteCount++;
      }
    }
    int playersByteCount = ((3+players[0].resources.length)*Float.BYTES+3*Integer.BYTES+1)*players.length;
    ByteBuffer buffer = ByteBuffer.allocate(Integer.BYTES*8+Long.BYTES+Integer.BYTES*mapWidth*mapHeight*3+partiesByteCount+playersByteCount);
    buffer.putInt(mapWidth);
    buffer.putInt(mapHeight);
    buffer.putInt(partiesByteCount);
    buffer.putInt(playersByteCount);
    buffer.putInt(players.length);
    buffer.putInt(players[0].resources.length);
    buffer.putInt(turnNumber);
    buffer.putInt(turnPlayer);
    buffer.putLong(heightMapSeed);
    for (int y=0; y<mapHeight; y++){
      for (int x=0; x<mapWidth; x++){
        buffer.putInt(terrain[y][x]);
      }
    }
    for (int y=0; y<mapHeight; y++){
      for (int x=0; x<mapWidth; x++){
        if(buildings[y][x]==null){
          buffer.putInt(-1);
          buffer.putInt(-1);
        } else {
          buffer.putInt(buildings[y][x].type);
          buffer.putInt(buildings[y][x].image_id);
        }
      }
    }
    for (int y=0; y<mapHeight; y++){
      for (int x=0; x<mapWidth; x++){
        if(parties[y][x]==null){
          buffer.put(PApplet.parseByte(0));
        } else if (parties[y][x].player == 2){
          buffer.put(PApplet.parseByte(2));
          saveParty(buffer, ((Battle)parties[y][x]).party1);
          saveParty(buffer, ((Battle)parties[y][x]).party2);
        } else {
          buffer.put(PApplet.parseByte(1));
          saveParty(buffer, parties[y][x]);
        }
      }
    }
    for (Player p: players){
      buffer.putFloat(p.mapXOffset);
      buffer.putFloat(p.mapYOffset);
      buffer.putFloat(p.blockSize);
      for (float r: p.resources){
        buffer.putFloat(r);
      }
      buffer.putInt(p.cellX);
      buffer.putInt(p.cellY);
      buffer.putInt(p.colour);
      buffer.put(PApplet.parseByte(p.cellSelected));
    }
    saveBytes(filename, buffer.array());
  }
  public MapSave loadMap(String filename, int resourceCountNew){
    byte tempBuffer[] = loadBytes(filename);
    int headerSize = Integer.BYTES*4;
    ByteBuffer headerBuffer = ByteBuffer.allocate(headerSize);
    headerBuffer.put(Arrays.copyOfRange(tempBuffer, 0, headerSize));
    headerBuffer.flip();//need flip
    mapWidth = headerBuffer.getInt();
    mapHeight = headerBuffer.getInt();
    int partiesByteCount = headerBuffer.getInt();
    int playersByteCount = headerBuffer.getInt();
    int dataSize = Long.BYTES+partiesByteCount+playersByteCount+(4+mapWidth*mapHeight*3)*Integer.BYTES;
    ByteBuffer buffer = ByteBuffer.allocate(dataSize);
    buffer.put(Arrays.copyOfRange(tempBuffer, headerSize, headerSize+dataSize));
    buffer.flip();//need flip
    int playerCount = buffer.getInt();
    int resourceCountOld = buffer.getInt();
    int turnNumber = buffer.getInt();
    int turnPlayer = buffer.getInt();
    heightMapSeed = buffer.getLong();
    terrain = new int[mapHeight][mapWidth];
    parties = new Party[mapHeight][mapWidth];
    buildings = new Building[mapHeight][mapWidth];
    for (int y=0; y<mapHeight; y++){
      for (int x=0; x<mapWidth; x++){
        terrain[y][x] = buffer.getInt();
      }
    }
    for (int y=0; y<mapHeight; y++){
      for (int x=0; x<mapWidth; x++){
        int type = buffer.getInt();
        int image_id = buffer.getInt();
        if(type!=-1){
          buildings[y][x] = new Building(type, image_id);
        }
      }
    }
    for (int y=0; y<mapHeight; y++){
      for (int x=0; x<mapWidth; x++){
        Byte partyType = buffer.get();
        if (partyType == 2){
          Party p1 = loadParty(buffer);
          Party p2 = loadParty(buffer);
          float savedStrength = p1.strength;
          Battle b = new Battle(p1, p2);
          b.party1.strength = savedStrength;
          parties[y][x] = b;
        } else if (partyType == 1){
          parties[y][x] = loadParty(buffer);
        }
      }
    }
    Player[] players = new Player[playerCount];
    for (int i=0;i<playerCount;i++){
      float mapXOffset = buffer.getFloat();
      float mapYOffset = buffer.getFloat();
      float blockSize = buffer.getFloat();
      float[] resources = new float[resourceCountNew];
      for (int r=0; r<resourceCountOld;r++){
        resources[r] = buffer.getFloat();
      }
      int cellX = buffer.getInt();
      int cellY = buffer.getInt();
      int colour = buffer.getInt();
      boolean cellSelected = PApplet.parseBoolean(buffer.get());
      players[i] = new Player(mapXOffset, mapYOffset, blockSize, resources, colour);
      players[i].cellSelected = cellSelected;
    }
    noiseSeed(heightMapSeed);
    generateNoiseMaps();
    
    return new MapSave(heightMap, mapWidth, mapHeight, terrain, parties, buildings, turnNumber, turnPlayer, players);
  }
  
  
  public int toMapIndex(int x, int y, int x1, int y1){
    return PApplet.parseInt(x1+x*jsManager.loadFloatSetting("terrain detail")+y1*jsManager.loadFloatSetting("terrain detail")*(mapWidth+1/jsManager.loadFloatSetting("terrain detail"))+y*pow(jsManager.loadFloatSetting("terrain detail"), 2)*(mapWidth+1/jsManager.loadFloatSetting("terrain detail")));
  }
  
  
  //int getRandomGroundType(HashMap<Integer, Float> groundWeightings, float total){
  //  float randomNum = random(0, 1);
  //  float min = 0;
  //  int lastType = 1;
  //  for (int type: groundWeightings.keySet()){
  //    if(randomNum>min&&randomNum<min+groundWeightings.get(type)/total){
  //      return type;
  //    }
  //    min += groundWeightings.get(type)/total;
  //    lastType = type;
  //  }
  //  return lastType;
  //}
  //int getRandomGroundTypeAt(int x, int y, ArrayList<Integer> shuffledTypes, HashMap<Integer, Float> groundWeightings, float total){
  //  double randomNum = Math.cbrt(noise(x*MAPTERRAINNOISESCALE, y*MAPTERRAINNOISESCALE, 1)*2-1)*0.5+0.5;
  //  float min = 0;
  //  int lastType = 1;
  //  for (int type: shuffledTypes){
  //    if(randomNum>min&&randomNum<min+groundWeightings.get(type)/total){
  //      return type;
  //    }
  //    min += groundWeightings.get(type)/total;
  //    lastType = type;
  //  }
  //  return lastType;
  //}
  //int[][] smoothMap(int distance, int firstType, int[][] terrain){
  //  ArrayList<int[]> order = new ArrayList<int[]>();
  //  for (int y=0; y<mapHeight;y++){
  //    for (int x=0; x<mapWidth;x++){
  //      order.add(new int[] {x, y});
  //    }
  //  }
  //  Collections.shuffle(order);
  //  int[][] newMap = new int[mapHeight][mapWidth];
  //  for (int[] coord: order){
  //    if(terrain[coord[1]][coord[0]]==terrainIndex("water")){
  //      newMap[coord[1]][coord[0]] = terrain[coord[1]][coord[0]];
  //    } else {
  //      int[] counts = new int[NUMOFGROUNDTYPES+1];
  //      for (int y1=coord[1]-distance+1;y1<coord[1]+distance;y1++){
  //        for (int x1 = coord[0]-distance+1; x1<coord[0]+distance;x1++){
  //          if (y1<mapHeight&&y1>=0&&x1<mapWidth&&x1>=0){
  //            if(terrain[y1][x1]!=terrainIndex("water")){
  //              counts[terrain[y1][x1]]+=1;
  //            }
  //          }
  //        }
  //      }
  //      int highest = terrain[coord[1]][coord[0]];
  //      for (int i=firstType; i<=NUMOFGROUNDTYPES;i++){
  //        if (counts[i] > counts[highest]){
  //          highest = i;
  //        }
  //      }
  //      newMap[coord[1]][coord[0]] = highest;
  //    }
  //  }
  //  return newMap;
  //}
  public void generateTerrain(){
    HashMap<Integer, Float> groundWeightings = new HashMap();
    for (Integer i=1; i<gameData.getJSONArray("terrain").size()+1; i++){
      groundWeightings.put(i, gameData.getJSONArray("terrain").getJSONObject(i-1).getFloat("weighting"));
    }

    float totalWeighting = 0;
    for (float weight: groundWeightings.values()){
      totalWeighting+=weight;
    }
    //for(int i=0;i<jsManager.loadIntSetting("ground spawns");i++){
    //  int type = getRandomGroundType(groundWeightings, totalWeighting);
    //  int x = (int)random(mapWidth);
    //  int y = (int)random(mapHeight);
    //  if(isWater(x, y)){
    //    i--;
    //  } else {
    //    terrain[y][x] = type;
    //  }
    //}
    class TempTerrainDetail implements Comparable<TempTerrainDetail>{
      int x;
      int y;
      float noiseValue;
      TempTerrainDetail(int x, int y, float noiseValue){
        super();
        this.x = x;
        this.y = y;
        this.noiseValue = noiseValue;
      }
      public int compareTo(TempTerrainDetail otherDetail) {
        if(this.noiseValue>otherDetail.noiseValue){
          return 1;
        } else if (this.noiseValue<otherDetail.noiseValue){
          return -1;
        } else {
          return 0;
        }
      }
    }
    ArrayList<TempTerrainDetail> cells = new ArrayList<TempTerrainDetail>();
    for (int y=0; y<mapHeight;y++){
      for (int x=0; x<mapWidth;x++){
        if(isWater(x, y)){
          terrain[y][x] = terrainIndex("water");
        } else {
          cells.add(new TempTerrainDetail(x, y, noise(x*MAPTERRAINNOISESCALE, y*MAPTERRAINNOISESCALE, 1)));
        }
      }
    }
    TempTerrainDetail[] cellsArray = new TempTerrainDetail[cells.size()];
    cells.toArray(cellsArray);
    Arrays.sort(cellsArray);
    int terrainIndex = 0;
    int totalBelow = 0;
    int lastType = 0;
    for (int type: groundWeightings.keySet()){
      if(groundWeightings.get(type)>0){
        while(PApplet.parseFloat(terrainIndex-totalBelow)/cells.size()<groundWeightings.get(type)/totalWeighting){
          terrain[cellsArray[terrainIndex].y][cellsArray[terrainIndex].x] = type;
          cellsArray[terrainIndex].noiseValue = 0;
          terrainIndex++;
        }
        totalBelow = terrainIndex-1;
      }
      lastType = type;
    }
    for(TempTerrainDetail t: cellsArray){
      if(t.noiseValue!=0){
        terrain[t.y][t.x] = lastType;
        println("map generation possible issue here");
      }
    }
    //ArrayList<int[]> order = new ArrayList<int[]>();
    //for (int y=0; y<mapHeight;y++){
    //  for (int x=0; x<mapWidth;x++){
    //    if(isWater(x, y)){
    //      terrain[y][x] = terrainIndex("water");
    //    } else {
    //      order.add(new int[] {x, y});
    //    }
    //  }
    //}
    //Collections.shuffle(order);
    //for (int[] coord: order){
    //  int x = coord[0];
    //  int y = coord[1];
    //  while (terrain[y][x] == 0||terrain[y][x]==terrainIndex("water")){
    //    int direction = (int) random(8);
    //    switch(direction){
    //      case 0:
    //        x= max(x-1, 0);
    //        break;
    //      case 1:
    //        x = min(x+1, mapWidth-1);
    //        break;
    //      case 2:
    //        y= max(y-1, 0);
    //        break;
    //      case 3:
    //        y = min(y+1, mapHeight-1);
    //        break;
    //      case 4:
    //        x = min(x+1, mapWidth-1);
    //        y = min(y+1, mapHeight-1);
    //        break;
    //      case 5:
    //        x = min(x+1, mapWidth-1);
    //        y= max(y-1, 0);
    //        break;
    //      case 6:
    //        y= max(y-1, 0);
    //        x= max(x-1, 0);
    //        break;
    //      case 7:
    //        y = min(y+1, mapHeight-1);
    //        x= max(x-1, 0);
    //        break;
    //    }
    //  }
    //  terrain[coord[1]][coord[0]] = terrain[y][x];
    //}
    //terrain = smoothMap(jsManager.loadIntSetting("smoothing"), 2, terrain);
    //terrain = smoothMap(jsManager.loadIntSetting("smoothing")+2, 1, terrain);
    for (int y=0; y<mapHeight;y++){
      for (int x=0; x<mapWidth;x++){
        if(terrain[y][x] != terrainIndex("water") && (groundMaxRawHeightAt(x, y) > 0.5f+jsManager.loadFloatSetting("water level")/2.0f) || getMaxSteepness(x, y)>HILLSTEEPNESS){
          terrain[y][x] = terrainIndex("hills");
        }
      }
    }
  }
  public void generateMap(int mapWidth, int mapHeight){
    terrain = new int[mapHeight][mapWidth];
    buildings = new Building[mapHeight][mapWidth];
    parties = new Party[mapHeight][mapWidth];
    this.mapWidth = mapWidth;
    this.mapHeight = mapHeight;
    heightMapSeed = (long)random(Long.MIN_VALUE, Long.MAX_VALUE);
    noiseSeed(heightMapSeed);
    generateNoiseMaps();
    generateTerrain();
  }
  public void generateNoiseMaps(){
    heightMap = new float[PApplet.parseInt((mapWidth+1/jsManager.loadFloatSetting("terrain detail"))*(mapHeight+1/jsManager.loadFloatSetting("terrain detail"))*pow(jsManager.loadFloatSetting("terrain detail"), 2))];
    for(int y = 0;y<mapHeight;y++){
      for(int y1 = 0;y1<jsManager.loadFloatSetting("terrain detail");y1++){
        for(int x = 0;x<mapWidth;x++){
          for(int x1 = 0;x1<jsManager.loadFloatSetting("terrain detail");x1++){
            heightMap[toMapIndex(x, y, x1, y1)] = noise((x+x1/jsManager.loadFloatSetting("terrain detail"))*MAPHEIGHTNOISESCALE, (y+y1/jsManager.loadFloatSetting("terrain detail"))*MAPHEIGHTNOISESCALE);
          }
        }
        heightMap[toMapIndex(mapWidth, y, 0, y1)] = noise(((mapWidth+1))*MAPHEIGHTNOISESCALE, (y+y1/jsManager.loadFloatSetting("terrain detail"))*MAPHEIGHTNOISESCALE);
      }
    }
    for(int x = 0;x<mapWidth;x++){
      for(int x1 = 0;x1<jsManager.loadFloatSetting("terrain detail");x1++){
        heightMap[toMapIndex(x, mapHeight, x1, 0)] = noise((x+x1/jsManager.loadFloatSetting("terrain detail"))*MAPHEIGHTNOISESCALE, (mapHeight)*MAPHEIGHTNOISESCALE);
      }
    }
    heightMap[toMapIndex(mapWidth, mapHeight, 0, 0)] = noise(((mapWidth+1))*MAPHEIGHTNOISESCALE, (mapHeight)*MAPHEIGHTNOISESCALE);
  }
  public float getRawHeight(int x, int y, int x1, int y1) {
    try{
      if((x>=0&&x<mapWidth&&y>=0&&y<mapHeight)||(x==mapWidth&&x1==0)||(y==mapHeight&&y1==0)){
        return max(heightMap[toMapIndex(x, y, x1, y1)], jsManager.loadFloatSetting("water level"));
      } else {
        // println("A request for the height at a tile outside the map has been made. Ideally this should be prevented earlier"); // Uncomment this when we want to fix it
        return jsManager.loadFloatSetting("water level");
      }
    } catch (ArrayIndexOutOfBoundsException e) {
      println("this message should never appear");
      return jsManager.loadFloatSetting("water level");
    }
  }
  public float getRawHeight(int x, int y) {
    return getRawHeight(x, y, 0, 0);
  }
  public float getRawHeight(float x, float y){
    if(x<0||y<0){
      return jsManager.loadFloatSetting("water level");
    }
    return getRawHeight(PApplet.parseInt(x), PApplet.parseInt(y), round((x-PApplet.parseInt(x))*jsManager.loadFloatSetting("terrain detail")), round((y-PApplet.parseInt(y))*jsManager.loadFloatSetting("terrain detail")));
  }
  public float groundMinRawHeightAt(int x1, int y1) {
    int x = floor(x1);
    int y = floor(y1);
    return min(new float[]{getRawHeight(x, y), getRawHeight(x+1, y), getRawHeight(x, y+1), getRawHeight(x+1, y+1)});
  }
  public float groundMaxRawHeightAt(int x1, int y1) {
    int x = floor(x1);
    int y = floor(y1);
    return max(new float[]{getRawHeight(x, y), getRawHeight(x+1, y), getRawHeight(x, y+1), getRawHeight(x+1, y+1)});
  }
  public boolean isWater(int x, int y){
    return groundMaxRawHeightAt(x, y) == jsManager.loadFloatSetting("water level");
  }
  
  public float getMaxSteepness(int x, int y){
    float maxZ, minZ;
    maxZ = 0;
    minZ = 1;
    for (float y1 = y; y1<=y+1;y1+=1.0f/jsManager.loadFloatSetting("terrain detail")){
      for (float x1 = x; x1<=x+1;x1+=1.0f/jsManager.loadFloatSetting("terrain detail")){
        float z = getRawHeight(x1, y1);
        if(z>maxZ){
          maxZ = z;
        } else if (z<minZ){
          minZ = z;
        }
      }
    }
    return maxZ-minZ;
  }
}

class Map2D extends BaseMap implements Map{
  final int EW, EH, INITIALHOLD=1000;
  float blockSize, targetBlockSize;
  float mapXOffset, mapYOffset, targetXOffset, targetYOffset, panningSpeed, resetTime;
  boolean panning=false, zooming=false;
  float mapMaxSpeed;
  int elementWidth;
  int elementHeight;
  float[] mapVelocity = {0,0};
  int startX;
  int startY;
  int frameStartTime;
  int xPos, yPos;
  boolean zoomChanged;
  boolean mapFocused, mapActive;
  int selectedCellX, selectedCellY;
  boolean cellSelected;
  int partyManagementColour;
  Node[][] moveNodes;
  ArrayList<int[]> drawPath;

  Map2D(int x, int y, int w, int h, int[][] terrain, Party[][] parties, Building[][] buildings, int mapWidth, int mapHeight){
    xPos = x;
    yPos = y;
    EW = w;
    EH = h;
    this.mapWidth = mapWidth;
    this.mapHeight = mapHeight;
    elementWidth = round(EW);
    elementHeight = round(EH);
    mapXOffset = 0;
    mapYOffset = 0;
    mapMaxSpeed = 15;
    this.terrain = terrain;
    this.parties = parties;
    this.buildings = buildings;
    this.mapWidth = mapWidth;
    this.mapHeight = mapHeight;
    limitCoords();
    frameStartTime = 0;
    cancelMoveNodes();
    cancelPath();
    heightMap = new float[PApplet.parseInt((mapWidth+1)*(mapHeight+1)*pow(jsManager.loadFloatSetting("terrain detail"), 2))];
  }
  public void generateShape(){

  }
  public void clearShape(){

  }
  public void updateHoveringScale(){
    
  }
  public boolean isMoving(){
    return mapVelocity[0] != 0 || mapVelocity[1] != 0;
  }
  public Node[][] getMoveNodes(){
    return moveNodes;
  }
  public float getTargetZoom(){
    return targetBlockSize;
  }
  public float getZoom(){
    return blockSize;
  }
  public boolean isZooming(){
    return zooming;
  }
  public boolean isPanning(){
    return panning;
  }
  public float getFocusedX(){
    return mapXOffset;
  }
  public float getFocusedY(){
    return mapYOffset;
  }
  public void removeTreeTile(int cellX, int cellY) {
    terrain[cellY][cellX] = terrainIndex("grass");
  }
  public void setActive(boolean a){
    this.mapActive = a;
  }
  public void selectCell(int x, int y){
    cellSelected = true;
    selectedCellX = x;
    selectedCellY = y;
  }
  public void unselectCell(){
    cellSelected = false;
  }
  public void setPanningSpeed(float s){
    panningSpeed = s;
  }
  public void limitCoords(){
    mapXOffset = min(max(mapXOffset, -mapWidth*blockSize+elementWidth*0.5f), elementWidth*0.5f);
    mapYOffset = min(max(mapYOffset, -mapHeight*blockSize+elementHeight*0.5f), elementHeight*0.5f);
  }
  public void reset(){
    mapXOffset = 0;
    mapYOffset = 0;
    blockSize = min(elementWidth/(float)mapWidth, elementWidth/10);
    setPanningSpeed(0.02f);
    resetTime = millis();
    frameStartTime = 0;
    cancelMoveNodes();
  }
  public void loadSettings(float x, float y, float bs){
    targetZoom(bs);
    targetOffset(x, y);
  }
  public void targetOffset(float x, float y){
    targetXOffset = x;
    targetYOffset = y;
    limitCoords();
    panning = true;
  }
  public void targetZoom(float bs){
    zooming = true;
    targetBlockSize = bs;
  }
  public float getTargetOffsetX(){
    return targetXOffset;
  }
  public float getTargetOffsetY(){
    return targetYOffset;
  }
  public float getTargetBlockSize(){
    return targetBlockSize;
  }
  public float [] targetCell(int x, int y, float bs){
    targetBlockSize = bs;
    targetXOffset = -(x+0.5f)*targetBlockSize+elementWidth/2+xPos;
    targetYOffset = -(y+0.5f)*targetBlockSize+elementHeight/2+yPos;
    panning = true;
    zooming = true;
    return new float[]{targetXOffset, targetYOffset, targetBlockSize};
  }
  public void focusMapMouse(int x, int y){
    // based on mouse click
    if(mouseOver()){
      targetXOffset = -scaleXInv()*blockSize+elementWidth/2+xPos;
      targetYOffset = -scaleYInv()*blockSize+elementHeight/2+yPos;
      limitCoords();
      panning = true;
    }
  }
  public void resetTarget(){
    targetXOffset = mapXOffset;
    targetYOffset = mapYOffset;
    panning = false;
  }
  public void resetTargetZoom(){
    zooming = false;
    targetBlockSize = blockSize;
    setPanningSpeed(0.05f);
  }

  public void updateMoveNodes(Node[][] nodes){
    moveNodes = nodes;
  }
  public void updatePath(ArrayList<int[]> nodes){
    drawPath = nodes;
  }
  public void cancelMoveNodes(){
    moveNodes = null;
  }
  public void cancelPath(){
    drawPath = null;
  }

  public ArrayList<String> mouseEvent(String eventType, int button, MouseEvent event){
    if (eventType == "mouseWheel"){
      float count = event.getCount();
      if(mouseOver() && mapActive){
        float zoom = pow(0.9f, count);
        float newBlockSize = max(min(blockSize*zoom, (float)elementWidth/10), (float)elementWidth/(float)jsManager.loadIntSetting("map size"));
        if (blockSize != newBlockSize){
          mapXOffset = scaleX(((mouseX-mapXOffset-xPos)/blockSize))-xPos-((mouseX-mapXOffset-xPos)*newBlockSize/blockSize);
          mapYOffset = scaleY(((mouseY-mapYOffset-yPos)/blockSize))-yPos-((mouseY-mapYOffset-yPos)*newBlockSize/blockSize);
          blockSize = newBlockSize;
          limitCoords();
          resetTarget();
          resetTargetZoom();
        }
      }
    }
    return new ArrayList<String>();
  }

  public ArrayList<String> mouseEvent(String eventType, int button){
    if (button == LEFT&mapActive){
      if (eventType=="mouseDragged" && mapFocused){
        mapXOffset += (mouseX-startX);
        mapYOffset += (mouseY-startY);
        limitCoords();
        startX = mouseX;
        startY = mouseY;
        resetTarget();
        resetTargetZoom();
      }
      if (eventType == "mousePressed"){
        if (mouseOver()){
          startX = mouseX;
          startY = mouseY;
          mapFocused = true;
        }
        else{
          mapFocused = false;
        }
      }
    }
    return new ArrayList<String>();
  }
  public ArrayList<String> keyboardEvent(String eventType, char _key){
    if (eventType == "keyPressed"){
      if (_key == 'a'){
        resetTargetZoom();
        resetTarget();
        mapVelocity[0] -= mapMaxSpeed;
      }
      if (_key == 's'){
        resetTargetZoom();
        resetTarget();
        mapVelocity[1] += mapMaxSpeed;
      }
      if (_key == 'd'){
        resetTargetZoom();
        resetTarget();
        mapVelocity[0] += mapMaxSpeed;
      }
      if (_key == 'w'){
        resetTargetZoom();
        resetTarget();
        mapVelocity[1] -= mapMaxSpeed;
      }
    }
    if (eventType == "keyReleased"){
      if (_key == 'a'){
        mapVelocity[0] += mapMaxSpeed;
      }
      if (_key == 's'){
        mapVelocity[1] -= mapMaxSpeed;
      }
      if (_key == 'd'){
        mapVelocity[0] -= mapMaxSpeed;
      }
      if (_key == 'w'){
        mapVelocity[1] += mapMaxSpeed;
      }
    }
    return new ArrayList<String>();
  }

  public void setWidth(int w){
    this.elementWidth = w;
  }

  public void drawSelectedCell(PVector c, PGraphics panelCanvas){
   //cell selection
   panelCanvas.stroke(0);
   if (cellSelected){
     if (max(c.x, xPos)+min(blockSize, xPos+elementWidth-c.x, blockSize+c.x-xPos)>xPos && max(c.x, xPos) < elementWidth+xPos && max(c.y, yPos)+min(blockSize, yPos+elementHeight-c.y, blockSize+c.y-yPos)>yPos && max(c.y, yPos) < elementHeight+yPos){
       panelCanvas.fill(50, 100);
       panelCanvas.rect(max(c.x, xPos), max(c.y, yPos), min(blockSize-1, xPos+elementWidth-c.x, blockSize+c.x-xPos), min(blockSize-1, yPos+elementHeight-c.y, blockSize+c.y-yPos));
     }
   }
  }

  public void draw(PGraphics panelCanvas){

    // Terrain
    PImage[] tempTileImages = new PImage[gameData.getJSONArray("terrain").size()];
    PImage[][] tempBuildingImages = new PImage[gameData.getJSONArray("buildings").size()][];
    PImage[] tempPartyImages = new PImage[3];
    PImage[] tempTaskImages = new PImage[taskImages.length];
    if (frameStartTime == 0){
      frameStartTime = millis();
    }
    int frameTime = millis()-frameStartTime;
    if (millis()-resetTime < INITIALHOLD){
      frameTime = 0;
    }
    if (zooming){
      blockSize += (targetBlockSize-blockSize)*panningSpeed*frameTime*60/1000;
    }

    // Resize map based on scale
    if (panning){
      mapXOffset -= (mapXOffset-targetXOffset)*panningSpeed*frameTime*60/1000;
      mapYOffset -= (mapYOffset-targetYOffset)*panningSpeed*frameTime*60/1000;
    }
    if ((zooming || panning) && pow(mapXOffset-targetXOffset, 2) + pow(mapYOffset-targetYOffset, 2) < pow(blockSize*0.5f, 2) && abs(blockSize-targetBlockSize) < 1){
      resetTargetZoom();
      resetTarget();
    }
    mapXOffset -= mapVelocity[0]*frameTime*60/1000;
    mapYOffset -= mapVelocity[1]*frameTime*60/1000;
    frameStartTime = millis();
    limitCoords();

    if (blockSize <= 0)
      return;

    for (int i=0; i<gameData.getJSONArray("terrain").size(); i++){
      JSONObject tileType = gameData.getJSONArray("terrain").getJSONObject(i);
      if(blockSize<24&&!tileType.isNull("low img")){
        tempTileImages[i] = lowImages.get(tileType.getString("id")).copy();
        tempTileImages[i].resize(ceil(blockSize), 0);
      } else {
        tempTileImages[i] = tileImages.get(tileType.getString("id")).copy();
        tempTileImages[i].resize(ceil(blockSize), 0);
      }
    }
    for (int i=0; i<gameData.getJSONArray("buildings").size(); i++){
      JSONObject buildingType = gameData.getJSONArray("buildings").getJSONObject(i);
      tempBuildingImages[i] = new PImage[buildingImages.get(buildingType.getString("id")).length];
      for (int j=0; j<buildingImages.get(buildingType.getString("id")).length; j++){
        tempBuildingImages[i][j] = buildingImages.get(buildingType.getString("id"))[j].copy();
        tempBuildingImages[i][j].resize(ceil(blockSize*48/64), 0);
      }
    }
    for (int i=0; i<3; i++){
      tempPartyImages[i] = partyImages[i].copy();
      tempPartyImages[i].resize(ceil(blockSize), 0);
    }
    for(int i=0; i<taskImages.length; i++){
      if(taskImages[i] != null){
        tempTaskImages[i] = taskImages[i].copy();
        tempTaskImages[i].resize(ceil(3*blockSize/16), 0);
      }
    }
    int lx = max(0, -ceil((mapXOffset)/blockSize));
    int ly = max(0, -ceil((mapYOffset)/blockSize));
    int hx = min(floor((elementWidth-mapXOffset)/blockSize)+1, mapWidth);
    int hy = min(floor((elementHeight-mapYOffset)/blockSize)+1, mapHeight);

    PVector c;
    PVector selectedCell = new PVector(scaleX(selectedCellX), scaleY(selectedCellY));

    for(int y=ly;y<hy;y++){
      for (int x=lx; x<hx; x++){
        float x2 = round(scaleX(x));
        float y2 = round(scaleY(y));
        panelCanvas.image(tempTileImages[terrain[y][x]-1], x2, y2);

         //Buildings
         if (buildings[y][x] != null){
           c = new PVector(scaleX(x), scaleY(y));
           int border = round((64-48)*blockSize/(2*64));
           int imgSize = round(blockSize*48/60);
           drawCroppedImage(round(c.x+border), round(c.y+border*2), imgSize, imgSize, tempBuildingImages[buildings[y][x].type-1][buildings[y][x].image_id], panelCanvas);
         }
         //Parties
         if(parties[y][x]!=null){
           c = new PVector(scaleX(x), scaleY(y));
           if(c.x<xPos+elementWidth&&c.y+blockSize/8>yPos&&c.y<yPos+elementHeight){
             panelCanvas.noStroke();
             if(parties[y][x].player == 2){
               Battle battle = (Battle) parties[y][x];
               if (c.x+blockSize>xPos){
                 panelCanvas.fill(120, 120, 120);
                 panelCanvas.rect(max(c.x, xPos), max(c.y, yPos), max(0, min(blockSize, xPos+elementWidth-c.x, blockSize+c.x-xPos)), max(0, min(ceil(blockSize/16), yPos+elementHeight-c.y, blockSize/16+c.y-yPos)));
               }
               if (c.x+blockSize*parties[y][x].getUnitNumber()/1000>xPos){
                 panelCanvas.fill(playerColours[battle.party1.player]);
                 panelCanvas.rect(max(c.x, xPos), max(c.y, yPos), max(0, min(blockSize*battle.party1.getUnitNumber()/1000, xPos+elementWidth-c.x, blockSize*battle.party1.getUnitNumber()/1000+c.x-xPos)), max(0, min(ceil(blockSize/16), yPos+elementHeight-c.y, blockSize/16+c.y-yPos)));
               }
               if (c.x+blockSize>xPos){
                 panelCanvas.fill(120, 120, 120);
                 panelCanvas.rect(max(c.x, xPos), max(c.y+blockSize/16, yPos), max(0, min(blockSize, xPos+elementWidth-c.x, blockSize+c.x-xPos)), max(0, min(ceil(blockSize/16), yPos+elementHeight-c.y-blockSize/16, blockSize/16+c.y-yPos)));
               }
               if (c.x+blockSize*parties[y][x].getUnitNumber()/1000>xPos){
                 panelCanvas.fill(playerColours[battle.party2.player]);
                 panelCanvas.rect(max(c.x, xPos), max(c.y+blockSize/16, yPos), max(0, min(blockSize*battle.party2.getUnitNumber()/1000, xPos+elementWidth-c.x, blockSize*battle.party2.getUnitNumber()/1000+c.x-xPos)), max(0, min(ceil(blockSize/16), yPos+elementHeight-c.y-blockSize/16, blockSize/8+c.y-yPos)));
               }

             } else {
               if (c.x+blockSize>xPos){
                 panelCanvas.fill(120, 120, 120);
                 panelCanvas.rect(max(c.x, xPos), max(c.y, yPos), min(blockSize, xPos+elementWidth-c.x, blockSize+c.x-xPos), min(blockSize/8, yPos+elementHeight-c.y, blockSize/8+c.y-yPos));
               }
               if (c.x+blockSize*parties[y][x].getUnitNumber()/1000>xPos){
                 panelCanvas.fill(playerColours[parties[y][x].player]);
                 panelCanvas.rect(max(c.x, xPos), max(c.y, yPos), min(blockSize*parties[y][x].getUnitNumber()/1000, xPos+elementWidth-c.x, blockSize*parties[y][x].getUnitNumber()/1000+c.x-xPos), min(blockSize/8, yPos+elementHeight-c.y, blockSize/8+c.y-yPos));
               }
             }
             int imgSize = round(blockSize);
             drawCroppedImage(floor(c.x), floor(c.y), imgSize, imgSize, tempPartyImages[parties[y][x].player], panelCanvas);
             JSONObject jo = gameData.getJSONArray("tasks").getJSONObject(parties[y][x].getTask());
             if (jo != null && !jo.isNull("img")){
               drawCroppedImage(floor(c.x+13*blockSize/32), floor(c.y+blockSize/2), ceil(3*blockSize/16), ceil(3*blockSize/16), tempTaskImages[parties[y][x].getTask()], panelCanvas);
             }
           }
         }
         if (cellSelected&&y==selectedCellY&&x==selectedCellX){
           drawSelectedCell(selectedCell, panelCanvas);
         }
         if(parties[y][x]!=null){
           c = new PVector(scaleX(x), scaleY(y));
           if(c.x<xPos+elementWidth&&c.y+blockSize/8>yPos&&c.y<yPos+elementHeight){
             panelCanvas.textFont(getFont(blockSize/7));
             panelCanvas.fill(255);
             panelCanvas.textAlign(CENTER, CENTER);
             if(parties[y][x].actions.size() > 0 && parties[y][x].actions.get(0).initialTurns>0){
               int totalTurns = parties[y][x].calcTurns(parties[y][x].actions.get(0).initialTurns);
               String turnsLeftString = str(totalTurns-parties[y][x].turnsLeft())+"/"+str(totalTurns);
               if (c.x+textWidth(turnsLeftString) < elementWidth+xPos && c.y+2*(textAscent()+textDescent()) < elementHeight+yPos){
                 panelCanvas.text(turnsLeftString, c.x+blockSize/2, c.y+3*blockSize/4);
               }
             }
           }
         }
         //if (millis()-pt > 10){
         //  println(millis()-pt);
         //}
       }
     }

     if (moveNodes != null){
       for (int y1=0; y1<mapHeight; y1++){
         for (int x=0; x<mapWidth; x++){
           if (moveNodes[y1][x] != null){
             c = new PVector(scaleX(x), scaleY(y1));
             if (max(c.x, xPos)+min(blockSize, xPos+elementWidth-c.x, blockSize+c.x-xPos)>xPos && max(c.x, xPos) < elementWidth+xPos && max(c.y, yPos)+min(blockSize, yPos+elementHeight-c.y, blockSize+c.y-yPos)>yPos && max(c.y, yPos) < elementHeight+yPos){
               if (blockSize > 10*jsManager.loadFloatSetting("text scale") && moveNodes[y1][x].cost <= parties[selectedCellY][selectedCellX].getMovementPoints()){
                 panelCanvas.fill(50, 150);
                 panelCanvas.rect(max(c.x, xPos), max(c.y, yPos), min(blockSize, xPos+elementWidth-c.x, blockSize+c.x-xPos), min(blockSize, yPos+elementHeight-c.y, blockSize+c.y-yPos));
                 panelCanvas.fill(255);
                 panelCanvas.textFont(getFont(8*jsManager.loadFloatSetting("text scale")));
                 panelCanvas.textAlign(CENTER, CENTER);
                 String s = ""+moveNodes[y1][x].cost;
                 s = s.substring(0, min(s.length(), 3));
                 BigDecimal cost = new BigDecimal(s);
                 String s2 = cost.stripTrailingZeros().toPlainString();
                 if (c.x+panelCanvas.textWidth(s2) < elementWidth+xPos && c.y+2*(textAscent()+textDescent()) < elementHeight+yPos){
                   panelCanvas.text(s2, c.x+blockSize/2, c.y+blockSize/2);
                 }
               }
             }
           }
         }
       }
     }

     if (drawPath != null){
       for (int i=0; i<drawPath.size()-1;i++){
         if (lx <= drawPath.get(i)[0] && drawPath.get(i)[0] < hx && ly <= drawPath.get(i)[1] && drawPath.get(i)[1] < hy){
           panelCanvas.pushStyle();
           panelCanvas.stroke(255,0,0);
           panelCanvas.line(scaleX(drawPath.get(i)[0])+blockSize/2, scaleY(drawPath.get(i)[1])+blockSize/2, scaleX(drawPath.get(i+1)[0])+blockSize/2, scaleY(drawPath.get(i+1)[1])+blockSize/2);
           panelCanvas.popStyle();
         }
       }
     }
     else if (cellSelected && parties[selectedCellY][selectedCellX] != null){
       ArrayList<int[]> path = parties[selectedCellY][selectedCellX].path;
       if (path != null){
         for (int i=0; i<path.size()-1;i++){
           if (lx <= path.get(i)[0] && path.get(i)[0] < hx && ly <= path.get(i)[1] && path.get(i)[1] < hy){
             panelCanvas.pushStyle();
             panelCanvas.stroke(100);
             panelCanvas.line(scaleX(path.get(i)[0])+blockSize/2, scaleY(path.get(i)[1])+blockSize/2, scaleX(path.get(i+1)[0])+blockSize/2, scaleY(path.get(i+1)[1])+blockSize/2);
             panelCanvas.popStyle();
           }
         }
       }
     }

     panelCanvas.noFill();
     panelCanvas.stroke(0);
     panelCanvas.rect(xPos, yPos, elementWidth, elementHeight);
  }
  public int sign(float x){
    if(x > 0){
      return 1;
    }
    else if (x < 0){
      return -1;
    }
    return 0;
  }
  public void drawCroppedImage(int x, int y, int w, int h, PImage img, PGraphics panelCanvas){
    if (x+w>xPos && x<elementWidth+xPos && y+h>yPos && y<elementHeight+yPos){
      int newX = max(min(x, xPos+elementWidth), xPos);
      int newY = max(min(y, yPos+elementHeight), yPos);
      int imgX = max(0, newX-x, 0);
      int imgY = max(0, newY-y, 0);
      int imgW = min(max(elementWidth+xPos-x, -sign(elementWidth+xPos-x)*(x+w-newX)), img.width);
      int imgH = min(max(elementHeight+yPos-y, -sign(elementHeight+yPos-y)*(y+h-newY)), img.height);
      panelCanvas.image(img, newX, newY);
    }
  }
  public float scaleX(float x){
    return x*blockSize + mapXOffset + xPos;
  }
  public float scaleY(float y){
    return y*blockSize + mapYOffset + yPos;
  }
  public float scaleXInv(){
    return (mouseX-mapXOffset-xPos)/blockSize;
  }
  public float scaleYInv(){
    return (mouseY-mapYOffset-yPos)/blockSize;
  }
  public boolean mouseOver(){
    return mouseX > xPos && mouseX < xPos+elementWidth && mouseY > yPos && mouseY < yPos+elementHeight;
  }
}
//boolean isWater(int x, int y) {
//  //return max(new float[]{
//  //  noise(x*MAPNOISESCALE, y*MAPNOISESCALE),
//  //  noise((x+1)*MAPNOISESCALE, y*MAPNOISESCALE),
//  //  noise(x*MAPNOISESCALE, (y+1)*MAPNOISESCALE),
//  //  noise((x+1)*MAPNOISESCALE, (y+1)*MAPNOISESCALE),
//  //  })<jsManager.loadFloatSetting("water level");
//  for (float y1 = y; y1<=y+1;y1+=1.0/jsManager.loadFloatSetting("terrain detail")){
//    for (float x1 = x; x1<=x+1;x1+=1.0/jsManager.loadFloatSetting("terrain detail")){
//      if(noise(x1*MAPHEIGHTNOISESCALE, y1*MAPHEIGHTNOISESCALE)>jsManager.loadFloatSetting("water level")){
//        return false;
//      }
//    }
//  }
//  return true;
//}





class Map3D extends BaseMap implements Map{
  final int thickness = 10;
  final float PANSPEED = 0.5f, ROTSPEED = 0.002f;
  final float STUMPR = 0.5f, STUMPH = 4, LEAVESR = 5, LEAVESH = 15, TREERANDOMNESS=0.3f;
  final float HILLRAISE = 1.05f;
  final float GROUNDHEIGHT = 5;
  float panningSpeed = 0.05f;
  int x, y, w, h, prevT, frameTime;
  float hoveringX, hoveringY, oldHoveringX, oldHoveringY;
  float targetXOffset, targetYOffset;
  int selectedCellX, selectedCellY;
  PShape tiles, blueFlag, redFlag, battle, trees, selectTile, water, tileRect, pathLine, highlightingGrid;
  HashMap<String, PShape> taskObjs;
  HashMap<String, PShape[]> buildingObjs;
  PShape[] unitNumberObjects;
  PImage[] tempTileImages;
  float targetZoom, zoom, zoomv, tilt, tiltv, rot, rotv, focusedX, focusedY;
  PVector focusedV, heldPos;
  Boolean zooming, panning, mapActive, cellSelected;
  Node[][] moveNodes;
  float blockSize = 16;
  ArrayList<int[]> drawPath;
  HashMap<Integer, Integer> forestTiles;
  PGraphics canvas, refractionCanvas;
  HashMap<Integer, HashMap<Integer, Float>> downwardAngleCache;

  Map3D(int x, int y, int w, int h, int[][] terrain, Party[][] parties, Building[][] buildings, int mapWidth, int mapHeight) {
    this.x = x;
    this.y = y;
    this.w = w;
    this.h = h;
    this.terrain = terrain;
    this.parties = parties;
    this.buildings = buildings;
    this.mapWidth = mapWidth;
    this.mapHeight = mapHeight;
    blockSize = 32;
    zoom = height/2;
    tilt = PI/3;
    focusedX = round(mapWidth*blockSize/2);
    focusedY = round(mapHeight*blockSize/2);
    focusedV = new PVector(0, 0);
    heldPos = null;
    cellSelected = false;
    panning = false;
    zooming = false;
    buildingObjs = new HashMap<String, PShape[]>();
    taskObjs = new HashMap<String, PShape>();
    forestTiles = new HashMap<Integer, Integer>();
    canvas = createGraphics(width, height, P3D);
    refractionCanvas = createGraphics(width/4, height/4, P3D);
    downwardAngleCache = new HashMap<Integer, HashMap<Integer, Float>>();
    heightMap = new float[PApplet.parseInt((mapWidth+1)*(mapHeight+1)*pow(jsManager.loadFloatSetting("terrain detail"), 2))];
    targetXOffset = mapWidth/2*blockSize;
    targetXOffset = mapHeight/2*blockSize;
  }
  

  public float getDownwardAngle(int x, int y){
    if(!downwardAngleCache.containsKey(y)){
      downwardAngleCache.put(y, new HashMap<Integer, Float>());
    }
    if(downwardAngleCache.get(y).containsKey(x)){
      return downwardAngleCache.get(y).get(x);
    } else {
      PVector maxZCoord = new PVector();
      PVector minZCoord = new PVector();
      float maxZ = 0;
      float minZ = 1;
      for (float y1 = y; y1<=y+1;y1+=1.0f/jsManager.loadFloatSetting("terrain detail")){
        for (float x1 = x; x1<=x+1;x1+=1.0f/jsManager.loadFloatSetting("terrain detail")){
          float z = getRawHeight(x1, y1);
          if(z > maxZ){
            maxZCoord = new PVector(x1, y1);
            maxZ = z;
          } else if (z < minZ){
            minZCoord = new PVector(x1, y1);
            minZ = z;
          }
        }
      }
      PVector direction = minZCoord.sub(maxZCoord);
      float angle = atan2(direction.y, direction.x);
  
      downwardAngleCache.get(y).put(x, angle);
      return angle;
    }
  }
  
  public Node[][] getMoveNodes(){
    return moveNodes;
  }
  public boolean isPanning(){
    return panning;
  }
  public float getTargetZoom(){
    return targetZoom;
  }
  public boolean isMoving(){
    return focusedV.x != 0 || focusedV.y != 0;
  }

  public float getTargetOffsetX(){return 0;}
  public float getTargetOffsetY(){return 0;}
  public float getTargetBlockSize(){return 0;}
  public float getZoom(){
    return zoom;
  }
  public boolean isZooming(){
    return zooming;
  }
  public float getFocusedX(){
    return focusedX;
  }
  public float getFocusedY(){
    return focusedY;
  }
  public void setActive(boolean a){
    this.mapActive = a;
  }
  public void updateMoveNodes(Node[][] nodes) {
    moveNodes = nodes;
  }
  public void updatePath(ArrayList<int[]> nodes) {
    float x0, y0;
    drawPath = nodes;
    pathLine = createShape();
    pathLine.beginShape();
    pathLine.noFill();
    pathLine.stroke(255,0,0);
    for (int i=0; i<drawPath.size()-1;i++){
      for (int u=0; u<blockSize/8; u++){
        x0 = drawPath.get(i)[0]+(drawPath.get(i+1)[0]-drawPath.get(i)[0])*u/8+0.5f;
        y0 = drawPath.get(i)[1]+(drawPath.get(i+1)[1]-drawPath.get(i)[1])*u/8+0.5f;
        pathLine.vertex(x0*blockSize, y0*blockSize, 5+getHeight(x0, y0));
      }
    }
    pathLine.vertex((selectedCellX+0.5f)*blockSize, (selectedCellY+0.5f)*blockSize, 5+getHeight(selectedCellX+0.5f, selectedCellY+0.5f));
    pathLine.endShape();
  }
  public void cancelMoveNodes() {
    moveNodes = null;
  }
  public void cancelPath() {
    drawPath = null;
  }
  public void loadSettings(float mapXOffset, float mapYOffset, float blockSize) {
  }
  public float[] targetCell(int x, int y, float zoom) {
    targetXOffset = x*blockSize-width/2;
    targetYOffset = y*blockSize-height/2;
    panning = true;
    return new float[2];
  }


  public void selectCell(int x, int y) {
    cellSelected = true;
    selectedCellX = x;
    selectedCellY = y;
  }
  public void unselectCell() {
    cellSelected = false;
  }

  public float scaleXInv() {
    return hoveringX;
  }
  public float scaleYInv() {
    return hoveringY;
  }
  public void updateHoveringScale(){
    PVector mo = MousePosOnObject(mouseX, mouseY);
    hoveringX = (mo.x)/getObjectWidth()*mapWidth;
    hoveringY = (mo.y)/getObjectHeight()*mapHeight;
  }

  public void addTreeTile(int cellX, int cellY, int i) {
    forestTiles.put(cellX+cellY*mapWidth, i);
  }
  public void removeTreeTile(int cellX, int cellY) {
    trees.removeChild(forestTiles.get(cellX+cellY*mapWidth));
    for (Integer i : forestTiles.keySet()) {
      if (forestTiles.get(i) > forestTiles.get(cellX+cellY*mapWidth)) {
        forestTiles.put(i, forestTiles.get(i)-1);
      }
    }
    forestTiles.remove(cellX+cellY*mapWidth);
  }

  // void generateWater(int vertices){
  //  water = createShape(GROUP);
  //  PShape w;
  //  float scale = getObjectWidth()/vertices;
  //  w = createShape();
  //  w.setShininess(10);
  //  w.setSpecular(10);
  //  w.beginShape(TRIANGLE_STRIP);
  //  w.fill(color(0, 50, 150));
  //  for(int x = 0; x < vertices; x++){
  //    w.vertex(x*scale, y*scale, 1);
  //    w.vertex(x*scale, (y+1)*scale, 1);
  //  }
  //  w.endShape(CLOSE);
  //  water.addChild(w);
  //}

  public float getWaveHeight(float x, float y, float t){
    return sin(t/1000+y)+cos(t/1000+x)+2;
  }

  //void updateWater(int vertices){
  //  float scale = getObjectWidth()/vertices;
  //  for (int y = 0; y < vertices+1; y++){
  //    PShape w = water.getChild(y);
  //    for(int x = 0; x < vertices*2; x++){
  //      PVector v = w.getVertex(x);
  //      w.setVertex(x, v.x, v.y, getWaveHeight(v.x, v.y, millis()));
  //    }
  //  }
  //}

  public PShape generateTrees(int num, int vertices, float x1, float y1) {
    PShape shapes = createShape(GROUP);
    colorMode(HSB, 100);
    for (int i=0; i<num; i++) {
      float x = random(0, blockSize), y = random(0, blockSize);
      float h = getHeight((x1+x)/blockSize, (y1+y)/blockSize);
      if (h <= 0) continue;
      int leafColour = color(random(35, 40), random(90, 100), random(30, 60));
      PShape leaves = createShape();
      leaves.setShininess(0.1f);
      leaves.beginShape(TRIANGLES);
      leaves.fill(leafColour);

      // create tree
      for (int j=0; j<vertices; j++) {
        leaves.vertex(x+cos(j*TWO_PI/vertices), y+sin(j*TWO_PI/vertices), STUMPH+h);
        leaves.vertex(x, y, STUMPH+LEAVESH*random(1-TREERANDOMNESS, 1+TREERANDOMNESS)+h);
        leaves.vertex(x+cos((j+1)*TWO_PI/vertices)*LEAVESR, y+sin((j+1)*TWO_PI/vertices)*LEAVESR, STUMPH+h);
      }
      leaves.endShape(CLOSE);
      shapes.addChild(leaves);
    }
    colorMode(RGB, 255);
    return shapes;
  }

  public void clearShape(){
    // Use to clear references to large objects when exiting state
    water = null;
    trees = null;
    tiles = null;
    buildingObjs = new HashMap<String, PShape[]>();
    taskObjs = new HashMap<String, PShape>();
    forestTiles = new HashMap<Integer, Integer>();
  }

  public void generateShape() {
    pushStyle();
    noFill();
    noStroke();
    tempTileImages = new PImage[gameData.getJSONArray("terrain").size()];
    for (int i=0; i<gameData.getJSONArray("terrain").size(); i++) {
      JSONObject tileType = gameData.getJSONArray("terrain").getJSONObject(i);
      if(tile3DImages.containsKey(tileType.getString("id"))){
        tempTileImages[i] = tile3DImages.get(tileType.getString("id")).copy();
      } else {
        tempTileImages[i] = tileImages.get(tileType.getString("id")).copy();
      }
      tempTileImages[i].resize(jsManager.loadIntSetting("terrain texture resolution"), jsManager.loadIntSetting("terrain texture resolution"));
    }
    PGraphics tempTerrain;

    water = createShape(RECT, 0, 0, getObjectWidth(), getObjectHeight());
    water.translate(0, 0, 0.1f);
    generateHighlightingGrid(8, 8);

    tiles = createShape(GROUP);
    textureMode(IMAGE);
    trees = createShape(GROUP);
    PShape t;
    int numTreeTiles=0;
    for (int y=0; y<mapHeight; y++) {
      tempTerrain = createGraphics(round((1+mapWidth)*jsManager.loadIntSetting("terrain texture resolution")), round(jsManager.loadIntSetting("terrain texture resolution")));
      tempTerrain.beginDraw();
      for (int x=0; x<mapWidth; x++) {
        tempTerrain.image(tempTileImages[terrain[y][x]-1], x*jsManager.loadIntSetting("terrain texture resolution"), 0);
      }
      tempTerrain.endDraw();

      for (int y1=0; y1<jsManager.loadFloatSetting("terrain detail"); y1++) {
        t = createShape();
        t.setTexture(tempTerrain);
        //t.setShininess(0.1);
        //t.setEmissive(color(0, 20, 20));
        //t.setSpecular(color(0, 20, 20));
        t.beginShape(TRIANGLE_STRIP);
        resetMatrix();
        t.vertex(0, (y+y1/jsManager.loadFloatSetting("terrain detail"))*blockSize, 0, 0, y1*jsManager.loadIntSetting("terrain texture resolution")/jsManager.loadFloatSetting("terrain detail"));
        t.vertex(0, (y+(1+y1)/jsManager.loadFloatSetting("terrain detail"))*blockSize, 0, 0, (y1+1)*jsManager.loadIntSetting("terrain texture resolution")/jsManager.loadFloatSetting("terrain detail"));
        for (int x=0; x<mapWidth; x++) {
          //int x1=(int)jsManager.loadFloatSetting("terrain detail");
          for (int x1=0; x1<jsManager.loadFloatSetting("terrain detail"); x1++) {
            t.vertex((x+x1/jsManager.loadFloatSetting("terrain detail"))*blockSize, (y+y1/jsManager.loadFloatSetting("terrain detail"))*blockSize, getHeight(x+x1/jsManager.loadFloatSetting("terrain detail"), (y+y1/jsManager.loadFloatSetting("terrain detail"))), (x+x1/jsManager.loadFloatSetting("terrain detail"))*jsManager.loadIntSetting("terrain texture resolution"), y1*jsManager.loadIntSetting("terrain texture resolution")/jsManager.loadFloatSetting("terrain detail"));
            t.vertex((x+x1/jsManager.loadFloatSetting("terrain detail"))*blockSize, (y+(1+y1)/jsManager.loadFloatSetting("terrain detail"))*blockSize, getHeight(x+x1/jsManager.loadFloatSetting("terrain detail"), y+(1+y1)/jsManager.loadFloatSetting("terrain detail")), (x+x1/jsManager.loadFloatSetting("terrain detail"))*jsManager.loadIntSetting("terrain texture resolution"), (y1+1)*jsManager.loadIntSetting("terrain texture resolution")/jsManager.loadFloatSetting("terrain detail"));
          }
        }
        t.vertex(mapWidth*blockSize, (y+y1/jsManager.loadFloatSetting("terrain detail"))*blockSize, getHeight(mapWidth, (y+y1/jsManager.loadFloatSetting("terrain detail"))), mapWidth*jsManager.loadIntSetting("terrain texture resolution"), (y1/jsManager.loadFloatSetting("terrain detail"))*jsManager.loadIntSetting("terrain texture resolution"));
        t.vertex(mapWidth*blockSize, (y+(1+y1)/jsManager.loadFloatSetting("terrain detail"))*blockSize, getHeight(mapWidth, y+(1.0f+y1)/jsManager.loadFloatSetting("terrain detail")), mapWidth*jsManager.loadIntSetting("terrain texture resolution"), ((y1+1.0f)/jsManager.loadFloatSetting("terrain detail"))*jsManager.loadIntSetting("terrain texture resolution"));
        //t.vertex(mapWidth*blockSize, (y+y1/jsManager.loadFloatSetting("terrain detail"))*blockSize, 0, mapWidth*jsManager.loadIntSetting("terrain texture resolution"), (y1/jsManager.loadFloatSetting("terrain detail"))*jsManager.loadIntSetting("terrain texture resolution"));
        //t.vertex(mapWidth*blockSize, (y+(1+y1)/jsManager.loadFloatSetting("terrain detail"))*blockSize, 0, mapWidth*jsManager.loadIntSetting("terrain texture resolution"), ((y1+1.0)/jsManager.loadFloatSetting("terrain detail"))*jsManager.loadIntSetting("terrain texture resolution"));
        t.endShape();
        tiles.addChild(t);
      }
      for (int x=0; x<mapWidth; x++) {
        if (terrain[y][x] == JSONIndex(gameData.getJSONArray("terrain"), "forest")+1) {
          PShape cellTree = generateTrees(jsManager.loadIntSetting("forest density"), 16, x*blockSize, y*blockSize);
          cellTree.translate((x)*blockSize, (y)*blockSize, 0);
          trees.addChild(cellTree);
          addTreeTile(x, y, numTreeTiles++);
        }
      }
    }
    resetMatrix();

    blueFlag = loadShape("blueflag.obj");
    blueFlag.rotateX(PI/2);
    blueFlag.scale(2.6f, 3, 3);
    redFlag = loadShape("redflag.obj");
    redFlag.rotateX(PI/2);
    redFlag.scale(2.6f, 3, 3);
    battle = loadShape("battle.obj");
    battle.rotateX(PI/2);
    
    
    int players = 2;
    fill(255);
    
    unitNumberObjects = new PShape[players+1];
    for (int i=0;i < players; i++){
      unitNumberObjects[i] = createShape();
      unitNumberObjects[i].beginShape(QUADS);
      unitNumberObjects[i].setStroke(1);
      unitNumberObjects[i].stroke(0);
      unitNumberObjects[i].fill(120, 120, 120);
      unitNumberObjects[i].vertex(blockSize, 0, 0);
      unitNumberObjects[i].fill(120, 120, 120);
      unitNumberObjects[i].vertex(blockSize, blockSize*0.125f, 0);
      unitNumberObjects[i].fill(120, 120, 120);
      unitNumberObjects[i].vertex(blockSize, blockSize*0.125f, 0);
      unitNumberObjects[i].fill(120, 120, 120);
      unitNumberObjects[i].vertex(blockSize, 0, 0);
      unitNumberObjects[i].fill(playerColours[i]);
      unitNumberObjects[i].vertex(0, 0, 0);
      unitNumberObjects[i].fill(playerColours[i]);
      unitNumberObjects[i].vertex(0, blockSize*0.125f, 0);
      unitNumberObjects[i].fill(playerColours[i]);
      unitNumberObjects[i].vertex(blockSize, blockSize*0.125f, 0);
      unitNumberObjects[i].fill(playerColours[i]);
      unitNumberObjects[i].vertex(blockSize, 0, 0);
      unitNumberObjects[i].endShape();
      unitNumberObjects[i].rotateX(PI/2);
      //unitNumberObjects[i].setStroke(false);
    }
    unitNumberObjects[2] = createShape();
    unitNumberObjects[2].beginShape(QUADS);
    unitNumberObjects[2].setStroke(1);
    unitNumberObjects[2].stroke(0);
    unitNumberObjects[2].fill(120, 120, 120);
    unitNumberObjects[2].vertex(blockSize, 0, 0);
    unitNumberObjects[2].fill(120, 120, 120);
    unitNumberObjects[2].vertex(blockSize, blockSize*0.0625f, 0);
    unitNumberObjects[2].fill(120, 120, 120);
    unitNumberObjects[2].vertex(blockSize, blockSize*0.0625f, 0);
    unitNumberObjects[2].fill(120, 120, 120);
    unitNumberObjects[2].vertex(blockSize, 0, 0);
    unitNumberObjects[2].fill(playerColours[0]);
    unitNumberObjects[2].vertex(0, 0, 0);
    unitNumberObjects[2].fill(playerColours[0]);
    unitNumberObjects[2].vertex(0, blockSize*0.0625f, 0);
    unitNumberObjects[2].fill(playerColours[0]);
    unitNumberObjects[2].vertex(blockSize, blockSize*0.0625f, 0);
    unitNumberObjects[2].fill(playerColours[0]);
    unitNumberObjects[2].vertex(blockSize, 0, 0);
    unitNumberObjects[2].fill(120, 120, 120);
    unitNumberObjects[2].vertex(blockSize, blockSize*0.0625f, 0);
    unitNumberObjects[2].fill(120, 120, 120);
    unitNumberObjects[2].vertex(blockSize, blockSize*0.125f, 0);
    unitNumberObjects[2].fill(120, 120, 120);
    unitNumberObjects[2].vertex(blockSize, blockSize*0.125f, 0);
    unitNumberObjects[2].fill(120, 120, 120);
    unitNumberObjects[2].vertex(blockSize, blockSize*0.0625f, 0);
    unitNumberObjects[2].fill(playerColours[1]);
    unitNumberObjects[2].vertex(0, blockSize*0.0625f, 0);
    unitNumberObjects[2].fill(playerColours[1]);
    unitNumberObjects[2].vertex(0, blockSize*0.125f, 0);
    unitNumberObjects[2].fill(playerColours[1]);
    unitNumberObjects[2].vertex(blockSize, blockSize*0.125f, 0);
    unitNumberObjects[2].fill(playerColours[1]);
    unitNumberObjects[2].vertex(blockSize, blockSize*0.0625f, 0);
    unitNumberObjects[2].endShape();
    unitNumberObjects[2].rotateX(PI/2);
    //unitNumberObjects[2].setStroke(false);
    tileRect = createShape();
    tileRect.beginShape();
    tileRect.noFill();
    tileRect.stroke(0);
    tileRect.strokeWeight(3);
    int[][] directions = {{0, 1}, {1, 0}, {0, -1}, {-1, 0}};
    int[] curLoc = {0, 0};
    for (int[] dir : directions){
      for (int i=0; i<jsManager.loadFloatSetting("terrain detail"); i++){
        tileRect.vertex(curLoc[0]*blockSize/jsManager.loadFloatSetting("terrain detail"), curLoc[1]*blockSize/jsManager.loadFloatSetting("terrain detail"), 0);
        curLoc[0] += dir[0];
        curLoc[1] += dir[1];
      }
    }
    tileRect.endShape(CLOSE);
    for (int i=0; i<gameData.getJSONArray("tasks").size(); i++) {
      JSONObject task = gameData.getJSONArray("tasks").getJSONObject(i);
      if (!task.isNull("img")) {
        PShape object = createShape(RECT, 0, 0, blockSize/2, blockSize/2);
        object.setFill(color(255, 255, 255));
        object.setTexture(taskImages[i]);
        taskObjs.put(task.getString("id"), object);
        taskObjs.get(task.getString("id")).rotateX(-PI/2);
      }
    }
    for (int i=0; i<gameData.getJSONArray("buildings").size(); i++) {
      JSONObject buildingType = gameData.getJSONArray("buildings").getJSONObject(i);
      if (!buildingType.isNull("obj")) {
        buildingObjs.put(buildingType.getString("id"), new PShape[buildingType.getJSONArray("obj").size()]);
        for (int j=0; j<buildingType.getJSONArray("obj").size(); j++) {
          buildingObjs.get(buildingType.getString("id"))[j] = loadShape(buildingType.getJSONArray("obj").getString(j));
          buildingObjs.get(buildingType.getString("id"))[j].rotateX(PI/2);
        }
      }
    }

    popStyle();
  }
  
  public void generateHighlightingGrid(int horizontals, int verticles){
    PShape line;
    // Load horizontal lines first
    highlightingGrid = createShape(GROUP);
    for (int i=0; i<horizontals; i++){
      line = createShape();
      line.beginShape();
      line.noFill();
      for (int x1=0; x1<jsManager.loadFloatSetting("terrain detail")*(verticles-1)+1; x1++){
        float x2 = -horizontals/2+0.5f+x1/jsManager.loadFloatSetting("terrain detail");
        float y1 = -verticles/2+i+0.5f;
        line.stroke(255,255,255,255-sqrt(pow(x2, 2)+pow(y1, 2))/3*255);
        line.vertex(0, 0, 0);
      }
      line.endShape();
      highlightingGrid.addChild(line);
    }
    // Next do verticle lines
    for (int i=0; i<verticles; i++){
      line = createShape();
      line.beginShape();
      line.noFill();
      for (int y1=0; y1<jsManager.loadFloatSetting("terrain detail")*(horizontals-1)+1; y1++){
        float y2 = -verticles/2+0.5f+y1/jsManager.loadFloatSetting("terrain detail");
        float x1 = -horizontals/2+i+0.5f;
        line.stroke(255,255,255,255-sqrt(pow(y2, 2)+pow(x1, 2))/3*255);
        line.vertex(0, 0, 0);
      }
      line.endShape();
      highlightingGrid.addChild(line);
    }
  }
  
  public void updateHighlightingGrid(int x, int y, int horizontals, int verticles){
    // x, y are cell coordinates
    PShape line;
    for (int i=0; i<horizontals; i++){
      line = highlightingGrid.getChild(i);
      for (int x1=0; x1<jsManager.loadFloatSetting("terrain detail")*(verticles-1)+1; x1++){
        float x2 = x-horizontals/2+1+x1/jsManager.loadFloatSetting("terrain detail");
        float y1 = y-verticles/2+1+i;
        line.setVertex(x1, x2*blockSize, y1*blockSize, 0.1f+getHeight(x2, y1));
      }
    }
    // verticle lines
    for (int i=0; i<verticles; i++){
      line = highlightingGrid.getChild(i+horizontals);
      for (int y1=0; y1<jsManager.loadFloatSetting("terrain detail")*(horizontals-1)+1; y1++){
        float x1 = x-horizontals/2+1+i;
        float y2 = y-verticles/2+1+y1/jsManager.loadFloatSetting("terrain detail");
        line.setVertex(y1, x1*blockSize, y2*blockSize, 0.1f+getHeight(x1, y2));
      }
    }
  }

  public void updateSelectionRect(int cellX, int cellY){
    int[][] directions = {{0, 1}, {1, 0}, {0, -1}, {-1, 0}};
    int[] curLoc = {0, 0};
    int a = 0;
    for (int[] dir : directions){
      for (int i=0; i<jsManager.loadFloatSetting("terrain detail"); i++){
        tileRect.setVertex(a++, curLoc[0]*blockSize/jsManager.loadFloatSetting("terrain detail"), curLoc[1]*blockSize/jsManager.loadFloatSetting("terrain detail"), getHeight(cellX+curLoc[0]/jsManager.loadFloatSetting("terrain detail"), cellY+curLoc[1]/jsManager.loadFloatSetting("terrain detail")));
        curLoc[0] += dir[0];
        curLoc[1] += dir[1];
      }
    }
  }

  public PVector MousePosOnObject(int mx, int my) {
    applyCameraPerspective();
    PVector floorPos = new PVector(focusedX+width/2, focusedY+height/2, 0);
    PVector floorDir = new PVector(0, 0, -1);
    PVector mousePos = getUnProjectedPointOnFloor( mouseX, mouseY, floorPos, floorDir);
    camera();
    return mousePos;
  }

  public float getObjectWidth() {
    return mapWidth*blockSize;
  }
  public float getObjectHeight() {
    return mapHeight*blockSize;
  }
  public void setZoom(float zoom) {
    this.zoom =  between(height/4, zoom, min(mapHeight*blockSize, height*4));
  }
  public void setTilt(float tilt) {
    this.tilt = between(0.01f, tilt, 3*PI/8);
  }
  public void setRot(float rot) {
    this.rot = rot;
  }
  public void setFocused(float focusedX, float focusedY) {
    this.focusedX = between(-width/2, focusedX, getObjectWidth()-width/2);
    this.focusedY = between(-height/2, focusedY, getObjectHeight()-height/2);
  }

  public ArrayList<String> mouseEvent(String eventType, int button) {
    if (eventType.equals("mouseDragged")) {
      if (mouseButton == LEFT) {
        //if (heldPos != null){

        //camera(prevFx+width/2+zoom*sin(tilt)*sin(rot), prevFy+height/2+zoom*sin(tilt)*cos(rot), zoom*cos(tilt), prevFy+width/2, focusedY+height/2, 0, 0, 0, -1);
        //PVector newHeldPos = MousePosOnObject(mouseX, mouseY);
        //camera();
        //focusedX = heldX-(newHeldPos.x-heldPos.x);
        //focusedY = heldY-(newHeldPos.y-heldPos.y);
        //prevFx = heldX-(newHeldPos.x-heldPos.x);
        //prevFy = heldY-(newHeldPos.y-heldPos.y);
        //heldPos.x = newHeldPos.x;
        //heldPos.y = newHeldPos.y;
        //}
      } else if (mouseButton != RIGHT) {
        setTilt(tilt-(mouseY-pmouseY)*0.01f);
        setRot(rot-(mouseX-pmouseX)*0.01f);
        updateHoveringScale();
      }
    }
    //else if (eventType.equals("mousePressed")){
    //  if (button == LEFT){
    //    camera(focusedX+width/2+zoom*sin(tilt)*sin(rot), focusedY+height/2+zoom*sin(tilt)*cos(rot), zoom*cos(tilt), focusedX+width/2, focusedY+height/2, 0, 0, 0, -1);
    //    heldPos = MousePosOnObject(mouseX, mouseY);
    //    heldX = focusedX;
    //    heldY = focusedY;
    //    camera();
    //  }
    //}
    //else if (eventType.equals("mouseReleased")){
    //  if (button == LEFT){
    //    heldPos = null;
    //  }
    //}
    return new ArrayList<String>();
  }


  public ArrayList<String> mouseEvent(String eventType, int button, MouseEvent event) {
    if (eventType == "mouseWheel") {
      float count = event.getCount();
      setZoom(zoom+zoom*count*0.15f);
    }
    return new ArrayList<String>();
  }
  public ArrayList<String> keyboardEvent(String eventType, char _key) {
    if (eventType.equals("keyPressed")) {
      if (_key == 'w') {
        focusedV.y -= PANSPEED;
        panning = false;
      }
      if (_key == 's') {
        focusedV.y += PANSPEED;
        panning = false;
      }
      if (_key == 'a') {
        focusedV.x -= PANSPEED;
        panning = false;
      }
      if (_key == 'd') {
        focusedV.x += PANSPEED;
        panning = false;
      }
      if (_key == 'q') {
        rotv -= ROTSPEED;
      }
      if (_key == 'e') {
        rotv += ROTSPEED;
      }
      if (_key == 'x') {
        tiltv += ROTSPEED;
      }
      if (_key == 'c') {
        tiltv -= ROTSPEED;
      }
      if (_key == 'f') {
        zoomv += PANSPEED;
      }
      if (_key == 'r') {
        zoomv -= PANSPEED;
      }
    } else if (eventType.equals("keyReleased")) {
      if (_key == 'w') {
        focusedV.y += PANSPEED;
        panning = false;
      }
      if (_key == 's') {
        focusedV.y -= PANSPEED;
        panning = false;
      }
      if (_key == 'a') {
        focusedV.x += PANSPEED;
        panning = false;
      }
      if (_key == 'd') {
        focusedV.x -= PANSPEED;
        panning = false;
      }
      if (_key == 'q') {
        rotv += ROTSPEED;
      }
      if (_key == 'e') {
        rotv -= ROTSPEED;
      }
      if (_key == 'x') {
        tiltv -= ROTSPEED;
      }
      if (_key == 'c') {
        tiltv += ROTSPEED;
      }
      if (_key == 'f') {
        zoomv -= PANSPEED;
      }
      if (_key == 'r') {
        zoomv += PANSPEED;
      }
    }
    return new ArrayList<String>();
  }
  public float getHeight(float x, float y) {
    //if (y<mapHeight && x<mapWidth && y+jsManager.loadFloatSetting("terrain detail")/blockSize<mapHeight && x+jsManager.loadFloatSetting("terrain detail")/blockSize<mapHeight && y-jsManager.loadFloatSetting("terrain detail")/blockSize>=0 && x-jsManager.loadFloatSetting("terrain detail")/blockSize>=0 &&
    //terrain[floor(y)][floor(x)] == JSONIndex(gameData.getJSONArray("terrain"), "hills")+1 &&
    //terrain[floor(y+jsManager.loadFloatSetting("terrain detail")/blockSize)][floor(x+jsManager.loadFloatSetting("terrain detail")/blockSize)] == JSONIndex(gameData.getJSONArray("terrain"), "hills")+1 && 
    //terrain[floor(y-jsManager.loadFloatSetting("terrain detail")/blockSize)][floor(x-jsManager.loadFloatSetting("terrain detail")/blockSize)] == JSONIndex(gameData.getJSONArray("terrain"), "hills")+1){
    //  return (max(noise(x*MAPNOISESCALE, y*MAPNOISESCALE), waterLevel)-waterLevel)*blockSize*GROUNDHEIGHT*HILLRAISE;
    //} else {
      return (max(getRawHeight(x, y), jsManager.loadFloatSetting("water level"))-jsManager.loadIntSetting("water level"))*blockSize*GROUNDHEIGHT;
      //float h = (max(noise(x*MAPNOISESCALE, y*MAPNOISESCALE), waterLevel)-waterLevel);
      //return (max(h-(0.5+waterLevel/2.0), 0)*(1000)+h)*blockSize*GROUNDHEIGHT;
    //}
  }
  public float groundMinHeightAt(int x1, int y1) {
    int x = floor(x1);
    int y = floor(y1);
    return min(new float[]{getHeight(x, y), getHeight(x+1, y), getHeight(x, y+1), getHeight(x+1, y+1)});
  }
  public float groundMaxHeightAt(int x1, int y1) {
    int x = floor(x1);
    int y = floor(y1);
    return max(new float[]{getHeight(x, y), getHeight(x+1, y), getHeight(x, y+1), getHeight(x+1, y+1)});
  }

  public void applyCameraPerspective(){
    float fov = PI/3.0f;
    float cameraZ = (height/2.0f) / tan(fov/2.0f);
    perspective(fov, PApplet.parseFloat(width)/PApplet.parseFloat(height), cameraZ/100.0f, cameraZ*10.0f);
    applyCamera();
  }


  public void applyCameraPerspective(PGraphics canvas){
    float fov = PI/3.0f;
    float cameraZ = (height/2.0f) / tan(fov/2.0f);
    canvas.perspective(fov, PApplet.parseFloat(width)/PApplet.parseFloat(height), cameraZ/100.0f, cameraZ*10.0f);
    applyCamera(canvas);
  }


  public void applyCamera(){
    camera(focusedX+width/2+zoom*sin(tilt)*sin(rot), focusedY+height/2+zoom*sin(tilt)*cos(rot), zoom*cos(tilt), focusedX+width/2, focusedY+height/2, 0, 0, 0, -1);
  }


  public void applyCamera(PGraphics canvas){
    canvas.camera(focusedX+width/2+zoom*sin(tilt)*sin(rot), focusedY+height/2+zoom*sin(tilt)*cos(rot), zoom*cos(tilt), focusedX+width/2, focusedY+height/2, 0, 0, 0, -1);
  }

  public void applyInvCamera(PGraphics canvas){
    canvas.camera(focusedX+width/2+zoom*sin(tilt)*sin(rot), focusedY+height/2+zoom*sin(tilt)*cos(rot), -zoom*cos(tilt), focusedX+width/2, focusedY+height/2, 0, 0, 0, -1);
  }


  public void draw(PGraphics panelCanvas) {

    // Update camera position and orientation
    frameTime = millis()-prevT;
    prevT = millis();
    focusedV.x = between(-PANSPEED, focusedV.x, PANSPEED);
    focusedV.y = between(-PANSPEED, focusedV.y, PANSPEED);
    rotv = between(-ROTSPEED, rotv, ROTSPEED);
    tiltv = between(-ROTSPEED, tiltv, ROTSPEED);
    zoomv = between(-PANSPEED, zoomv, PANSPEED);
    PVector p = focusedV.copy().rotate(-rot).mult(frameTime*pow(zoom, 0.5f)/20);
    focusedX += p.x;
    focusedY += p.y;
    rot += rotv*frameTime;
    tilt += tiltv*frameTime;
    zoom += zoomv*frameTime;
    
    if (panning){
      focusedX -= (focusedX-targetXOffset)*panningSpeed*frameTime*60/1000;
      focusedY -= (focusedY-targetYOffset)*panningSpeed*frameTime*60/1000;
      // Stop panning when very close
      if (abs(focusedX-targetXOffset) < 1 && abs(focusedY-targetYOffset) < 1){
        panning = false;
      }
    }
    
    // update highlight grid if hovering over diffent pos
    if (!(hoveringX == oldHoveringX && hoveringY == oldHoveringY) ){
      updateHighlightingGrid(floor(hoveringX), floor(hoveringY), 8, 8);
      oldHoveringX = hoveringX;
      oldHoveringY = hoveringY;
    }

    // Check camera ok
    setZoom(zoom);
    setRot(rot);
    setTilt(tilt);
    setFocused(focusedX, focusedY);

    pushStyle();
    hint(ENABLE_DEPTH_TEST);

    // Render 3D stuff from normal camera view onto refraction canvas for refraction effect in water
    //refractionCanvas.beginDraw();
    //refractionCanvas.background(#7ED7FF);
    //float fov = PI/3.0;
    //float cameraZ = (height/2.0) / tan(fov/2.0);
    //applyCamera(refractionCanvas);
    ////refractionCanvas.perspective(fov, float(width)/float(height), 1, 100);
    //refractionCanvas.shader(toon);
    //renderScene(refractionCanvas);
    //refractionCanvas.resetShader();
    //refractionCanvas.camera();
    //refractionCanvas.endDraw();

    //water.setTexture(refractionCanvas);

    // Render 3D stuff from normal camera view
    canvas.beginDraw();
    canvas.background(0xff7ED7FF);
    applyCameraPerspective(canvas);
    renderWater(canvas);
    renderScene(canvas);
    //canvas.box(0, 0, getObjectWidth(), getObjectHeight(), 1, 100);
    canvas.camera();
    canvas.endDraw();


    //Remove all 3D effects for GUI rendering
    hint(DISABLE_DEPTH_TEST);
    camera();
    noLights();
    resetShader();
    popStyle();

    //draw the scene to the screen
    panelCanvas.image(canvas, 0, 0);
    //image(refractionCanvas, 0, 0);

  }

  public void renderWater(PGraphics canvas){
    //Draw water
    canvas.pushMatrix();
    canvas.shape(water);
    canvas.popMatrix();
  }

  public void drawPath(PGraphics canvas){
    float x0, y0;
    if (drawPath != null){
      canvas.shape(pathLine);
    }
  }

  public void renderScene(PGraphics canvas){

    canvas.directionalLight(240, 255, 255, 0, -0.1f, -1);
    //canvas.directionalLight(100, 100, 100, 0.1, 1, -1);
    //canvas.lightSpecular(102, 102, 102);
    canvas.shape(tiles);
    canvas.ambientLight(100, 100, 100);
    canvas.shape(trees);
    


    canvas.pushMatrix();
    //noLights();
    if (cellSelected) {
      canvas.pushMatrix();
      canvas.stroke(0);
      canvas.strokeWeight(3);
      canvas.noFill();
      canvas.translate(selectedCellX*blockSize, (selectedCellY)*blockSize, 0);
      updateSelectionRect(selectedCellX, selectedCellY);
      canvas.shape(tileRect);
      canvas.translate(0, 0, groundMinHeightAt(selectedCellX, selectedCellY));
      canvas.strokeWeight(1);
      if (parties[selectedCellY][selectedCellX] != null) {
        canvas.translate(blockSize/2, blockSize/2, 32);
        canvas.box(blockSize, blockSize, 64);
      } else {
        canvas.translate(blockSize/2, blockSize/2, 16);
        canvas.box(blockSize, blockSize, 32);
      }
      canvas.popMatrix();
    }


    for (int x=0; x<mapWidth; x++) {
      for (int y=0; y<mapHeight; y++) {
        if (buildings[y][x] != null) {
          if (buildingObjs.get(buildingString(buildings[y][x].type)) != null) {
            canvas.lights();
            canvas.pushMatrix();
            if(buildings[y][x].type==buildingIndex("Mine")){
              canvas.translate((x+0.5f)*blockSize, (y+0.5f)*blockSize, 16+groundMinHeightAt(x, y));
              canvas.rotateZ(getDownwardAngle(x, y));
            } else {
              canvas.translate((x+0.5f)*blockSize, (y+0.5f)*blockSize, 16+groundMaxHeightAt(x, y));
            }
            canvas.shape(buildingObjs.get(buildingString(buildings[y][x].type))[buildings[y][x].image_id]);
            canvas.popMatrix();
          }
        }
        if(parties[y][x] != null){
          canvas.noLights();
          if (parties[y][x].player == 0) {
            canvas.pushMatrix();
            canvas.translate((x+0.5f-0.4f)*blockSize, (y+0.5f)*blockSize, 30+groundMinHeightAt(x, y));
            canvas.shape(blueFlag);
            canvas.popMatrix();
          } else if (parties[y][x].player == 1) {
            canvas.pushMatrix();
            canvas.translate((x+0.5f-0.4f)*blockSize, (y+0.5f)*blockSize, 30+groundMinHeightAt(x, y));
            canvas.shape(redFlag);
            canvas.popMatrix();
          } else if (parties[y][x].player == 2) {
            canvas.pushMatrix();
            canvas.translate((x+0.5f)*blockSize, (y+0.5f)*blockSize, 16+groundMaxHeightAt(x, y));
            canvas.shape(battle);
            canvas.popMatrix();
          }
          if(parties[y][x].player!=2){
            canvas.noLights();
            canvas.pushMatrix();
            canvas.translate((x+0.5f+sin(rot)*0.5f)*blockSize, (y+0.5f+cos(rot)*0.5f)*blockSize, blockSize*2.25f+groundMinHeightAt(x, y));
            canvas.rotateZ(-this.rot);
            canvas.translate(-0.5f*blockSize, -0.5f*blockSize);
            unitNumberObjects[parties[y][x].player].setVertex(0, blockSize*parties[y][x].getUnitNumber()/1000, 0, 0);
            unitNumberObjects[parties[y][x].player].setVertex(1, blockSize*parties[y][x].getUnitNumber()/1000, blockSize*0.125f, 0);
            unitNumberObjects[parties[y][x].player].setVertex(2, blockSize, blockSize*0.125f, 0);
            unitNumberObjects[parties[y][x].player].setVertex(3, blockSize, 0, 0);
            unitNumberObjects[parties[y][x].player].setVertex(4, 0, 0, 0);
            unitNumberObjects[parties[y][x].player].setVertex(5, 0, blockSize*0.125f, 0);
            unitNumberObjects[parties[y][x].player].setVertex(6, blockSize*parties[y][x].getUnitNumber()/1000, blockSize*0.125f, 0);
            unitNumberObjects[parties[y][x].player].setVertex(7, blockSize*parties[y][x].getUnitNumber()/1000, 0, 0);
            canvas.shape(unitNumberObjects[parties[y][x].player]);
            canvas.popMatrix();
          } else {
            Battle battle = (Battle) parties[y][x];
            unitNumberObjects[battle.party1.player].setVertex(0, blockSize*battle.party1.getUnitNumber()/1000, 0, 0);
            unitNumberObjects[battle.party1.player].setVertex(1, blockSize*battle.party1.getUnitNumber()/1000, blockSize*0.0625f, 0);
            unitNumberObjects[battle.party1.player].setVertex(2, blockSize, blockSize*0.0625f, 0);
            unitNumberObjects[battle.party1.player].setVertex(3, blockSize, 0, 0);
            unitNumberObjects[battle.party1.player].setVertex(4, 0, 0, 0);
            unitNumberObjects[battle.party1.player].setVertex(5, 0, blockSize*0.0625f, 0);
            unitNumberObjects[battle.party1.player].setVertex(6, blockSize*battle.party1.getUnitNumber()/1000, blockSize*0.0625f, 0);
            unitNumberObjects[battle.party1.player].setVertex(7, blockSize*battle.party1.getUnitNumber()/1000, 0, 0);
            unitNumberObjects[battle.party2.player].setVertex(0, blockSize*battle.party2.getUnitNumber()/1000, blockSize*0.0625f, 0);
            unitNumberObjects[battle.party2.player].setVertex(1, blockSize*battle.party2.getUnitNumber()/1000, blockSize*0.125f, 0);
            unitNumberObjects[battle.party2.player].setVertex(2, blockSize, blockSize*0.125f, 0);
            unitNumberObjects[battle.party2.player].setVertex(3, blockSize, blockSize*0.0625f, 0);
            unitNumberObjects[battle.party2.player].setVertex(4, 0, blockSize*0.0625f, 0);
            unitNumberObjects[battle.party2.player].setVertex(5, 0, blockSize*0.125f, 0);
            unitNumberObjects[battle.party2.player].setVertex(6, blockSize*battle.party2.getUnitNumber()/1000, blockSize*0.125f, 0);
            unitNumberObjects[battle.party2.player].setVertex(7, blockSize*battle.party2.getUnitNumber()/1000, blockSize*0.0625f, 0);
            canvas.noLights();
            canvas.pushMatrix();
            canvas.translate((x+0.5f+sin(rot)*0.5f)*blockSize, (y+0.5f+cos(rot)*0.5f)*blockSize, blockSize*2.25f+groundMinHeightAt(x, y));
            canvas.rotateZ(-this.rot);
            canvas.translate(-0.5f*blockSize, -0.5f*blockSize);
            canvas.shape(unitNumberObjects[battle.party1.player]);
            canvas.shape(unitNumberObjects[battle.party2.player]);
            canvas.popMatrix();
          }
          JSONObject jo = gameData.getJSONArray("tasks").getJSONObject(parties[y][x].task);
          if (jo != null && !jo.isNull("img")){
            canvas.noLights();
            canvas.pushMatrix();
            canvas.translate((x+0.5f+sin(rot)*0.25f)*blockSize, (y+0.5f+cos(rot)*0.25f)*blockSize, blockSize*3+groundMinHeightAt(x, y));
            canvas.rotateZ(-this.rot);
            canvas.translate(-0.25f*blockSize, -0.25f*blockSize);
            canvas.shape(taskObjs.get(jo.getString("id")));
            canvas.popMatrix();
          }
        }
      }
    }
    canvas.popMatrix();

    canvas.pushMatrix();
    drawPath(canvas);
    PVector mv = MousePosOnObject(mouseX, mouseY).div(blockSize);
    if(0<mv.x&&mv.x<mapWidth&&0<mv.y&&mv.y<mapHeight){
      canvas.shape(highlightingGrid);
    }
    canvas.popMatrix();

  }

  public void renderTexturedEntities(PGraphics canvas){

  }

  public String buildingString(int buildingI) {
    if (gameData.getJSONArray("buildings").isNull(buildingI-1)) {
      println("invalid building string ", buildingI-1);
      return null;
    }
    return gameData.getJSONArray("buildings").getJSONObject(buildingI-1).getString("id");
  }

  public boolean mouseOver() {
    return mouseX > x && mouseX < x+w && mouseY > y && mouseY < y+h;
  }

  public float getRayHeightAt(PVector r, PVector s, float targetX){
    PVector start = s.copy();
    PVector ray = r.copy();
    float dz_dx = ray.z/ray.x;
    return start.z + (targetX - start.x) * dz_dx;
  }

  public boolean rayPassesThrough(PVector r, PVector s, PVector targetV){
    PVector start = s.copy();
    PVector ray = r.copy();
    start.add(ray);
    return start.dist(targetV) < blockSize/jsManager.loadFloatSetting("terrain detail");
  }



  // Ray Tracing Code Below is an example by Bontempos, modified for height map intersection by Jack Parsons
  // https://forum.processing.org/two/discussion/21644/picking-in-3d-through-ray-tracing-method

  // Function that calculates the coordinates on the floor surface corresponding to the screen coordinates
  public PVector getUnProjectedPointOnFloor(float screen_x, float screen_y, PVector floorPosition, PVector floorDirection) {

    PVector f = floorPosition.get(); // Position of the floor
    PVector n = floorDirection.get(); // The direction of the floor ( normal vector )
    PVector w = unProject(screen_x, screen_y, -1.0f); // 3 -dimensional coordinate corresponding to a point on the screen
    PVector e = getEyePosition(); // Viewpoint position

    // Computing the intersection of
    f.sub(e);
    w.sub(e);
    w.mult( n.dot(f)/n.dot(w) );
    PVector ray = w.copy();
    w.add(e);
    
    float acHeight, curX = e.x, curY = e.y;
    for (int i = 0; i < ray.mag(); i++){
      curX += ray.x/ray.mag();
      curY += ray.y/ray.mag();
      if (0 <= curX/blockSize && curX/blockSize <= mapWidth && 0 <= curY/blockSize && curY/blockSize < mapHeight){
        acHeight = getHeight(curX/blockSize, curY/blockSize);
        if (getRayHeightAt(ray, e, curX) < acHeight+0.00001f){
          return new PVector(curX, curY,acHeight);
        }
      }
    }

    return w;
  }

  // Function to get the position of the viewpoint in the current coordinate system
  public PVector getEyePosition() {
    applyCameraPerspective();
    PMatrix3D mat = (PMatrix3D)getMatrix(); //Get the model view matrix
    mat.invert();
    return new PVector( mat.m03, mat.m13, mat.m23 );
  }
  //Function to perform the conversion to the local coordinate system ( reverse projection ) from the window coordinate system
  public PVector unProject(float winX, float winY, float winZ) {
    PMatrix3D mat = getMatrixLocalToWindow();
    mat.invert();

    float[] in = {winX, winY, winZ, 1.0f};
    float[] out = new float[4];
    mat.mult(in, out);  // Do not use PMatrix3D.mult(PVector, PVector)

    if (out[3] == 0 ) {
      return null;
    }

    PVector result = new PVector(out[0]/out[3], out[1]/out[3], out[2]/out[3]);
    return result;
  }

  //Function to compute the transformation matrix to the window coordinate system from the local coordinate system
  public PMatrix3D getMatrixLocalToWindow() {
    PMatrix3D projection = ((PGraphics3D)g).projection;
    PMatrix3D modelview = ((PGraphics3D)g).modelview;

    // viewport transf matrix
    PMatrix3D viewport = new PMatrix3D();
    viewport.m00 = viewport.m03 = width/2;
    viewport.m11 = -height/2;
    viewport.m13 =  height/2;

    // Calculate the transformation matrix to the window coordinate system from the local coordinate system
    viewport.apply(projection);
    viewport.apply(modelview);
    return viewport;
  }
}



class Building{
  int type;
  int image_id;
  Building(int type){
    this(type, 0);
  }
  Building(int type, int image_id){
    this.type = type;
    this.image_id = image_id;
  }
}






class Party{
  private int unitNumber;
  private int movementPoints;
  int player;
  float strength;
  private int task;
  ArrayList<Action> actions;
  ArrayList<int[]> path;
  int[] target;
  int pathTurns;
  byte[]byteRep;
  Party(int player, int startingUnits, int startingTask, int movementPoints){
    unitNumber = startingUnits;
    task = startingTask;
    this.player = player;
    this.movementPoints = movementPoints;
    actions = new ArrayList<Action>();
    strength = 1.5f;
    clearPath();
    target = null;
    pathTurns = 0;
  }
  public void changeTask(int task){
    this.task = task;
    JSONObject jTask = gameData.getJSONArray("tasks").getJSONObject(this.getTask());
    if (!jTask.isNull("strength")){
      this.strength = jTask.getInt("strength");
    }
    else
      this.strength = 1.5f;
  }
  public void setPathTurns(int v){
    pathTurns = v;
  }
  public void moved(){
    pathTurns = max(pathTurns-1, 0);
  }
  public int getTask(){
    return task;
  }
  public int[] nextNode(){
    return path.get(0);
  }
  public void loadPath(ArrayList<int[]> p){
    path = p;
  }
  public void clearNode(){
    path.remove(0);
  }
  public void clearPath(){
    path = new ArrayList<int[]>();
    pathTurns=0;
  }
  public void addAction(Action a){
    actions.add(a);
  }
  public boolean hasActions(){
    return actions.size()>0;
  }
  public int turnsLeft(){
    return calcTurns(actions.get(0).turns);
  }
  public int calcTurns(float turnsCost){
    //Use this to calculate the number of turns a task will take for this party
    return ceil(turnsCost/(sqrt(unitNumber)/10));
  }
  public Action progressAction(){
    if (actions.size() == 0){
      return null;
    }
    else if (actions.get(0).turns-sqrt((float)unitNumber)/10 <= 0){
      return actions.get(0);
    }
    else{
      actions.get(0).turns -= sqrt((float)unitNumber)/10;
      if (gameData.getJSONArray("tasks").getJSONObject(actions.get(0).type).getString("id").contains("Build")) {
        if (actions.get(0).turns-sqrt((float)unitNumber)/10 <= 0){
          return new Action(JSONIndex(gameData.getJSONArray("tasks"), "Construction End"), "Construction End", 0, null, null);
        } else {
          return new Action(JSONIndex(gameData.getJSONArray("tasks"), "Construction Mid"), "Construction Mid", 0, null, null);
        }
      }
      return null;
    }
  }
  public void clearCurrentAction(){
    if (actions.size() > 0)
    actions.remove(0);
  }public void clearActions(){
    actions = new ArrayList<Action>();
  }
  public int currentAction(){
    return actions.get(0).type;
  }
  public boolean isTurn(int turn){
    return this.player==turn;
  }
  public int getMovementPoints(){
    return movementPoints;
  }
  public void subMovementPoints(int p){
    movementPoints -= p;
  }
  public void setMovementPoints(int p){
    movementPoints = p;
  }
  public int getMovementPoints(int turn){
    return movementPoints;
  }
  public int getUnitNumber(){
    return unitNumber;
  }
  public int getUnitNumber(int turn){
    return unitNumber;
  }
  public void setUnitNumber(int newUnitNumber){
    unitNumber = (int)between(0, newUnitNumber, 1000);
  }
  public int changeUnitNumber(int changeInUnitNumber){
    int overflow = max(0, changeInUnitNumber+unitNumber-1000);
    this.setUnitNumber(unitNumber+changeInUnitNumber);
    return overflow;
  }
  public Party clone(){
    Party newParty = new Party(player, unitNumber, task, movementPoints);
    newParty.actions = new ArrayList<Action>(actions);
    newParty.strength = strength;
    return newParty;
  }
}

class Battle extends Party{
  Party party1;
  Party party2;
  Battle(Party attacker, Party defender){
    super(2, attacker.getUnitNumber()+defender.getUnitNumber(), JSONIndex(gameData.getJSONArray("tasks"), "Battle"), 0);
    party1 = attacker;
    party1.strength = 2;
    party2 = defender;
  }
  public boolean isTurn(int turn){
    return true;
  }
  public int getMovementPoints(int turn){
    if(turn==party1.player){
      return party1.getMovementPoints();
    } else {
      return party2.getMovementPoints();
    }
  }
  public void setUnitNumber(int turn, int newUnitNumber){
      if(turn==party1.player){
        party1.setUnitNumber(newUnitNumber);
      } else {
        party2.setUnitNumber(newUnitNumber);
      }
  }
  public int getUnitNumber(int turn){
      if(turn==party1.player){
        return party1.getUnitNumber();
      } else {
        return party2.getUnitNumber();
      }
  }
  public int changeUnitNumber(int turn, int changeInUnitNumber){
    if(turn==this.party1.player){
      int overflow = max(0, changeInUnitNumber+party1.getUnitNumber()-1000);
      this.party1.setUnitNumber(party1.getUnitNumber()+changeInUnitNumber);
      return overflow;
    } else {
      int overflow = max(0, changeInUnitNumber+party2.getUnitNumber()-1000);
      this.party2.setUnitNumber(party2.getUnitNumber()+changeInUnitNumber);
      return overflow;
    }
  }
  public Party doBattle(){
    int changeInParty1 = getBattleUnitChange(party1, party2);
    int changeInParty2 = getBattleUnitChange(party2, party1);
    party1.strength = 1;
    party2.strength = 1;
    int newParty1Size = party1.getUnitNumber()+changeInParty1;
    int newParty2Size = party2.getUnitNumber()+changeInParty2;
    int endDifference = newParty1Size-newParty2Size;
    party1.setUnitNumber(newParty1Size);
    party2.setUnitNumber(newParty2Size);
    if (party1.getUnitNumber()==0){
      if(party2.getUnitNumber()==0){
        if(endDifference==0){
          return null;
        } else if(endDifference>0){
          party1.setUnitNumber(endDifference);
          party1.changeTask(JSONIndex(gameData.getJSONArray("tasks"), "Rest"));
          return party1;
        } else {
          party2.setUnitNumber(-endDifference);
          party2.changeTask(JSONIndex(gameData.getJSONArray("tasks"), "Rest"));
          return party2;
        }
      } else {
        party2.changeTask(JSONIndex(gameData.getJSONArray("tasks"), "Rest"));
        return party2;
      }
    } if(party2.getUnitNumber()==0){
      party1.changeTask(JSONIndex(gameData.getJSONArray("tasks"), "Rest"));
      return party1;
    } else {
      return this;
    }
  }
  public Battle clone(){
    Battle newParty = new Battle(this.party1.clone(), this.party2.clone());
    return newParty;
  }
}

public int getBattleUnitChange(Party p1, Party p2){
  return floor(-0.2f*(p2.getUnitNumber()+pow(p2.getUnitNumber(), 2)/p1.getUnitNumber())*random(0.75f, 1.5f)*p2.strength/p1.strength);
}



class Player{
  float mapXOffset, mapYOffset, blockSize;
  float[] resources;
  int cellX, cellY, colour;
  boolean cellSelected = false;
  // Resources: food wood metal energy concrete cable spaceship_parts ore people
  Player(float mapXOffset, float mapYOffset, float blockSize, float[] resources, int colour){
    this.mapXOffset = mapXOffset;
    this.mapYOffset = mapYOffset;
    this.blockSize = blockSize;
    this.resources = resources;
    this.colour = colour;
  }
  public void saveSettings(float mapXOffset, float mapYOffset, float blockSize, int cellX, int cellY, boolean cellSelected){
    this.mapXOffset = mapXOffset;
    this.mapYOffset = mapYOffset;
    this.blockSize = blockSize;
    this.cellX = cellX;
    this.cellY = cellY;
    this.cellSelected = cellSelected;
  }
  public void loadSettings(Game g, Map m){
    m.loadSettings(mapXOffset, mapYOffset, blockSize);
    if(cellSelected){
      g.selectCell((int)this.cellX, (int)this.cellY, false);
    } else {
      g.deselectCell();
    }
  }
}





class Node{
  int cost;
  boolean fixed;
  int prevX = -1, prevY = -1;

  Node(int cost, boolean fixed, int prevX, int prevY){
    this.fixed = fixed;
    this.cost = cost;
    this.prevX = prevX;
    this.prevY = prevY;
  }
  public void setPrev(int prevX ,int prevY){
    this.prevX = prevX;
    this.prevY = prevY;
  }
}



class MapSave{
  float[] heightMap;
  int mapWidth, mapHeight;
  int[][] terrain;
  Party[][] parties;
  Building[][] buildings;
  int startTurn;
  int startPlayer;
  Player[] players;
  MapSave(float[] heightMap,int mapWidth, int mapHeight, int[][] terrain, Party[][] parties, Building[][] buildings, int startTurn, int startPlayer, Player[] players){
    this.heightMap = heightMap;
    this.mapWidth = mapWidth;
    this.mapHeight = mapHeight;
    this.terrain = terrain;
    this.parties = parties;
    this.buildings = buildings;
    this.startTurn = startTurn;
    this.startPlayer = startPlayer;
    this.players = players;
  }
}

class BattleEstimateManager{
  int currentWins = 0;
  int currentTrials = 0;
  int attackerX;
  int attackerY;
  int defenderX;
  int defenderY;
  int attackerUnits;
  boolean cached = false;
  Party[][] parties;
  BattleEstimateManager(Party[][] parties){
    this.parties = parties;
  }
  public BigDecimal getEstimate(int x1, int y1, int x2, int y2, int units){
    Party tempAttacker = parties[y1][x1].clone();
    tempAttacker.setUnitNumber(units);
    if (cached&&attackerX==x1&&attackerY==y1&&defenderX==x2&&defenderY==y2&&attackerUnits==units){
      int TRIALS = 1000;
      for (int i = 0;i<TRIALS;i++){
        currentWins+=runTrial(tempAttacker, parties[y2][x2]);
      }
      currentTrials+=TRIALS;
    } else {
      cached = true;
      currentWins = 0;
      currentTrials = 0;
      attackerX = x1;
      attackerY = y1;
      defenderX = x2;
      defenderY = y2;
      attackerUnits = units;
      int TRIALS = 10000;
      for (int i = 0;i<TRIALS;i++){
        currentWins+=runTrial(tempAttacker, parties[y2][x2]);
      }
      currentTrials = TRIALS;
    }
    BigDecimal chance = new BigDecimal(""+currentWins).multiply(new BigDecimal(100)).divide(new BigDecimal(""+currentTrials), 1, BigDecimal.ROUND_HALF_UP);
    return chance;
  }
  
  public int runTrial(Party attacker, Party defender){
    Battle battle;
    Party clone1;
    Party clone2;
    if(defender.player==2){
      battle = (Battle) defender.clone();
      battle.changeUnitNumber(attacker.player, attacker.getUnitNumber());
      if(battle.party1.player==attacker.player){
        clone1 = battle.party1;
        clone2 = battle.party2;
      } else {
        clone1 = battle.party2;
        clone2 = battle.party1;
      }
    } else {
      clone1 = attacker.clone();
      clone2 = defender.clone();
      battle = new Battle(clone1, clone2); 
    }
    while (clone1.getUnitNumber()>0&&clone2.getUnitNumber()>0){
      battle.doBattle();
    }
    if(clone1.getUnitNumber()>0){
      return 1;
    } else {
      return 0;
    }
  }
  public void refresh(){
    cached = false;
  }
}

public int terrainIndex(String terrain){
  int k = JSONIndex(gameData.getJSONArray("terrain"), terrain);
  if (k>=0){
    return k+1;
  }
  println("Invalid terrain type, "+terrain);
  return -1;
}
public int buildingIndex(String building){
  int k = JSONIndex(gameData.getJSONArray("buildings"), building);
  if (k>=0){
    return k+1;
  }
  println("Invalid building type, "+building);
  return -1;
}


class Game extends State{
  final int buttonW = 120;
  final int buttonH = 50;
  final int bezel = 10;
  final int mapElementWidth = round(width);
  final int mapElementHeight = round(height-bezel*2-buttonH);
  final int CLICKHOLD = 500;
  PGraphics gameUICanvas;
  String[] tasks;
  String[] buildingTypes;
  float[][] taskCosts;
  float[][] taskOutcomes;
  int numResources;
  String[] resourceNames;
  float [] startingResources;
  int turnNumber;
  int mapHeight = jsManager.loadIntSetting("map size");
  int mapWidth = jsManager.loadIntSetting("map size");
  int[][] terrain;
  Party[][] parties;
  Building[][] buildings;
  BattleEstimateManager battleEstimateManager;
  NotificationManager notificationManager;
  Tooltip tooltip;
  int turn;
  boolean changeTurn = false;
  int winner = -1;
  Map3D map3d;
  Map2D map2d;
  Map map;
  Player[] players;
  int cellX, cellY, cellSelectionX, cellSelectionY, cellSelectionW, cellSelectionH;
  boolean cellSelected=false, moving=false;
  int partyManagementColour;
  ArrayList<Integer[]> prevIdle;
  float[] totals;
  Party splittedParty;
  int[] mapClickPos = null;

  Game(){
    gameUICanvas = createGraphics(width, height, P2D); 
    initialiseResources();
    initialiseTasks();
    initialiseBuildings();

    addElement("2dmap", new Map2D(0, 0, mapElementWidth, mapElementHeight, terrain, parties, buildings, mapWidth, mapHeight));
    addElement("3dmap", new Map3D(0, 0, mapElementWidth, mapElementHeight, terrain, parties, buildings, mapWidth, mapHeight));
    addElement("4notification manager", new NotificationManager(0, 0, 0, 0, color(100), color(255), 10, turn));

    //map = (Map3D)getElement("2map", "default");
    notificationManager = (NotificationManager)getElement("4notification manager", "default");
    players = new Player[2];
    totals = new float[resourceNames.length];

    // Initial positions will be focused on starting party
    //players[0] = new Player(map.focusedX, map.focusedY, map.zoom, startingResources, color(0,0,255));
    //players[1] = new Player(map.focusedX, map.focusedY, map.zoom, startingResources, color(255,0,0));
    addPanel("land management", 0, 0, width, height, false, true, color(50, 200, 50), color(0));
    addPanel("party management", 0, 0, width, height, false, true, color(110, 110, 255), color(0));
    addPanel("bottom bar", 0, height-70, width, 70, true, true, color(150), color(50));
    addPanel("end screen", 0, 0, width, height, false, true, color(50, 50, 50, 50), color(0));
    addPanel("pause screen", 0, 0, width, height, false, true, color(50, 50, 50, 50), color(0));
    addPanel("save screen", (int)(width/2+jsManager.loadFloatSetting("gui scale")*150+(int)(jsManager.loadFloatSetting("gui scale")*20)), (int)(height/2-5*jsManager.loadFloatSetting("gui scale")*40), (int)(jsManager.loadFloatSetting("gui scale")*500), (int)(jsManager.loadFloatSetting("gui scale")*300), false, false, color(50), color(0));
    addPanel("overlay", 0, 0, width, height, true, false, color(255,255), color(255, 255));
    
    getPanel("save screen").setOverrideBlocking(true);

    addElement("0tooltip", new Tooltip(), "overlay");
    tooltip = (Tooltip)getElement("0tooltip", "overlay");

    addElement("end game button", new Button((int)(width/2-jsManager.loadFloatSetting("gui scale")*width/16), (int)(height/2+height/8), (int)(jsManager.loadFloatSetting("gui scale")*width/8), (int)(jsManager.loadFloatSetting("gui scale")*height/16), color(70, 70, 220), color(50, 50, 200), color(255), 14, CENTER, "End Game"), "end screen");
    addElement("winner", new Text(width/2, height/2, (int)(jsManager.loadFloatSetting("text scale")*10), "", color(255), CENTER), "end screen");

    addElement("main menu button", new Button((int)(width/2-jsManager.loadFloatSetting("gui scale")*150), (int)(height/2-jsManager.loadFloatSetting("gui scale")*40), (int)(jsManager.loadFloatSetting("gui scale")*300), (int)(jsManager.loadFloatSetting("gui scale")*60), color(70, 70, 220), color(50, 50, 200), color(255), 14, CENTER, "Exit to Main Menu"), "pause screen");
    addElement("desktop button", new Button((int)(width/2-jsManager.loadFloatSetting("gui scale")*150), (int)(height/2+jsManager.loadFloatSetting("gui scale")*40), (int)(jsManager.loadFloatSetting("gui scale")*300), (int)(jsManager.loadFloatSetting("gui scale")*60), color(70, 70, 220), color(50, 50, 200), color(255), 14, CENTER, "Exit to Desktop"), "pause screen");
    addElement("save as button", new Button((int)(width/2-jsManager.loadFloatSetting("gui scale")*150), (int)(height/2-3*jsManager.loadFloatSetting("gui scale")*40), (int)(jsManager.loadFloatSetting("gui scale")*300), (int)(jsManager.loadFloatSetting("gui scale")*60), color(70, 70, 220), color(50, 50, 200), color(255), 14, CENTER, "Save As"), "pause screen");
    addElement("resume button", new Button((int)(width/2-jsManager.loadFloatSetting("gui scale")*150), (int)(height/2-5*jsManager.loadFloatSetting("gui scale")*40), (int)(jsManager.loadFloatSetting("gui scale")*300), (int)(jsManager.loadFloatSetting("gui scale")*60), color(70, 70, 220), color(50, 50, 200), color(255), 14, CENTER, "Resume"), "pause screen");
    
    addElement("save button", new Button(bezel, bezel, (int)(jsManager.loadFloatSetting("gui scale")*300)-2*bezel, (int)(jsManager.loadFloatSetting("gui scale")*60), color(100), color(0), color(255), 14, CENTER, "Save"), "save screen");
    addElement("saving manager", new BaseFileManager(bezel, (int)(4*jsManager.loadFloatSetting("gui scale")*40), (int)(jsManager.loadFloatSetting("gui scale")*500)-2*bezel, (int)(jsManager.loadFloatSetting("gui scale")*300), "saves"), "save screen");
    addElement("save namer", new TextEntry(bezel, (int)(2*jsManager.loadFloatSetting("gui scale")*40)+bezel*2, (int)(jsManager.loadFloatSetting("gui scale")*300), (int)(jsManager.loadFloatSetting("gui scale")*50), LEFT, color(0), color(100), color(0), "", "Save Name"), "save screen");
 
    addElement("turns remaining", new Text(bezel*2+220, bezel*4+30+30, 8, "", color(255), LEFT), "party management");
    addElement("move button", new Button(bezel, bezel*3, 100, 30, color(150), color(50), color(0), 10, CENTER, "Move"), "party management");
    addElement("split units", new Slider(bezel+10, bezel*3+30, 220, 30, color(255), color(150), color(0), color(0), 0, 0, 0, 1, 1, 1, true, ""), "party management");
    addElement("tasks", new TaskManager(bezel, bezel*4+30+30, 220, 10, color(150), color(50), tasks), "party management");
    

    addElement("end turn", new Button(bezel, bezel, buttonW, buttonH, color(150), color(50), color(0), 10, CENTER, "Next Turn"), "bottom bar");
    addElement("idle party finder", new Button(bezel*2+buttonW, bezel, buttonW, buttonH, color(150), color(50), color(0), 10, CENTER, "Idle Party"), "bottom bar");
    addElement("resource summary", new ResourceSummary(0, 0, 70, resourceNames, startingResources, totals), "bottom bar");
    int resSummaryX = width-((ResourceSummary)(getElement("resource summary", "bottom bar"))).totalWidth();
    addElement("resource expander", new Button(resSummaryX-50, bezel, 30, 30, color(150), color(50), color(0), 10, CENTER, "<"), "bottom bar");
    addElement("turn number", new TextBox(bezel*3+buttonW*2, bezel, -1, buttonH, 14, "Turn 0", color(0,0,255), 0), "bottom bar");
    addElement("2d 3d toggle", new ToggleButton(bezel*4+buttonW*3, bezel*2, buttonW/2, buttonH-bezel, color(100), color(0), jsManager.loadBooleanSetting("map is 3d"), "3D View"), "bottom bar");
  //int x, int y, int w, int h, color bgColour, color strokeColour, boolean value, String name
  
    prevIdle = new ArrayList<Integer[]>();
  }

  public void initialiseBuildings(){
    JSONObject js;
    int numBuildings = gameData.getJSONArray("buildings").size();
    buildingTypes = new String[numBuildings];
    for (int i=0; i<numBuildings; i++){
      js = gameData.getJSONArray("buildings").getJSONObject(i);
      buildingTypes[i] = js.getString("id");
    }
  }
  public void initialiseTasks(){
    JSONObject js;
    int numTasks = gameData.getJSONArray("tasks").size();
    taskOutcomes = new float[numTasks][numResources];
    taskCosts = new float[numTasks][numResources];
    tasks = new String[numTasks];
    for (int i=0; i<numTasks; i++){
      js = gameData.getJSONArray("tasks").getJSONObject(i);
      tasks[i] = js.getString("id");
      if (!js.isNull("production"))
        for (int r=0; r<js.getJSONArray("production").size(); r++)
          taskOutcomes[i][getResIndex(js.getJSONArray("production").getJSONObject(r).getString("id"))] = js.getJSONArray("production").getJSONObject(r).getFloat("quantity");
      if (!js.isNull("consumption"))
        for (int r=0; r<js.getJSONArray("consumption").size(); r++){
          taskCosts[i][getResIndex(js.getJSONArray("consumption").getJSONObject(r).getString("id"))] = js.getJSONArray("consumption").getJSONObject(r).getFloat("quantity");
        }
    }
  }
  public void initialiseResources(){
    JSONObject js;
    numResources = gameData.getJSONArray("resources").size();
    resourceNames = new String[numResources];
    startingResources = new float[numResources];
    for (int i=0; i<numResources; i++){
      js = gameData.getJSONArray("resources").getJSONObject(i);
      resourceNames[i] = js.getString("id");
      JSONObject sr = findJSONObject(gameData.getJSONObject("game options").getJSONArray("starting resources"), resourceNames[i]);
      if (sr != null)
        startingResources[i] = sr.getFloat("quantity");
    }
  }

  public void leaveState(){
    map.clearShape();
  }

  public int getResIndex(String s){
    return JSONIndex(gameData.getJSONArray("resources"), s);
  }
  public String getResString(int r){
    return gameData.getJSONArray("resources").getJSONObject(r).getString("id");
  }
  public JSONArray taskInitialCost(int type){
    // Find initial cost for task (such as for buildings, 'Build Farm')
    JSONArray ja = gameData.getJSONArray("tasks").getJSONObject(type).getJSONArray("initial cost");
    return ja;
  }
  public int taskTurns(String task){
    JSONObject jo = findJSONObject(gameData.getJSONArray("tasks"), task);
    if (jo==null){
      print("invalid task type", task);
      return 0;
    }
    if (jo.isNull("action"))return 0;
    return jo.getJSONObject("action").getInt("turns");
  }
  public Action taskAction(int task){
    JSONObject jo = gameData.getJSONArray("tasks").getJSONObject(task).getJSONObject("action");
    if (jo != null)
      return new Action(task, jo.getString("notification"), jo.getInt("turns"), jo.getString("building"), jo.getString("terrain"));
    return null;
  }
  public float[] JSONToCost(JSONArray ja){
    float[] costs = new float[numResources];
    if (ja == null){
      return null;
    }
    for (int i=0; i<ja.size(); i++){
      costs[getResIndex(ja.getJSONObject(i).getString("id"))] = ja.getJSONObject(i).getFloat("quantity");
    }
    return costs;
  }

  public String terrainString(int terrainI){
    return gameData.getJSONArray("terrain").getJSONObject(terrainI-1).getString("id");
  }
  public String buildingString(int buildingI){
    if (gameData.getJSONArray("buildings").isNull(buildingI-1)){
      println("invalid building string ", buildingI-1);
      return null;
    }
    return gameData.getJSONArray("buildings").getJSONObject(buildingI-1).getString("id");
  }
  public float[] buildingCost(int actionType){
    float[] a = JSONToCost(taskInitialCost(actionType));
    if (a == null)
      return new float[numResources];
    else
      return a;
  }
  public boolean postEvent(GameEvent event){
    boolean valid = true;
    // Returns true if event is valid
    battleEstimateManager.refresh();
    if (event instanceof Move){

      Move m = (Move)event;
      int x = m.endX;
      int y = m.endY;
      int cellX = m.startX;
      int cellY = m.startY;

      if (x<0 || x>=mapWidth || y<0 || y>=mapHeight){
        println("invalid movement");
        valid = false;
      }

      Node[][] nodes = djk(cellX, cellY);

      if (canMove(cellX, cellY)){
        int sliderVal = round(((Slider)getElement("split units", "party management")).getValue());
        if (sliderVal > 0 && parties[cellY][cellX].getUnitNumber() >= 2 && parties[cellY][cellX].getTask() != JSONIndex(gameData.getJSONArray("tasks"), "Battle")){
          map.updateMoveNodes(nodes);
          moving = true;
          splittedParty = new Party(turn, sliderVal, JSONIndex(gameData.getJSONArray("tasks"), "Rest"), parties[cellY][cellX].getMovementPoints());
          parties[cellY][cellX].changeUnitNumber(-sliderVal);
          if (parties[cellY][cellX].getUnitNumber() <= 0){
            parties[cellY][cellX] = null;
          }
        }
      }

      if (splittedParty != null){
        splittedParty.target = new int[]{x, y};
        splittedParty.path = getPath(cellX, cellY, x, y, nodes);
        int pathTurns;
        if (cellX==x&&cellY==y){
          pathTurns = 0;
        }
        else if (!canMove(cellX, cellY)){
          pathTurns = getMoveTurns(cellX, cellY, x, y, nodes);
        }
        else{
          pathTurns = 1+getMoveTurns(cellX, cellY, x, y, nodes);
        }
        splittedParty.setPathTurns(pathTurns);
        Collections.reverse(splittedParty.path);
        splittedParty.changeTask(JSONIndex(gameData.getJSONArray("tasks"), "Rest"));
        splittedParty.clearActions();
        ((Text)getElement("turns remaining", "party management")).setText("");
        moveParty(cellX, cellY, true);
      }
      else {
        parties[cellY][cellX].target = new int[]{x, y};
        parties[cellY][cellX].path = getPath(cellX, cellY, x, y, nodes);
        int pathTurns;
        if (cellX==x&&cellY==y){
          pathTurns = 0;
        }
        else if (!canMove(cellX, cellY)){
          pathTurns = getMoveTurns(cellX, cellY, x, y, nodes);
        }
        else{
          pathTurns = 1+getMoveTurns(cellX, cellY, x, y, nodes);
        }
        parties[cellY][cellX].setPathTurns(pathTurns);
        Collections.reverse(parties[cellY][cellX].path);
        parties[cellY][cellX].changeTask(JSONIndex(gameData.getJSONArray("tasks"), "Rest"));
        parties[cellY][cellX].clearActions();
        ((Text)getElement("turns remaining", "party management")).setText("");
        moveParty(cellX, cellY);
      }
    }
    else if (event instanceof EndTurn){
      if (!changeTurn)
        changeTurn();
      else
        valid = false;
    }

    else if (event instanceof ChangeTask){
      ChangeTask m = (ChangeTask)event;
      int cellX = m.x;
      int cellY = m.y;
      int task = m.task;
      parties[cellY][cellX].clearPath();
      parties[cellY][cellX].target = null;
      JSONObject jo = gameData.getJSONArray("tasks").getJSONObject(parties[cellY][cellX].getTask());
      if (!jo.isNull("movement points")){
        //Changing from defending
        parties[cellY][cellX].setMovementPoints(min(parties[cellY][cellX].getMovementPoints()+jo.getInt("movement points"), gameData.getJSONObject("game options").getInt("movement points")));
      }
      parties[cellY][cellX].changeTask(task);
      if (parties[cellY][cellX].getTask() == JSONIndex(gameData.getJSONArray("tasks"), "Rest")){
        parties[cellY][cellX].clearActions();
        ((Text)getElement("turns remaining", "party management")).setText("");
      }
      else{
        moving = false;
        map.cancelMoveNodes();
      }
      jo = gameData.getJSONArray("tasks").getJSONObject(parties[cellY][cellX].getTask());
      if (!jo.isNull("movement points")){
        if (parties[cellY][cellX].getMovementPoints()-jo.getInt("movement points") >= 0){
          parties[cellY][cellX].subMovementPoints(jo.getInt("movement points"));
        }
        else{
          parties[cellY][cellX].changeTask(JSONIndex(gameData.getJSONArray("tasks"), "Rest"));
        }
      } else if (jo.getString("id").equals("Launch Rocket")){
        int rocketBehaviour = PApplet.parseInt(random(10));
        buildings[cellY][cellX].image_id=0;
        //Rocket Launch Animation with behaviour
        if (rocketBehaviour > 6){
          winner = turn;
        }
        else {
          players[turn].resources[getResIndex("rocket progress")] = 0;
          parties[cellY][cellX].changeTask(JSONIndex(gameData.getJSONArray("tasks"), "Rest"));
        }
      }
      else if (parties[cellY][cellX].getTask()==JSONIndex(gameData.getJSONArray("tasks"), "Produce Rocket")){
        if(players[turn].resources[getResIndex("rocket progress")]==-1){
          players[turn].resources[getResIndex("rocket progress")] = 0;
        }
      }

      else{
        Action a = taskAction(parties[cellY][cellX].getTask());
        if (a != null){
          float[] co = buildingCost(parties[cellY][cellX].getTask());
          if (sufficientResources(players[turn].resources, co, true)){
            parties[cellY][cellX].clearActions();
            ((Text)getElement("turns remaining", "party management")).setText("");
            parties[cellY][cellX].addAction(taskAction(parties[cellY][cellX].getTask()));
            if (sum(co)>0){
              spendRes(players[turn], co);
              buildings[cellY][cellX] = new Building(buildingIndex("Construction"));
            }
          }
          else{
            parties[cellY][cellX].changeTask(JSONIndex(gameData.getJSONArray("tasks"), "Rest"));
          }
        }
      }

      checkTasks();
    }
    if (valid){
      if (!changeTurn){
        this.totals = totalResources();
        ResourceSummary rs = ((ResourceSummary)(getElement("resource summary", "bottom bar")));
        rs.updateNet(totals);
        rs.updateStockpile(players[turn].resources);

        if (anyIdle(turn)){
          ((Button)getElement("idle party finder", "bottom bar")).setColour(color(255, 50, 50));
        }
        else{
          ((Button)getElement("idle party finder", "bottom bar")).setColour(color(150));
        }
      }
    }
    return valid;
  }
  public boolean anyIdle(int turn){
    for (int x=0; x<mapWidth; x++){
      for (int y=0; y<mapWidth; y++){
        if (parties[y][x] != null && parties[y][x].player == turn && isIdle(x, y)){
          return true;
        }
      }
    }
    return false;
  }
  public void updateCellSelection(){
    cellSelectionX = round((width-400-bezel*2)/jsManager.loadFloatSetting("gui scale"))+bezel*2;
    cellSelectionY = bezel*2;
    cellSelectionW = width-cellSelectionX-bezel*2;
    cellSelectionH = round(mapElementHeight);
    getPanel("land management").transform(cellSelectionX, cellSelectionY, cellSelectionW, round(cellSelectionH*0.15f));
    getPanel("party management").transform(cellSelectionX, cellSelectionY+round(cellSelectionH*0.15f)+bezel, cellSelectionW, round(cellSelectionH*0.5f)-bezel*3);
    ((NotificationManager)(getElement("4notification manager", "default"))).transform(cellSelectionX, cellSelectionY+round(cellSelectionH*0.65f)-bezel, cellSelectionW, round(cellSelectionH*0.35f)-bezel*2);
    ((Button)getElement("move button", "party management")).transform(bezel, round(13*jsManager.loadFloatSetting("text scale")+bezel), 100, 30);
    ((Slider)getElement("split units", "party management")).transform(round(10*jsManager.loadFloatSetting("gui scale")+bezel), round(bezel*3+2*jsManager.loadFloatSetting("text scale")*13), cellSelectionW-2*bezel-round(20*jsManager.loadFloatSetting("gui scale")),round(jsManager.loadFloatSetting("text scale")*2*13));
    ((TaskManager)getElement("tasks", "party management")).transform(bezel, round(bezel*4+4*jsManager.loadFloatSetting("text scale")*13), cellSelectionW-2*bezel, 30);
    ((Text)getElement("turns remaining", "party management")).translate(100+bezel*2, round(13*jsManager.loadFloatSetting("text scale")*2 + bezel*3));
  }


  public void makeTaskAvailable(int task){
    ((TaskManager)getElement("tasks", "party management")).makeAvailable(gameData.getJSONArray("tasks").getJSONObject(task).getString("id"));

  }
  public void resetAvailableTasks(){
    ((TaskManager)getElement("tasks", "party management")).resetAvailable();
  }
  //tasks building
  //settings

  public void checkTasks(){
    resetAvailableTasks();
    boolean correctTerrain, correctBuilding, enoughResources;
    JSONObject js;

    if(parties[cellY][cellX].hasActions()){
      makeTaskAvailable(parties[cellY][cellX].currentAction());
    }

    for(int i=0; i<gameData.getJSONArray("tasks").size(); i++){
      js = gameData.getJSONArray("tasks").getJSONObject(i);
      if (!js.isNull("terrain"))
        correctTerrain = JSONContainsStr(js.getJSONArray("terrain"), terrainString(terrain[cellY][cellX]));
      else
        correctTerrain = true;
      correctBuilding = false;
      enoughResources = true;
      if (!js.isNull("initial cost")){
        for (int j=0; j<js.getJSONArray("initial cost").size(); j++){
          JSONObject initialCost = js.getJSONArray("initial cost").getJSONObject(j);
          if (players[turn].resources[getResIndex(initialCost.getString("id"))]<(initialCost.getInt("quantity"))){
            enoughResources = false;
          }
        }
      }

      if (js.isNull("auto enabled")||!js.getBoolean("auto enabled")){
        if (js.isNull("buildings")){
          if (js.getString("id").equals("Demolish") && buildings[cellY][cellX] != null)
            correctBuilding = true;
          else if(!js.getString("id").equals("Demolish"))
            correctBuilding = true;
        }
        else{
          if (js.getJSONArray("buildings").size() > 0){
            if (buildings[cellY][cellX] != null)
            if (buildings[cellY][cellX] != null && JSONContainsStr(js.getJSONArray("buildings"), buildingString(buildings[cellY][cellX].type)))
              correctBuilding = true;
          }
          else if (buildings[cellY][cellX] == null){
            correctBuilding = true;
          }
        }
      }

      if (correctTerrain && correctBuilding && enoughResources){
        makeTaskAvailable(i);
      }
    }
    ((TaskManager)getElement("tasks", "party management")).select(jsManager.gameData.getJSONArray("tasks").getJSONObject(parties[cellY][cellX].getTask()).getString("id"));
  }

  public boolean UIHovering(){
   //To avoid doing things while hoving over important stuff
   NotificationManager nm = ((NotificationManager)(getElement("4notification manager", "default")));
   return !((!getPanel("party management").mouseOver() || !getPanel("party management").visible) && (!getPanel("land management").mouseOver() || !getPanel("land management").visible) &&
   (!nm.moveOver()||nm.empty()));
  }

  public void turnChange(){
    float[] totalResourceRequirements = new float[numResources];
    for (int y=0; y<mapHeight; y++){
      for (int x=0; x<mapWidth; x++){
        if (parties[y][x] != null){
          if (parties[y][x].player == turn){
            for (int i=0; i<tasks.length;i++){
              if(parties[y][x].getTask()==i){
                for(int resource = 0; resource < numResources; resource++){
                  totalResourceRequirements[resource]+=taskCosts[i][resource]*parties[y][x].getUnitNumber();
                }
              }
            }
            Action action = parties[y][x].progressAction();
            if (action != null){
              if (!(action.type==JSONIndex(gameData.getJSONArray("tasks"), "Construction Mid")) && !(action.type==JSONIndex(gameData.getJSONArray("tasks"), "Construction End")))
                notificationManager.post(action.notification, x, y, turnNumber, turn);
              if (action.building != null){
                if (action.building.equals(""))
                  buildings[y][x] = null;
                else
                  buildings[y][x] = new Building(buildingIndex(action.building));
              }
              if (action.terrain != null){
                if (terrain[y][x] == terrainIndex("forest")){
                  players[turn].resources[getResIndex("wood")]+=100;
                  map.removeTreeTile(x, y);
                }
                terrain[y][x] = terrainIndex(action.terrain);
              }
              if (action.type==JSONIndex(gameData.getJSONArray("tasks"), "Construction Mid")){
                  buildings[y][x].image_id = 1;
                  action = null;
              } else if(action.type==JSONIndex(gameData.getJSONArray("tasks"), "Construction End")){
                  buildings[y][x].image_id = 2;
                  action = null;
              }
            }
            if (action != null){
              parties[y][x].clearCurrentAction();
              parties[y][x].changeTask(JSONIndex(gameData.getJSONArray("tasks"), "Rest"));
            }
            moveParty(x, y);
          }
          else {
            if(parties[y][x].player==2){
              int player = ((Battle) parties[y][x]).party1.player;
              int otherPlayer = ((Battle) parties[y][x]).party2.player;
              parties[y][x] = ((Battle)parties[y][x]).doBattle();
              if(parties[y][x].player != 2){
                notificationManager.post("Battle Ended. Player "+str(parties[y][x].player+1)+" won", x, y, turnNumber, player);
                notificationManager.post("Battle Ended. Player "+str(parties[y][x].player+1)+" won", x, y, turnNumber, otherPlayer);
              }
            }
          }
        }
      }
    }
    float [] resourceAmountsAvailable = new float[numResources];
    for(int i=0; i<numResources;i++){
      if(totalResourceRequirements[i]==0){
        resourceAmountsAvailable[i] = 1;
      } else{
       resourceAmountsAvailable[i] = min(1, players[turn].resources[i]/totalResourceRequirements[i]);
      }
    }

    for (int y=0; y<mapHeight; y++){
      for (int x=0; x<mapWidth; x++){
        if (parties[y][x] != null){
          if (parties[y][x].player == turn){
            float productivity = 1;
            for (int task=0; task<tasks.length;task++){
              if(parties[y][x].getTask()==task){
                for(int resource = 0; resource < numResources; resource++){
                  if(taskCosts[task][resource]>0){
                    if(resource==0){
                      productivity = min(productivity, resourceAmountsAvailable[resource]+0.5f);
                    } else {
                      productivity = min(productivity, resourceAmountsAvailable[resource]);
                    }
                  }
                }
              }
            }
            for (int task=0; task<tasks.length;task++){
              if(parties[y][x].getTask()==task){
                for(int resource = 0; resource < numResources; resource++){
                  if(resource!=getResIndex("civilians")){
                    if(tasks[task]=="Produce Rocket"){
                      resource = getResIndex("rocket progress");
                    }
                    players[turn].resources[resource] += max((taskOutcomes[task][resource]-taskCosts[task][resource])*productivity*parties[y][x].getUnitNumber(), -players[turn].resources[resource]);
                    if(tasks[task]=="Produce Rocket"){
                      break;
                    }
                  } else if(resourceAmountsAvailable[getResIndex("food")]<1){
                    float lost = (1-resourceAmountsAvailable[getResIndex("food")])*taskOutcomes[task][resource]*parties[y][x].getUnitNumber();
                    parties[y][x].setUnitNumber(floor(parties[y][x].getUnitNumber()-lost));
                    if (parties[y][x].getUnitNumber() == 0)
                      notificationManager.post("Party Starved", x, y, turnNumber, turn);
                    else
                      notificationManager.post(String.format("Party Starving - %d lost", ceil(lost)), x, y, turnNumber, turn);
                  } else{
                    int prev = parties[y][x].getUnitNumber();
                    parties[y][x].setUnitNumber(ceil(parties[y][x].getUnitNumber()+taskOutcomes[task][resource]*(float)parties[y][x].getUnitNumber()));
                    if (prev != 1000 && parties[y][x].getUnitNumber() == 1000 && parties[y][x].task == JSONIndex(gameData.getJSONArray("tasks"), "Super Rest")){
                      notificationManager.post("Party Full", x, y, turnNumber, turn);
                    }
                  }

                }
              }
            }
            if(parties[y][x].getUnitNumber()==0){
              parties[y][x] = null;
            }
          }
        }
      }
    }
    if (players[turn].resources[getResIndex("rocket progress")] > 1000){
      //display indicator saying rocket produced
      for (int y=0; y<mapHeight; y++){
        for (int x=0; x<mapWidth; x++){
          if (parties[y][x] != null){
            if (parties[y][x].player == turn){
              if(parties[y][x].getTask()==JSONIndex(gameData.getJSONArray("tasks"), "Produce Rocket")){
                notificationManager.post("Rocket Produced", x, y, turnNumber, turn);
                parties[y][x].changeTask(JSONIndex(gameData.getJSONArray("tasks"), "Rest"));
                buildings[y][x].image_id=1;
              }
            }
          }
        }
      }
    }
    partyMovementPointsReset();
    float mapXOffset;
    float mapYOffset;
    if (map.isPanning()){
      mapXOffset = map.getFocusedX();
      mapYOffset = map.getFocusedY();
    } else {
      mapXOffset = map.getFocusedX();
      mapYOffset = map.getFocusedY();
    }
    float blockSize;
    if (map.isZooming()){
      blockSize = map.getTargetZoom();
    } else{
      blockSize = map.getZoom();
    }
    players[turn].saveSettings(map.getTargetOffsetX(), map.getTargetOffsetY(), blockSize, cellX, cellY, cellSelected);
    turn = (turn + 1)%2;
    players[turn].loadSettings(this, map);
    changeTurn = false;
    TextBox t = ((TextBox)(getElement("turn number", "bottom bar")));
    t.setColour(players[turn].colour);
    t.setText("Turn "+turnNumber);

    this.totals = totalResources();
    ResourceSummary rs = ((ResourceSummary)(getElement("resource summary", "bottom bar")));
    rs.updateNet(totals);
    rs.updateStockpile(players[turn].resources);

    notificationManager.turnChange(turn);

    if (anyIdle(turn)){
      ((Button)getElement("idle party finder", "bottom bar")).setColour(color(255, 50, 50));
    }
    else{
      ((Button)getElement("idle party finder", "bottom bar")).setColour(color(150));
    }

    if (turn == 0)
      turnNumber ++;
  }

  public boolean checkForPlayerWin(){
    if(winner == -1){
      boolean player1alive = false;
      boolean player2alive = false;

      for (int y=0;y<mapHeight; y++){
        for (int x=0; x<mapWidth; x++){
          if (parties[y][x] != null){
            if(parties[y][x].player == 2){
              player1alive = true;
              player2alive = true;
            } else if (parties[y][x].player == 1){
              player2alive = true;
            } else if (parties[y][x].player == 0){
              player1alive = true;
            }
          }
        }
      }
      if (!player1alive){
        winner = 1;
      } else if (!player2alive) {
        winner = 0;
      } else {
        return false;
      }
    }
    Text winnerMessage = ((Text)this.getElement("winner", "end screen"));
    winnerMessage.setText(winnerMessage.text.replace("/w", str(winner+1)));
    return true;
  }
  

  public void drawPanels(){
    // Draw the panels in reverse order (highest in the list are drawn last so appear on top)
    for (int i=panels.size()-1; i>=0; i--){
      if (panels.get(i).visible){
        panels.get(i).draw();
      }
    }
    //background(100);
    if (changeTurn){
      turnChange();
    }
    
    if (map.isMoving()){
      refreshTooltip();
    }
    
    gameUICanvas.beginDraw();
    gameUICanvas.clear();
    gameUICanvas.pushStyle();

    if(tooltip.visible&&tooltip.attacking){
      int x = floor(map.scaleXInv());
      int y = floor(map.scaleYInv());
      if(0<=x&&x<mapWidth&&0<=y&&y<mapHeight){
        BigDecimal chance = battleEstimateManager.getEstimate(cellX, cellY, x, y, splitUnitsNum());
        tooltip.setAttacking(chance);
      }
    }
  
    if(players[0].resources[getResIndex("rocket progress")]!=-1||players[1].resources[getResIndex("rocket progress")]!=-1){
      drawRocketProgressBar(gameUICanvas);
    }
    if (cellSelected){
      drawCellManagement(gameUICanvas);
      if(parties[cellY][cellX] != null && getPanel("party management").visible)
        drawPartyManagement(gameUICanvas);
    }
    gameUICanvas.endDraw();
    gameUICanvas.popStyle();
    image(gameUICanvas, 0, 0);
    
    if (checkForPlayerWin()){
      this.getPanel("end screen").visible = true;
    }
  }
  public void partyMovementPointsReset(){
    for (int y=0; y<mapHeight; y++){
      for (int x=0; x<mapWidth; x++){
        if (parties[y][x] != null){
          if (parties[y][x].player != 2){
            parties[y][x].setMovementPoints(gameData.getJSONObject("game options").getInt("movement points"));
          }
        }
      }
    }
  }
  public void changeTurn(){
    changeTurn = true;
  }
  public boolean sufficientResources(float[] available, float[] required){
    for (int i=0; i<numResources;i++){
      if (available[i] < required[i]){
        return false;
      }
    }
    return true;
  }
  public boolean sufficientResources(float[] available, float[] required, boolean flash){
    ResourceSummary rs = ((ResourceSummary)(getElement("resource summary", "bottom bar")));
    boolean t = true;
    for (int i=0; i<numResources;i++){
      if (available[i] < required[i] && !buildingString(i).equals("rocket progress")){
        t = false;
        rs.flash(i);
      }
    }
    return t;
  }
  public void spendRes(Player player, float[] required){
    for (int i=0; i<numResources;i++){
      player.resources[i] -= required[i];
    }
  }
  public void reclaimRes(Player player, float[] required){
    //reclaim half cost of building
    for (int i=0; i<numResources;i++){
      player.resources[i] += required[i]/2;
    }
  }
  public int[] newPartyLoc(){
    ArrayList<int[]> locs = new ArrayList<int[]>();
    locs.add(new int[]{cellX+1, cellY});
    locs.add(new int[]{cellX-1, cellY});
    locs.add(new int[]{cellX, cellY+1});
    locs.add(new int[]{cellX, cellY-1});
    Collections.shuffle(locs);
    for (int i=0; i<4; i++){
      if (parties[locs.get(i)[1]][locs.get(i)[0]] == null && terrain[locs.get(i)[1]][locs.get(i)[0]] != 1){
        return locs.get(i);
      }
    }
    return null;
  }
  public boolean canMove(int x, int y){
    float points;
    int[][] mvs = {{1,0}, {0,1}, {1,1}, {-1,0}, {0,-1}, {-1,-1}, {1,-1}, {-1,1}};

    if (splittedParty!=null){
      points = splittedParty.getMovementPoints();
      for (int[] n : mvs){
        if (points >= cost(x+n[0], y+n[1], x, y)){
          return true;
        }
      }
    }
    else{
      points = parties[y][x].getMovementPoints();
      for (int[] n : mvs){
        if (points >= cost(x+n[0], y+n[1], x, y)){
          return true;
        }
      }
    }
    return false;
  }

  public boolean inPrevIdle(int x, int y){
    for (int i=0; i<prevIdle.size();i++){
      if (prevIdle.get(i)[0] == x && prevIdle.get(i)[1] == y){
        return true;
      }
    }
    return false;
  }
  public void clearPrevIdle(){
    prevIdle.clear();
  }
  public boolean isIdle(int x, int y){
    return (parties[y][x].task == JSONIndex(gameData.getJSONArray("tasks"), "Rest") && canMove(x, y) && (parties[y][x].path==null||parties[y][x].path!=null&&parties[y][x].path.size()==0));
  }

  public int[] findIdle(int player){
    int[] backup = {-1, -1};
    for (int y=0; y<mapHeight; y++){
      for (int x=0; x<mapWidth; x++){
        if (parties[y][x] != null && parties[y][x].player == player && isIdle(x, y)){
          if (inPrevIdle(x, y)){
            backup = new int[]{x, y};
          }
          else{
            prevIdle.add(new Integer[]{x, y});
            return new int[]{x, y};
          }
        }
      }
    }
    clearPrevIdle();
    if (backup[0] == -1){
      return backup;
    }
    else{
      return findIdle(player);
    }
  }

  public void elementEvent(ArrayList<Event> events){
    for (Event event : events){
      if (event.type == "clicked"){
        if (event.id == "idle party finder"){
          int[] t = findIdle(turn);
          if (t[0] != -1){
            selectCell(t[0], t[1], false);
            map.targetCell(t[0], t[1], 64);
          }
        }
        else if (event.id == "end turn"){
          postEvent(new EndTurn());
        }
        else if (event.id == "move button"){
          if (parties[cellY][cellX].player == turn){
            moving = !moving;
            if (moving){
              map.updateMoveNodes(djk(cellX, cellY));
            }
            else{
              map.cancelMoveNodes();
            }
          }
        }
        else if (event.id == "resource expander"){
          ResourceSummary r = ((ResourceSummary)(getElement("resource summary", "bottom bar")));
          Button b = ((Button)(getElement("resource expander", "bottom bar")));
          r.toggleExpand();
          b.transform(width-r.totalWidth()-50, bezel, 30, 30);
          if (b.getText() == ">")
            b.setText("<");
          else
            b.setText(">");
        }
        else if (event.id.equals("end game button")){
          newState = "menu";
        }
        else if (event.id.equals("main menu button")){
          // old save place
          newState = "menu";
        }
        else if (event.id.equals("desktop button")){
          exit();
        }
        else if (event.id.equals("resume button")){
          getPanel("pause screen").visible = false;
          getPanel("save screen").visible = false;
          // Enable map
          getElement("2dmap", "default").active = true;
          getElement("3dmap", "default").active = true;
        }
        else if (event.id.equals("save as button")){
          // Show the save menu
          getPanel("save screen").visible = !getPanel("save screen").visible;
          if (loadingName == null){
            loadingName = ((BaseFileManager)getElement("saving manager", "save screen")).getNextAutoName(); // Autogen name
          }
          ((TextEntry)getElement("save namer", "save screen")).setText(loadingName);
        }
        else if (event.id.equals("save button")){
          loadingName = ((TextEntry)getElement("save namer", "save screen")).getText();
          float blockSize;
          if (map.isZooming()){
            blockSize = map.getTargetZoom();
          } else{
            blockSize = map.getZoom();
          }
          players[turn].saveSettings(map.getTargetOffsetX(), map.getTargetOffsetY(), blockSize, cellX, cellY, cellSelected);
          ((BaseMap)map).saveMap("saves/"+loadingName, this.turnNumber, this.turn, this.players);
        }
      }
      if (event.type.equals("valueChanged")){
        if (event.id.equals("tasks")){
          postEvent(new ChangeTask(cellX, cellY, JSONIndex(jsManager.gameData.getJSONArray("tasks"), ((TaskManager)getElement("tasks", "party management")).getSelected())));
        }
        else if (event.id.equals("2d 3d toggle")){
          // Save the game
          loadingName = "Autosave.dat";
          float blockSize;
          if (map.isZooming()){
            blockSize = map.getTargetZoom();
          } else{
            blockSize = map.getZoom();
          }
          players[turn].saveSettings(map.getTargetOffsetX(), map.getTargetOffsetY(), blockSize, cellX, cellY, cellSelected);
          ((BaseMap)map).saveMap("saves/"+loadingName, this.turnNumber, this.turn, this.players);
          
          jsManager.saveSetting("map is 3d", ((ToggleButton)(getElement("2d 3d toggle", "bottom bar"))).getState());
          reloadGame();
          
        }
        else if (event.id.equals("saving manager")){
          loadingName = ((BaseFileManager)getElement("saving manager", "save screen")).selectedSaveName();
          ((TextEntry)getElement("save namer", "save screen")).setText(loadingName);
        }
      }
      if (event.type.equals("notification selected")){
        int x = notificationManager.lastSelected.x, y = notificationManager.lastSelected.y;
        map.targetCell(x, y, 100);
        selectCell(x, y, false);
      }
    }
  }
  public void deselectCell(){
    tooltip.hide();
    cellSelected = false;
    map.unselectCell();
    getPanel("land management").setVisible(false);
    getPanel("party management").setVisible(false);
    map.cancelMoveNodes();
    moving = false;
    //map.setWidth(round(width-bezel*2));
    ((Text)getElement("turns remaining", "party management")).setText("");
  }

  public void moveParty(int px, int py){
    moveParty(px, py, false);
  }

  public void moveParty(int px, int py, boolean splitting){
    boolean hasMoved = false;
    int startPx = px;
    int startPy = py;
    Party p;

    if (splitting){
      p = splittedParty;
    } else {
      p = parties[py][px];
    }


    boolean cellFollow = (px==cellX && py==cellY);
    boolean stillThere = true;
    if (p.target == null || p.path == null)
      return;
    int tx = p.target[0];
    int ty = p.target[1];
    if (px == tx && py == ty){
      if (splitting){
        if(parties[py][px] == null){
          parties[py][px] = p;
        } else {
          parties[py][px].changeUnitNumber(p.getUnitNumber());
        }
      }
      p.clearPath();
      return;
    }

    ArrayList <int[]> path = p.path;
    int i=0;
    boolean moved = false;
    for (int node=1; node<path.size(); node++){
      int cost = cost(path.get(node)[0], path.get(node)[1], px, py);
      if (p.getMovementPoints() >= cost){
        hasMoved = true;
        if (parties[path.get(node)[1]][path.get(node)[0]] == null){
          // empty cell
          p.subMovementPoints(cost);
          parties[path.get(node)[1]][path.get(node)[0]] = p;
          if (splitting){
            splittedParty = null;
            splitting = false;
          } else{
            parties[py][px] = null;
          }
          px = path.get(node)[0];
          py = path.get(node)[1];
          p = parties[py][px];
          if (!moved){
            p.moved();
            moved = true;
          }
        }
        else if(path.get(node)[0] != px || path.get(node)[1] != py){
          p.clearPath();
          if (parties[path.get(node)[1]][path.get(node)[0]].player == turn){
            // merge cells
            notificationManager.post("Parties Merged", (int)path.get(node)[0], (int)path.get(node)[1], turnNumber, turn);
            int movementPoints = min(parties[path.get(node)[1]][path.get(node)[0]].getMovementPoints(), p.getMovementPoints()-cost);
            int overflow = parties[path.get(node)[1]][path.get(node)[0]].changeUnitNumber(p.getUnitNumber());
            if(cellFollow){
              selectCell((int)path.get(node)[0], (int)path.get(node)[1], false);
              stillThere = false;
            }
            if (splitting){
              splittedParty = null;
              splitting = false;
            } else{
              parties[py][px] = null;
            }
            if (overflow>0){
              if(parties[path.get(node-1)[1]][path.get(node-1)[0]]==null){
                p.setUnitNumber(overflow);
                parties[path.get(node-1)[1]][path.get(node-1)[0]] = p;
              } else {
                parties[path.get(node-1)[1]][path.get(node-1)[0]].changeUnitNumber(overflow);
              }
            }
            parties[path.get(node)[1]][path.get(node)[0]].setMovementPoints(movementPoints);
          } else if (parties[path.get(node)[1]][path.get(node)[0]].player == 2){
            // merge cells battle
            notificationManager.post("Battle Reinforced", (int)path.get(node)[0], (int)path.get(node)[1], turnNumber, turn);
            int overflow = ((Battle) parties[path.get(node)[1]][path.get(node)[0]]).changeUnitNumber(turn, p.getUnitNumber());
            if(cellFollow){
              selectCell((int)path.get(node)[0], (int)path.get(node)[1], false);
              stillThere = false;
            }
              if (splitting){
                splittedParty = null;
                splitting = false;
              } else{
                parties[py][px] = null;
              }
            if (overflow>0){
              if(parties[path.get(node-1)[1]][path.get(node-1)[0]]==null){
                p.setUnitNumber(overflow);
                parties[path.get(node-1)[1]][path.get(node-1)[0]] = p;
              } else {
                parties[path.get(node-1)[1]][path.get(node-1)[0]].changeUnitNumber(overflow);
              }
            }
          }
          else{
            int x, y;
            x = path.get(node)[0];
            y = path.get(node)[1];
            int otherPlayer = parties[y][x].player;
            notificationManager.post("Battle Started", x, y, turnNumber, turn);
            notificationManager.post("Battle Started", x, y, turnNumber, otherPlayer);
            p.subMovementPoints(cost);
            parties[y][x] = new Battle(p, parties[y][x]);
            parties[y][x] = ((Battle)parties[y][x]).doBattle();
            if(parties[y][x].player != 2){
              notificationManager.post("Battle Ended. Player "+str(parties[y][x].player+1)+" won", x, y, turnNumber, turn);
              notificationManager.post("Battle Ended. Player "+str(parties[y][x].player+1)+" won", x, y, turnNumber, otherPlayer);
            }
            if(cellFollow){
              selectCell((int)path.get(node)[0], (int)path.get(node)[1], false);
              stillThere = false;
            }
            if (splitting){
                splittedParty = null;
                splitting = false;
              } else{
                parties[py][px] = null;
              }
            if(buildings[path.get(node)[1]][path.get(node)[0]]!=null&&buildings[path.get(node)[1]][path.get(node)[0]].type==0){
              buildings[path.get(node)[1]][path.get(node)[0]] = null;
            }
          }
          break;
        }
        i++;
      }
      else{
        p.path = new ArrayList(path.subList(i, path.size()));
        break;
      }
      if (tx==px&&ty==py){
        p.clearPath();
      }
    }
    
    if(cellFollow&&stillThere){
      selectCell((int)px, (int)py, false);
    }
    
    // if the party didnt move then put the splitted party back into the cell
    if (startPx == px && startPy == py && !hasMoved){
      parties[py][px] = p;
    }
  }
  public int getMoveTurns(int startX, int startY, int targetX, int targetY, Node[][] nodes){
    int movementPoints;
    if (parties[startY][startX] != null)
      movementPoints = round(parties[startY][startX].getMovementPoints()); 
    else if (splittedParty != null)
      movementPoints = round(splittedParty.getMovementPoints());
    else
      return -1; 

    int turns = 0;
    ArrayList <int[]> path = getPath(startX, startY, targetX, targetY, nodes);
    Collections.reverse(path);
    for (int node=1; node<path.size(); node++){
      int cost = cost(path.get(node)[0], path.get(node)[1], path.get(node-1)[0], path.get(node-1)[1]);
      if (movementPoints < cost){
        turns += 1;
        movementPoints = gameData.getJSONObject("game options").getInt("movement points");
      }
      movementPoints -= cost;
    }
    return turns;
  }
  public int splitUnitsNum(){
    return round(((Slider)getElement("split units", "party management")).getValue());
  }
  public void refreshTooltip(){
    if (!getPanel("pause screen").visible){
      if (((TaskManager)getElement("tasks", "party management")).moveOver() && getPanel("party management").visible){
        tooltip.setTask(((TaskManager)getElement("tasks", "party management")).findMouseOver());
        tooltip.show();
      }
      else if(((Text)getElement("turns remaining", "party management")).mouseOver()&& getPanel("party management").visible){
        tooltip.setTurnsRemaining();
        tooltip.show();
      }
      else if(((Button)getElement("move button", "party management")).mouseOver()&& getPanel("party management").visible){
        tooltip.setMoveButton();
        tooltip.show(); 
      }
      else if (map.mouseOver()){
        map.updateHoveringScale();
        if (moving && !UIHovering()){
          Node [][] nodes = map.getMoveNodes();
          int x = floor(map.scaleXInv()); 
          int y = floor(map.scaleYInv());
          if (x < mapWidth && y<mapHeight && x>=0 && y>=0 && nodes[y][x] != null && !(cellX == x && cellY == y)){
            if (parties[cellY][cellX] != null){
              map.updatePath(getPath(cellX, cellY, x, y, map.getMoveNodes()));
            }
            if(parties[y][x]==null){
              //Moving into empty tile
              int turns = getMoveTurns(cellX, cellY, x, y, nodes);
              boolean splitting = splitUnitsNum()!=parties[cellY][cellX].getUnitNumber();
              tooltip.setMoving(turns, splitting);
              tooltip.show();
            }
            else {
              if (parties[y][x].player == turn){
                //merge parties
                tooltip.setMerging();
                tooltip.show();
              }
              else {
                //Attack
                BigDecimal chance = battleEstimateManager.getEstimate(cellX, cellY, x, y, splitUnitsNum());
                tooltip.setAttacking(chance);
                tooltip.show();
              }
            }
          }
        }
        else{
          map.cancelPath();
          tooltip.hide();
        }
      }
      else{
        map.cancelPath();
        tooltip.hide();
      }
      map.setActive(!UIHovering());
    }
  }

  public ArrayList<String> mouseEvent(String eventType, int button){
    refreshTooltip();
    if (button == RIGHT){
      if (eventType == "mousePressed"){
        if (parties[cellY][cellX] != null && parties[cellY][cellX].player == turn && cellSelected && !UIHovering()){
          if (map.mouseOver()){
            if (moving){
              map.cancelPath();
              moving = false;
              map.cancelMoveNodes();
            }
            else{
              moving = true;
              map.updateMoveNodes(djk(cellX, cellY));
            }
          } 
        }
      }
      if (eventType == "mouseReleased"){
        if (parties[cellY][cellX] != null && parties[cellY][cellX].player == turn && !UIHovering()){ 
          if (moving){
            int x = floor(map.scaleXInv());

            int y = floor(map.scaleYInv());
            postEvent(new Move(cellX, cellY, x, y));
            map.cancelPath();
            moving = false;
            map.cancelMoveNodes();
          }
        }
      }
    }
    if (button == LEFT){
      if (eventType == "mousePressed"){
        mapClickPos = new int[]{mouseX, mouseY, millis()};
      }
      if (eventType == "mouseReleased" && mapClickPos != null && mapClickPos[0] == mouseX && mapClickPos[1] == mouseY && millis() - mapClickPos[2] < CLICKHOLD){ // Custom mouse click
        mapClickPos = null;
        if (activePanel == "default" && !UIHovering()){
          if (map.mouseOver()){
            if (moving){
              //int x = floor(map.scaleXInv(mouseX));
              //int y = floor(map.scaleYInv(mouseY));
              //postEvent(new Move(cellX, cellY, x, y));
              //map.cancelPath();
              if (mousePressed){
                map.cancelPath();
                moving = false;
                map.cancelMoveNodes();
              }
              else{
                int x = floor(map.scaleXInv());
                int y = floor(map.scaleYInv());
                postEvent(new Move(cellX, cellY, x, y));
                map.cancelPath();
                moving = false;
                map.cancelMoveNodes();
              }
            }
            else{
              if(floor(map.scaleXInv())==cellX&&floor(map.scaleYInv())==cellY&&cellSelected){
                deselectCell();
              } else {
                selectCell();
              }
            }
          }
        }
      }
    }
    return new ArrayList<String>();
  }
  public void selectCell(){
    // select cell based on mouse pos
    int x = floor(map.scaleXInv());
    int y = floor(map.scaleYInv());
    selectCell(x, y, false);
  }

  public boolean cellInBounds(int x, int y){
    return 0<=x&&x<mapWidth&&0<=y&&y<mapHeight;
  }

  public void selectCell(int x, int y, boolean raw){
    deselectCell();
    if(raw){
      selectCell();
    }
    else if (cellInBounds(x, y)){
      tooltip.hide();
      cellX = x;
      cellY = y;
      cellSelected = true;
      map.selectCell(cellX, cellY);
      //map.setWidth(round(width-bezel*2-400));
      getPanel("land management").setVisible(true);
      if (parties[cellY][cellX] != null && parties[cellY][cellX].isTurn(turn)){
        if (parties[cellY][cellX].getTask() != JSONIndex(gameData.getJSONArray("tasks"), "Battle")){
          ((Slider)getElement("split units", "party management")).show();
        }
        else{
          ((Slider)getElement("split units", "party management")).hide();
        }
        getPanel("party management").setVisible(true);
        if (parties[cellY][cellX].getUnitNumber() <= 1){
          ((Slider)getElement("split units", "party management")).hide();
        } else {
          ((Slider)getElement("split units", "party management")).setScale(1, parties[cellY][cellX].getUnitNumber(), parties[cellY][cellX].getUnitNumber(), 1, parties[cellY][cellX].getUnitNumber()/2);
        }
        if (turn == 1){
          partyManagementColour = color(170, 30, 30);
          getPanel("party management").setColour(color(220, 70, 70));
        } else {
          partyManagementColour = color(0, 0, 150);
          getPanel("party management").setColour(color(70, 70, 220));
        }
        checkTasks();
      }
    }
  }
  public float[] resourceProduction(int x, int y){
    float[] totalResourceRequirements = new float[numResources];
    float [] resourceAmountsAvailable = new float[numResources];
    float [] production = new float[numResources];
    for(int i=0; i<numResources;i++){
      if(totalResourceRequirements[i]==0){
        resourceAmountsAvailable[i] = 1;
      } else{
       resourceAmountsAvailable[i] = min(1, players[turn].resources[i]/totalResourceRequirements[i]);
      }
    }
    if (parties[y][x] != null){
      if (parties[y][x].player == turn){
        float productivity = 1;
        for (int task=0; task<tasks.length;task++){
          if(parties[y][x].getTask()==task){
            for(int resource = 0; resource < numResources; resource++){
              if(taskCosts[task][resource]>0){
                productivity = min(productivity, resourceAmountsAvailable[resource]);
              }
            }
          }
        }
        for (int task=0; task<tasks.length;task++){
          if(parties[y][x].getTask()==task){
            for(int resource = 0; resource < numResources; resource++){
              if(resource<numResources){
                production[resource] = (taskOutcomes[task][resource])*productivity*parties[y][x].getUnitNumber();
              }
            }
          }
        }
      }
    }
    return production;
  }
  public float[] resourceConsumption(int x, int y){
    float[] totalResourceRequirements = new float[numResources];
    float [] resourceAmountsAvailable = new float[numResources];
    float [] production = new float[numResources];
    for(int i=0; i<numResources;i++){
      if(totalResourceRequirements[i]==0){
        resourceAmountsAvailable[i] = 1;
      } else{
       resourceAmountsAvailable[i] = min(1, players[turn].resources[i]/totalResourceRequirements[i]);
      }
    }
    if (parties[y][x] != null){
      if (parties[y][x].player == turn){
        float productivity = 1;
        for (int task=0; task<tasks.length;task++){
          if(parties[y][x].getTask()==task){
            for(int resource = 0; resource < numResources; resource++){
              if(taskCosts[task][resource]>0){
                productivity = min(productivity, resourceAmountsAvailable[resource]);
              }
            }
          }
        }
        for (int task=0; task<tasks.length;task++){
          if(parties[y][x].getTask()==task){
            for(int resource = 0; resource < numResources; resource++){
              if(resource<numResources){
                production[resource] = (taskCosts[task][resource])*productivity*parties[y][x].getUnitNumber();
              }
            }
          }
        }
      }
    }
    return production;
  }
  public void drawPartyManagement(PGraphics panelCanvas){
    Panel pp = getPanel("party management");
    panelCanvas.pushStyle();
    panelCanvas.fill(partyManagementColour);
    panelCanvas.rect(cellSelectionX, pp.y, cellSelectionW, 13*jsManager.loadFloatSetting("text scale"));
    panelCanvas.fill(255);
    panelCanvas.textFont(getFont(10*jsManager.loadFloatSetting("text scale")));
    panelCanvas.textAlign(CENTER, TOP);
    panelCanvas.text("Party Management", cellSelectionX+cellSelectionW/2, pp.y);

    panelCanvas.fill(0);
    panelCanvas.textAlign(LEFT, CENTER);
    panelCanvas.textFont(getFont(8*jsManager.loadFloatSetting("text scale")));
    float barY = cellSelectionY + 13*jsManager.loadFloatSetting("text scale") + cellSelectionH*0.15f + bezel*2;
    panelCanvas.text("Movement Points Remaining: "+parties[cellY][cellX].getMovementPoints(turn) + "/"+gameData.getJSONObject("game options").getInt("movement points"), 120+cellSelectionX, barY);
    barY += 13*jsManager.loadFloatSetting("text scale");
    panelCanvas.text("Units: "+parties[cellY][cellX].getUnitNumber(turn) + "/1000", 120+cellSelectionX, barY);
    barY += 13*jsManager.loadFloatSetting("text scale");
    if (parties[cellY][cellX].pathTurns > 0){
      ((Text)getElement("turns remaining", "party management")).setText("Turns Remaining: "+ parties[cellY][cellX].pathTurns);
    }
    else if (parties[cellY][cellX].actions.size() > 0 && parties[cellY][cellX].actions.get(0).initialTurns > 0){
      ((Text)getElement("turns remaining", "party management")).setText("Turns Remaining: "+parties[cellY][cellX].turnsLeft() + "/"+round(parties[cellY][cellX].calcTurns(parties[cellY][cellX].actions.get(0).initialTurns)));
    }
  }

  public String resourcesList(float[] resources){
    String returnString = "";
    boolean notNothing = false;
    for (int i=0; i<numResources;i++){
      if (resources[i]>0){
        returnString += roundDp(""+resources[i], 1)+ " " +resourceNames[i]+ ", ";
        notNothing = true;
      }
    }
    if (!notNothing)
      returnString += "Nothing/Unknown";
    else if(returnString.length()-2 > 0)
      returnString = returnString.substring(0, returnString.length()-2);
    return returnString;
  }

  public float[] totalResources(){
    float[] amount=new float[resourceNames.length];
    for (int x=0; x<mapWidth; x++){
      for (int y=0; y<mapHeight; y++){
        for (int res=0; res<9; res++){
          amount[res]+=resourceProduction(x, y)[res];
          amount[res]-=resourceConsumption(x, y)[res];
        }
      }
    }
    return amount;
  }

  public void drawCellManagement(PGraphics panelCanvas){
    panelCanvas.pushStyle();
    panelCanvas.fill(0, 150, 0);
    panelCanvas.rect(cellSelectionX, cellSelectionY, cellSelectionW, 13*jsManager.loadFloatSetting("text scale"));
    panelCanvas.fill(255);
    panelCanvas.textFont(getFont(10*jsManager.loadFloatSetting("text scale")));
    panelCanvas.textAlign(CENTER, TOP);
    panelCanvas.text("Land Management", cellSelectionX+cellSelectionW/2, cellSelectionY);

    panelCanvas.fill(0);
    panelCanvas.textAlign(LEFT, TOP);
    float barY = cellSelectionY + 13*jsManager.loadFloatSetting("text scale");
    panelCanvas.text("Cell Type: "+gameData.getJSONArray("terrain").getJSONObject(terrain[cellY][cellX]-1).getString("display name"), 5+cellSelectionX, barY);
    barY += 13*jsManager.loadFloatSetting("text scale");
    if (buildings[cellY][cellX] != null){
      if (buildings[cellY][cellX].type != 0)
        panelCanvas.text("Building: "+buildingTypes[buildings[cellY][cellX].type-1], 5+cellSelectionX, barY);
      else
        panelCanvas.text("Building: Construction Site", 5+cellSelectionX, barY);
      barY += 13*jsManager.loadFloatSetting("text scale");
    }
    float[] production = resourceProduction(cellX, cellY);
    float[] consumption = resourceConsumption(cellX, cellY);
    String pl = resourcesList(production);
    String cl = resourcesList(consumption);
    panelCanvas.fill(0);
    if (!pl.equals("Nothing/Unknown")){
      panelCanvas.text("Producing: "+pl, 5+cellSelectionX, barY);
      barY += 13*jsManager.loadFloatSetting("text scale");
    }
    if (!cl.equals("Nothing/Unknown")){
      panelCanvas.fill(255,0,0);
      panelCanvas.text("Consuming: "+cl, 5+cellSelectionX, barY);
      barY += 13*jsManager.loadFloatSetting("text scale");
    }
  }

  public String getResourceString(float amount, PGraphics panelCanvas){
    String tempString = roundDp(""+amount, 1);
    if (amount >= 0){
      fill(0);
      tempString = "+"+tempString;
    }
    else{
      fill(255, 0, 0);
    }
    return tempString;
  }

  public void drawRocketProgressBar(PGraphics panelCanvas){
    int x, y, w, h;
    String progressMessage;
    boolean both = players[0].resources[getResIndex("rocket progress")] != 0 && players[1].resources[getResIndex("rocket progress")] != 0;
    if (players[0].resources[getResIndex("rocket progress")] ==0 && players[1].resources[getResIndex("rocket progress")] == 0)return;
    int progress = PApplet.parseInt(players[turn].resources[getResIndex("rocket progress")]);
    int fillColour;
    if(progress == 0){
      progress = PApplet.parseInt(players[(turn+1)%2].resources[getResIndex("rocket progress")]);
      progressMessage = "";
      fillColour = playerColours[(turn+1)%2];
    } else {
      fillColour = playerColours[turn];
      if(progress>=1000){
         progressMessage = "Rocket Progress: Completed";
      } else {
        progressMessage = "Rocket Progress: "+str(progress)+"/1000";
      }
    }
    if (both){
      x = round(width*0.25f);
      y = round(height*0.05f);
      w = round(width/2);
      h = round(height*0.015f);
      panelCanvas.fill(200);
      panelCanvas.stroke(100);
      panelCanvas.rect(x, y, w, h);
      panelCanvas.noStroke();
      progress = PApplet.parseInt(players[0].resources[getResIndex("rocket progress")]);
      w = round(min(w, w*progress/1000));
      panelCanvas.fill(playerColours[0]);
      panelCanvas.rect(x, y, w, h);
      y = round(height*0.065f);
      w = round(width/2);
      panelCanvas.fill(200);
      panelCanvas.stroke(100);
      panelCanvas.rect(x, y, w, h);
      panelCanvas.noStroke();
      progress = PApplet.parseInt(players[1].resources[getResIndex("rocket progress")]);
      w = round(min(w, w*progress/1000));
      panelCanvas.fill(playerColours[1]);
      panelCanvas.rect(x, y, w, h);
      y = round(height*0.05f);
    } else {
      x = round(width*0.25f);
      y = round(height*0.05f);
      w = round(width/2);
      h = round(height*0.03f);
      panelCanvas.fill(200);
      panelCanvas.stroke(100);
      panelCanvas.rect(x, y, w, h);
      panelCanvas.noStroke();
      w = round(min(w, w*progress/1000));
      panelCanvas.fill(fillColour);
      panelCanvas.rect(x, y, w, h);
    }
    panelCanvas.textFont(getFont(10*jsManager.loadFloatSetting("text scale")));
    panelCanvas.textAlign(CENTER, BOTTOM);
    panelCanvas.fill(200);
    int tw = ceil((textWidth(progressMessage)));
    panelCanvas.rect(width/2 -tw/2, y-10*jsManager.loadFloatSetting("text scale"), tw, 10*jsManager.loadFloatSetting("text scale"));
    panelCanvas.fill(0);
    panelCanvas.text(progressMessage, width/2, y);
  }

  public ArrayList<String> keyboardEvent(String eventType, char _key){
    if (eventType == "keyPressed" && _key == ESC){
      getPanel("pause screen").visible = !getPanel("pause screen").visible;
      if (getPanel("pause screen").visible){
        ((BaseFileManager)getElement("saving manager", "save screen")).loadSaveNames();
        // Disable map
        getElement("2dmap", "default").active = false;
        getElement("3dmap", "default").active = false;
      }
      else{
        getPanel("save screen").visible = false;
        // Enable map
        getElement("2dmap", "default").active = true;
        getElement("3dmap", "default").active = true;
      }
    }
    if (!getPanel("pause screen").visible){
      refreshTooltip();
      if (eventType == "keyTyped"){
        if (key == ' '){
          postEvent(new EndTurn());
        }
        else if (key == 'i'){
          int[] t = findIdle(turn);
          if (t[0] != -1){
            selectCell(t[0], t[1], false);
            map.targetCell(t[0], t[1], 64);
          }
        }
      }
    }
    return new ArrayList<String>();
  }
  public void enterState(){
    reloadGame();
  }

  public void reloadGame(){
    mapWidth = jsManager.loadIntSetting("map size");
    mapHeight = jsManager.loadIntSetting("map size");
    updateCellSelection();

    clearPrevIdle();
    ((Text)getElement("turns remaining", "party management")).setText("");
    ((Panel)getPanel("end screen")).visible = false;
    getPanel("save screen").visible = false;
    // Enable map
    getElement("2dmap", "default").active = true;
    getElement("3dmap", "default").active = true;
    
    Text winnerMessage = ((Text)this.getElement("winner", "end screen"));
    winnerMessage.setText("Winner: player /w");

    if (jsManager.loadBooleanSetting("map is 3d")){
      map = (Map3D)getElement("3dmap", "default");
      ((Map3D)getElement("3dmap", "default")).visible = true;
      ((Map2D)getElement("2dmap", "default")).visible = false;
    } else {
      map = (Map2D)getElement("2dmap", "default");
      ((Map3D)getElement("3dmap", "default")).visible = false;
      ((Map2D)getElement("2dmap", "default")).visible = true;
      ((Map2D)map).reset();
    }
    if(loadingName != null){
      MapSave mapSave = ((BaseMap)map).loadMap("saves/"+loadingName, resourceNames.length);
      terrain = mapSave.terrain;
      buildings = mapSave.buildings;
      parties = mapSave.parties;
      mapWidth = mapSave.mapWidth;
      mapHeight = mapSave.mapHeight;
      this.turnNumber = mapSave.startTurn;
      this.turn = mapSave.startPlayer;
      this.players = mapSave.players;
      if(!jsManager.loadBooleanSetting("map is 3d")){
        ((Map2D)map).mapXOffset = this.players[turn].mapXOffset;
        ((Map2D)map).mapYOffset = this.players[turn].mapYOffset;
        ((Map2D)map).blockSize = this.players[turn].blockSize;
      }
    } else {
      ((BaseMap)map).generateMap(mapWidth, mapHeight);
      terrain = ((BaseMap)map).terrain;
      buildings = ((BaseMap)map).buildings;
      parties = ((BaseMap)map).parties;
      PVector[] playerStarts = generateStartingParties();
      float[] conditions2 = map.targetCell((int)playerStarts[1].x, (int)playerStarts[1].y, 42);
      players[1] = new Player(conditions2[0], conditions2[1], 42, startingResources.clone(), color(255,0,0));
      float[] conditions1 = map.targetCell((int)playerStarts[0].x, (int)playerStarts[0].y, 42);
      players[0] = new Player(conditions1[0], conditions1[1], 42, startingResources.clone(), color(0,0,255));
      turn = 0;
      turnNumber = 0;
    }
    
    battleEstimateManager = new BattleEstimateManager(parties);
    //for(int i=0;i<NUMOFBUILDINGTYPES;i++){
    //  buildings[(int)playerStarts[0].y][(int)playerStarts[0].x+i] = new Building(1+i);
    //}
    deselectCell();
    tooltip.hide();
    winner = -1;
    this.totals = totalResources();
    TextBox t = ((TextBox)(getElement("turn number", "bottom bar")));
    t.setColour(players[turn].colour);
    t.setText("Turn "+turnNumber);

    ResourceSummary rs = ((ResourceSummary)(getElement("resource summary", "bottom bar")));
    rs.updateNet(totals);
    rs.updateStockpile(players[turn].resources);
    getPanel("pause screen").visible = false;

    notificationManager.reset();

    if (anyIdle(turn)){
      ((Button)getElement("idle party finder", "bottom bar")).setColour(color(255, 50, 50));
    }
    else{
      ((Button)getElement("idle party finder", "bottom bar")).setColour(color(150));
    }
    map.generateShape();
  }
  public int cost(int x, int y, int prevX, int prevY){
    float mult = 1;
    if (x!=prevX && y!=prevY){
      mult = 1.41f;
    }
    if (0<=x && x<jsManager.loadIntSetting("map size") && 0<=y && y<jsManager.loadIntSetting("map size")){
      return round(gameData.getJSONArray("terrain").getJSONObject(terrain[y][x]-1).getInt("movement cost")*mult);
    }
    //Not a valid location
    return -1;
  }

  public ArrayList<int[]> getPath(int startX, int startY, int targetX, int targetY, Node[][] nodes){
    ArrayList<int[]> returnNodes = new ArrayList<int[]>();
    returnNodes.add(new int[]{targetX, targetY});
    int[] curNode = {targetX, targetY};
    while (curNode[0] != startX || curNode[1] != startY){
      returnNodes.add(new int[]{nodes[curNode[1]][curNode[0]].prevX, nodes[curNode[1]][curNode[0]].prevY});
      curNode = returnNodes.get(returnNodes.size()-1);
    }
    return returnNodes;
  }
  public Node[][] djk(int x, int y){
    int[][] mvs = {{1,0}, {0,1}, {1,1}, {-1,0}, {0,-1}, {-1,-1}, {1,-1}, {-1,1}};
    int xOff = 0;
    int yOff = 0;
    int w = mapWidth;
    int h = mapHeight;
    Node[][] nodes = new Node[h][w];
    int cx = x-xOff;
    int cy = y-yOff;
    nodes[cy][cx] = new Node(0, false, cx, cy);
    ArrayList<Integer> curMinCosts = new ArrayList<Integer>();
    ArrayList<int[]> curMinNodes = new ArrayList<int[]>();
    curMinNodes.add(new int[]{cx, cy});
    curMinCosts.add(0);
    while (curMinNodes.size() > 0){
      nodes[curMinNodes.get(0)[1]][curMinNodes.get(0)[0]].fixed = true;
      for (int[] mv : mvs){
        int nx = curMinNodes.get(0)[0]+mv[0];
        int ny = curMinNodes.get(0)[1]+mv[1];
        if (0 <= nx && nx < w && 0 <= ny && ny < h){
          boolean sticky = parties[ny][nx] != null;
          int newCost = cost(nx, ny, curMinNodes.get(0)[0], curMinNodes.get(0)[1]);
          int prevCost = curMinCosts.get(0);
          int totalNewCost = prevCost+newCost;
          if (totalNewCost < gameData.getJSONObject("game options").getInt("movement points")*100){
            if (nodes[ny][nx] == null){
              nodes[ny][nx] = new Node(totalNewCost, false, curMinNodes.get(0)[0], curMinNodes.get(0)[1]);
              if (!sticky){
                curMinNodes.add(search(curMinCosts, totalNewCost), new int[]{nx, ny});
                curMinCosts.add(search(curMinCosts, totalNewCost), totalNewCost);
              }
            }
            else if (!nodes[ny][nx].fixed){
              if (totalNewCost < nodes[ny][nx].cost){
                nodes[ny][nx].cost = min(nodes[ny][nx].cost, totalNewCost);
                nodes[ny][nx].setPrev(curMinNodes.get(0)[0], curMinNodes.get(0)[1]);
                if (!sticky){
                  curMinNodes.remove(search(curMinNodes, nx, ny));
                  curMinNodes.add(search(curMinCosts, totalNewCost), new int[]{nx, ny});
                  curMinCosts.remove(search(curMinNodes, nx, ny));
                  curMinCosts.add(search(curMinCosts, totalNewCost), totalNewCost);
                }
              }
            }
          }
        }
      }
      curMinNodes.remove(0);
      curMinCosts.remove(0);
    }
    return nodes;
  }
  public int search(ArrayList<int[]> nodes, int x, int y){
    for (int i=0; i < nodes.size(); i++){
      if (nodes.get(i)[0] == x && nodes.get(i)[1] == y){
        return i;
      }
    }
    return -1;
  }
  public int search(ArrayList<Integer> costs, float target){
    //int upper = nodes.size();
    //int lower = 0;
    //while(nodes.get(lower)[2] > target || target > nodes.get(upper)[2]){

    //}
    //return lower;

    //linear search for now
    for (int i=0; i < costs.size(); i++){
      if (costs.get(i) > target){
        return i;
      }
    }
    return costs.size();
  }
  public boolean startInvalid(PVector p1, PVector p2){
    if(p1.dist(p2)<mapWidth/8||((BaseMap)map).isWater(PApplet.parseInt(p1.x), PApplet.parseInt(p1.y))||((BaseMap)map).isWater(PApplet.parseInt(p2.x), PApplet.parseInt(p2.y))){
      return true;
    }
    return false;
  }
  public PVector generatePartyPosition(){
    return new PVector(PApplet.parseInt(random(0, mapWidth)), PApplet.parseInt(random(0, mapHeight)));
  }

  public PVector[] generateStartingParties(){
    PVector player1 = generatePartyPosition();
    PVector player2 = generatePartyPosition();
    int counter = 0;
    while(startInvalid(player1, player2)&&counter<100){
      counter++;
      player1 = generatePartyPosition();
      player2 = generatePartyPosition();
    }
    if(loadingName == null){
      parties[(int)player1.y][(int)player1.x] = new Party(0, 100, JSONIndex(gameData.getJSONArray("tasks"), "Rest"), gameData.getJSONObject("game options").getInt("movement points"));
      parties[(int)player2.y][(int)player2.x] = new Party(1, 100, JSONIndex(gameData.getJSONArray("tasks"), "Rest"), gameData.getJSONObject("game options").getInt("movement points"));
    }
    return  new PVector[]{player1, player2};
  }
}



class Menu extends State{
  PImage BGimg;
  PShape bg;
  String currentPanel, newPanel;
  HashMap<String, String[]> stateChangers, settingChangers;
  
  Menu(){
    BGimg = loadImage("data/menu_background.jpeg");
    bg = createShape(RECT, 0, 0, width, height);
    bg.setTexture(BGimg);
    
    currentPanel = "startup";
    loadMenuPanels();
    newPanel = currentPanel;
    activePanel = currentPanel;
    
  }
  
  public void loadMenuPanels(){
    resetPanels();
    jsManager.loadMenuElements(this, jsManager.loadFloatSetting("gui scale"));
    hidePanels();
    getPanel(currentPanel).setVisible(true);
    stateChangers = jsManager.getChangeStateButtons();
    settingChangers = jsManager.getChangeSettingButtons();
    
    addElement("loading manager", new BaseFileManager(width/4, height/4, width/2, height/2, "saves"), "load game");
  }
  
  public int currentColour(){
    float c = abs(((float)(hour()-12)+(float)minute()/60)/24);
    int day = color(255, 255, 255, 50);
    int night = color(0, 0, 50, 255);
    return lerpColor(day, night, c*2);
  }
  
  public String update(){
    shape(bg);
    //if(((ToggleButton)getElement("background dimming", "settings")).getState()){
    //  pushStyle();
    //  fill(currentColour());
    //  rect(0, 0, width, height);
    //  popStyle();
    //}
    if (!currentPanel.equals(newPanel)){
      changeMenuPanel();
    }
    drawPanels();
    
    drawMenuTitle();
    return getNewState();
  }
  
  public void drawMenuTitle(){
    // Draw menu state title
    if (jsManager.menuStateTitle(currentPanel) != null){
      fill(0);
      textFont(getFont(jsManager.loadFloatSetting("text scale")*30));
      textAlign(CENTER, TOP);
      text(jsManager.menuStateTitle(currentPanel), width/2, 100);
    }
  }
  
  public void changeMenuPanel(){
    panelToTop(newPanel);
    getPanel(newPanel).setVisible(true);
    getPanel(currentPanel).setVisible(false);
    currentPanel = new String(newPanel);
    for (Element elem : getPanel(newPanel).elements){
      elem.mouseEvent("mouseMoved", LEFT);
    }
    activePanel = newPanel;
  }
  
  public void saveMenuSetting(String id, Event event){
    if (settingChangers.get(id) != null){
      String type = jsManager.getElementType(event.panel, id);
      switch (type){
        case "slider":
          jsManager.saveSetting(settingChangers.get(id)[0], ((Slider)getElement(id, event.panel)).getValue());
          break;
        case "toggle button":
          jsManager.saveSetting(settingChangers.get(id)[0], ((ToggleButton)getElement(id, event.panel)).getState());
          break;
        case "tickbox":
          jsManager.saveSetting(settingChangers.get(id)[0], ((Tickbox)getElement(id, event.panel)).getState());
          break;
        case "dropdown":
          switch (((DropDown)getElement(id, event.panel)).optionTypes){
            case "floats":
              jsManager.saveSetting(settingChangers.get(id)[0], ((DropDown)getElement(id, event.panel)).getFloatVal());
              break;
            case "strings":
              jsManager.saveSetting(settingChangers.get(id)[0], ((DropDown)getElement(id, event.panel)).getStrVal());
              break;
            case "ints":
              jsManager.saveSetting(settingChangers.get(id)[0], ((DropDown)getElement(id, event.panel)).getIntVal());
              break;
          }
          break;
      }
    }
  }
  
  public void revertChanges(String panel){
    for (Element elem : getPanel(panel).elements){
      if (!jsManager.hasFlag(panel, elem.id, "autosave") && settingChangers.get(elem.id) != null){
        String type = jsManager.getElementType(panel, elem.id);
        switch (type){
          case "slider":
            ((Slider)getElement(elem.id, panel)).setValue(jsManager.loadFloatSetting(jsManager.getSettingName(elem.id, panel)));
            break;
          case "toggle button":
            ((ToggleButton)getElement(elem.id, panel)).setState(jsManager.loadBooleanSetting(jsManager.getSettingName(elem.id, panel)));
            break;
          case "tickbox":
            ((Tickbox)getElement(elem.id, panel)).setState(jsManager.loadBooleanSetting(jsManager.getSettingName(elem.id, panel)));
            break;
          case "dropdown":
            switch (((DropDown)getElement(elem.id, panel)).optionTypes){
              case "floats":
                ((DropDown)getElement(elem.id, panel)).setSelected(""+jsManager.loadFloatSetting(jsManager.getSettingName(elem.id, panel)));
                break;
              case "strings":
                ((DropDown)getElement(elem.id, panel)).setSelected(""+jsManager.loadStringSetting(jsManager.getSettingName(elem.id, panel)));
                break;
              case "ints":
                ((DropDown)getElement(elem.id, panel)).setSelected(""+jsManager.loadIntSetting(jsManager.getSettingName(elem.id, panel)));
                break;
            }
            break;
        }
      }
    }
  }
  
  public void elementEvent(ArrayList<Event> events){
    for (Event event:events){
      if (event.type.equals("valueChanged") && settingChangers.get(event.id) != null && event.panel != null){
        if (jsManager.hasFlag(event.panel, event.id, "autosave")){
          saveMenuSetting(event.id, event);
          jsManager.writeSettings();
          if (event.id.equals("framerate cap")){
            setFrameRateCap();
          }
        }
        if (event.id.equals("sound on")){
          loadSounds();
        }
        if (event.id.equals("volume")){
          setVolume();
        }
      }
      if (event.type.equals("clicked")){
        if (stateChangers.get(event.id) != null && stateChangers.get(event.id)[0] != null ){
          newPanel = stateChangers.get(event.id)[0];
          revertChanges(event.panel);
          if (newPanel.equals("load game")){
            ((BaseFileManager)getElement("loading manager", "load game")).loadSaveNames();
          }
        }
        else if (event.id.equals("apply")){
          for (Element elem : getPanel(event.panel).elements){
            if (!jsManager.hasFlag(event.panel, elem.id, "autosave")){
              saveMenuSetting(elem.id, event);
            }
          }
          jsManager.writeSettings();
          loadMenuPanels();
        }
        else if (event.id.equals("revert")){
          revertChanges(event.panel);
        }
        else if (event.id.equals("start")){
          newState = "map";
          loadingName = null;
        }
        else if (event.id.equals("load")){
          newState = "map";
          loadingName = ((BaseFileManager)getElement("loading manager", "load game")).selectedSaveName();
        }
        else if (event.id.equals("exit")){
          exit();
        }
      }
    }
  }
}
  public void settings() {  fullScreen(P3D); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "RocketResourceRace" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
